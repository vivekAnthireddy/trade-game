# **Entity Relationship Diagram**

![Screenshot](images/ERD Diagram.png)

# **Tables**

## Flow table:
### Attributes:
1. project_id is foreign key referencing to project tbale
2. flow_id is primary key

![Screenshot](images/screen1.png)



## Stream table:
### Attributes:
1. flow_id is foreign key referencing to flow table
2. alias is primary key

![Screenshot](images/screen3.png)





## Job table:
### Attributes:
1. job_name and alias together as  primary key
2. alias is also a foreign key referencing to stream table

![Screenshot](images/screen2.png)


