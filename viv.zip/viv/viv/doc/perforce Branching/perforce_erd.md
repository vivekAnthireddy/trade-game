## fact\_project_stream table to store project Details ##
#### List of Attributes
1. project id: which identifies each project uniquely.(Primary key)
2. project_name: Name of the project.
3. project\_last_update: To store the start date of the project.
4. project_branches: To stores the total number of streams for each project.
5. project\_active_branches: To store the number active streams for each project.
6. project\_max_depth: To store the depth of project which is used for pictorial representation. 

![Screenshot](Images/project.png) 

## fact_stream table to store stream Details ##
#### List of Attributes
1. stream\_id: which identifies each branch uniquely.(Primary Key)
2. stream_path: Path of the Stream.
3. stream\_update: Date on which stream was updated for the last time.
4. stream\_owner: Name of the owner who created the branch.
5. stream\_name: Name of the stream.
6. stream\_parent: Parent of the stream.
7. stream\_type: To store the category of the branch which is used to display the categorized pictorial representation of the active branches. (Development/release/main/virtual)
8. stream\_base_parent: To store the base parent name.
9. stream\_creation: To store the date on which the branch was created.
10. stream\_active_flag: To store the current status of a branch. (1 for active and 0 for passive branch)
11. stream\_alive_time: To store the duration of branch which it was alive.
12. stream\_level: To store the depth of branch from it's master branch. This is used to represent branches in pictorial format. 
13. stream\_project_id: To store the project which it belongs to. (Foreign Key referred to primary key of Project table)

![Screenshot](Images/stream.png)



If perforce branches is selected then the active branches of that project are extracted from the database and displayed in the form of a table or pictorial representation.
User can refine the active branches category wise (main or Dev) and see the results in table of pictorial representation.

## Entity Relationship Diagram

![Screenshot](Images/er.png)