# **Entity Relationship Diagram**

![Screenshot](images/Jenkinserd.png)

# **Tables**


## fact_job table:
### Attributes:
1. project_name, branch_name and job_name as primary key

![Screenshot](images/fact_job.PNG)


## fact_build table:
### Attributes:
1. project_name, branch_name,job_name and build_name as primary key
2. project_name, branch_name and job_name are foreign keys

![Screenshot](images/fact_build.PNG)