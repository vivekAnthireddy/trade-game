# **Entity Relationship Diagrams and Tables**

![Screenshot](fact_project_metrics.PNG)

![Screenshot](fact_project_metrics_table.PNG)



![Screenshot](dim_metrics_keywords.PNG)

![Screenshot](dim_metrics_keywords_table.PNG)


