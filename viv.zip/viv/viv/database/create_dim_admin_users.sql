drop table if exists dim_admin_users;

create table dim_admin_users
(admin_id serial primary key,
admin_username character varying(255) NOT NULL,
admin_rights boolean);
