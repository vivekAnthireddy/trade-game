--Table structure to store project details.
--Attributes
--1. product_id: Primary key to dim_sonar_product
--2. product_project_name: Name of the project which this product belongs to.
--3. product_name: To store the name of the product.
--4. product_key: To store the key of the product.
--5. product_username: Username to fetch the product metrics data.
--6. product_password: Password for authenticating the user.
--7. product_creation_date: To store the start date of the project.

--8. product_created_by: To stores the creator of the project.
--9. product_modified_date: To store modified date of the project.
--10. product_modified_by: To store the name of the person who did last modification.
--11. product_project_id: To store the id of the project (foreign key to fact project table).

drop table if exists dim_sonar_product cascade;

create table dim_sonar_product
("product_id" serial NOT NULL PRIMARY KEY,
"product_project_name" character varying(255) NOT NULL,
"product_name" character varying(255) NOT NULL,
"product_key" character varying(255) NOT NULL UNIQUE,
"product_server" character varying(255) NOT NULL,
"product_port" integer NOT NULL,
"product_username" character varying(255) NOT NULL,
"product_password" character varying(255) NOT NULL,
"product_creation_date" timestamp without time zone NOT NULL,
"product_created_by" character varying(255) NOT NULL,
"product_modified_date" timestamp without time zone,
"product_modified_by" character varying(255),
"product_project_id" integer NOT NULL,
foreign key ("product_project_id") references dim_project("project_id") ON DELETE CASCADE ON UPDATE CASCADE);