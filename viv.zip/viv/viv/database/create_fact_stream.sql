--Table structure to store the stream details.
--Attributes
--1. stream_id: which identifies each branch uniquely.(Primary Key)

--2. stream_path: Path of the Stream.

--3. stream_update: Date on which stream was updated for the last time.

--4. stream_owner: Name of the owner who created the branch.

--5. stream_name: Name of the stream.

--6. stream_parent: Parent of the stream.

--7. stream_type: To store the category of the branch which is used to display the categorized pictorial representation of the active branches. (Development/release/main/virtual)

--8. stream_base_parent: To store the base parent name.

--9. stream_creation: To store the date on which the branch was created.

--10. stream_active_flag: To store the current status of a branch. (1 for active and 0 for passive branch)

--11. stream_alive_time: To store the duration of branch which it was alive.

--12. stream_level: To store the depth of branch from it's master branch. This is used to represent branches in pictorial format. 

--13. stream_project_id: To store the project which it belongs to. (Foreign Key referred to primary key of Project table)

drop table if exists fact_stream cascade;

create table fact_stream
("stream_id" integer NOT NULL PRIMARY KEY,
"stream_path" character varying(255) NOT NULL,
"stream_update" timestamp without time zone NOT NULL,
"stream_owner" character varying(255) NOT NULL,
"stream_name" character varying(255) NOT NULL,
"stream_parent" integer NOT NULL,
"stream_type" character varying(30) NOT NULL,
"stream_base_parent" character varying(255) NOT NULL,
"stream_creation" timestamp without time zone NOT NULL,
"stream_active_flag" integer NOT NULL,
"stream_alive_time" integer NOT NULL,
"stream_level" integer NOT NULL,
"stream_project_id" integer NOT NULL,
foreign key ("stream_project_id") references dim_project(project_id) ON DELETE CASCADE ON UPDATE CASCADE);