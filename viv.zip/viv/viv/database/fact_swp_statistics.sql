DROP TABLE if exists public.fact_swp_statistics cascade;

CREATE TABLE public.fact_swp_statistics
(
    swp_statistics_id serial,
    week_no integer,
    week_start_date timestamp without time zone,
    week_end_date timestamp without time zone,
    flow_name character varying(255) COLLATE pg_catalog."default",
    number_of_flow_instances integer,
    number_of_successful_flow_instances integer,
    average_duration interval,
    failed_jobs character varying(255),
    project_id integer,
    CONSTRAINT fact_swp_statistics_pkey PRIMARY KEY (swp_statistics_id),
    CONSTRAINT fact_swp_statistics_project_id_fkey FOREIGN KEY (project_id)
        REFERENCES public.dim_project (project_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)