drop table if exists dim_module_threshold cascade;

create table dim_module_threshold
("threshold_id" serial NOT NULL PRIMARY KEY,
"threshold_module_name" character varying(255),
"threshold_metric_name" character varying(255),
"threshold_value" integer,
"threshold_color" character varying(255));