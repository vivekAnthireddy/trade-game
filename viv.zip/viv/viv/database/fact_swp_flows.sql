drop table if exists fact_swp_flows cascade;

CREATE TABLE public.fact_swp_flows
(
    flow_id integer NOT NULL,
    flow_name character varying(50) COLLATE pg_catalog."default",
    flow_start_date timestamp without time zone,
    flow_end_date timestamp without time zone,
    flow_duration interval,
    flow_status character varying(20) COLLATE pg_catalog."default",
    project_id integer,
    flow_event_id character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT fact_swp_flows_pkey PRIMARY KEY (flow_id),
    CONSTRAINT fact_swp__flows_project_id_fkey FOREIGN KEY (project_id)
        REFERENCES public.dim_project (project_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)