drop table if exists public.dim_swp_connection_details cascade;

CREATE TABLE public.dim_swp_connection_details
(
    swp_connection_details_id serial,
    oracle_db_username character varying(50) COLLATE pg_catalog."default" NOT NULL,
    oracle_db_password character varying(50) COLLATE pg_catalog."default" NOT NULL,
    oracle_db_hostname character varying(50) COLLATE pg_catalog."default" NOT NULL,
    oracle_db_SID character varying(50) COLLATE pg_catalog."default" NOT NULL,
    oracle_db_port_no integer NOT NULL,
    unix_server_hostname character varying(50) COLLATE pg_catalog."default" NOT NULL,
    unix_server_username character varying(50) COLLATE pg_catalog."default" NOT NULL,
    unix_server_password character varying(50) COLLATE pg_catalog."default" NOT NULL,
    unix_server_log_files_path character varying(50) COLLATE pg_catalog."default" NOT NULL,
    project_creation_date timestamp without time zone NOT NULL,
    project_created_by character varying(255) NOT NULL,
    project_modified_date timestamp without time zone,
    project_modified_by character varying(255),
    project_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    project_id integer,
    CONSTRAINT dim_swp_connection_details_pkey PRIMARY KEY (swp_connection_details_id),
    CONSTRAINT dim_swp_connection_details_project_id_fkey FOREIGN KEY (project_id)
        REFERENCES public.dim_project (project_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)