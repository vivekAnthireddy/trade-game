DROP TABLE if exists public.fact_jenkins_statistics cascade;

CREATE TABLE public.fact_jenkins_statistics
(
    jenkins_statistics_id serial,
    week_no integer,
    week_start_date timestamp without time zone,
    week_end_date timestamp without time zone,
    success_rate real,
    successful_builds integer,
    unstable_builds integer,
    failed_builds integer,
    aborted_builds integer,
    failed_products json,
    failed_culprits json,
    longest_number_builds_till_fixing_failure integer,
    average_number_builds_till_fixing_failure integer,
    number_of_failed_builds_till_fixing_failure integer,
    avg_duration_to_fix_failure interval,
    total_duration_of_failed_builds interval,
    longest_duration_to_fix_a_failure interval,
    job_id integer,
    CONSTRAINT fact_jenkins_statistics_pkey PRIMARY KEY (jenkins_statistics_id),
    CONSTRAINT fact_jenkins_statistics_job_id_fkey FOREIGN KEY (job_id)
        REFERENCES public.dim_jenkins_jobs (job_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)