create user dtest1 password 'dtest1_123';

create database dtest1_dashboard owner dtest1;
