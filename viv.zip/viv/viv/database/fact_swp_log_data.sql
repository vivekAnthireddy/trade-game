drop table if exists public.fact_swp_log_data cascade;

CREATE TABLE public.fact_swp_log_data
(
    date timestamp without time zone,
    job_or_stream character varying(20) COLLATE pg_catalog."default",
    name character varying(50) COLLATE pg_catalog."default",
    alias character varying(50) COLLATE pg_catalog."default",
    status character varying(20) COLLATE pg_catalog."default",
    project_id integer,
    CONSTRAINT fact_swp_log_data_project_id_fkey FOREIGN KEY (project_id)
        REFERENCES public.dim_project (project_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)