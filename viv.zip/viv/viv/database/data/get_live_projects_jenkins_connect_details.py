import os
import json
from urllib.parse import urlparse


def dump_into_csv(job_names,hostname,port_no,project_name,csv):
    for job_name in job_names:
        row=hostname+','+str(port_no)+','+job_name+','+project_name+'\n'
        csv.write(row)

if __name__=="__main__":
    '''
    Program to get jenkins connection details into csv file
    '''
    csv_dir = "dim_jenkins_connect.csv"
    csv_file=open(csv_dir,"w")
    columnTitleRow="jenkins_hostname,jenkins_port_no,job_name,project_name\n"
    csv_file.write(columnTitleRow)
    
    for data in os.listdir():
        filename=str(data)+'\config\jenkins.json'
        try:
            file_obj=open(filename,'r')
            json_obj=json.loads(file_obj.read())
            obj=urlparse(json_obj['uri'])
            hostname=obj.hostname.replace('.corp.amdocs.com','')
            port_no=obj.port
            job_names=[]
            project_name=str(data)
            for job in json_obj['jobs']:
                for key,value in job.items():
                    job_names.append(value[0])
            dump_into_csv(job_names,hostname,port_no,project_name,csv_file)
            file_obj.close()
        except Exception as error:
            continue
    csv_file.close()
