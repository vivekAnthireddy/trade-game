import os
import json
from urllib.parse import urlparse


def dump_into_csv(project_name,product_name,product_key,hostname,port_no,csv):
    row=project_name+','+product_name+','+product_key+','+hostname+','+str(port_no)+'\n'
    csv.write(row)

if __name__=="__main__":
    '''
    Program to get sonar product connection details and load into csv file
    '''
    csv_dir = "dim_sonar_product.csv"
    csv_file=open(csv_dir,"w")
    columnTitleRow="product_project_name,product_name,product_key,product_server,product_port\n"
    csv_file.write(columnTitleRow)
    i=0
    for data in os.listdir():
        filename=str(data)+'\config\sonar.json'
        try:
            file_obj=open(filename,'r')
            json_obj=json.loads(file_obj.read())
            obj=urlparse(json_obj['uri'])
            hostname=obj.hostname.replace('.corp.amdocs.com','')
            port_no=obj.port
            components=json_obj['components']
            for i,j in components.items():
                dump_into_csv(str(data),j['component'],j['component'],hostname,port_no,csv_file)
            file_obj.close()

        except Exception as error:
            pass
    csv_file.close()
