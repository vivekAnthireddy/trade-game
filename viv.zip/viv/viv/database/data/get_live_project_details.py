import os
import json
from urllib.parse import urlparse
import random

def dump_into_csv(project_name,csv):
    project_division=['CALA','APAC','EMEA','ATAT']
    project_head=['XYZ','PQR','ABC']
    data_row=project_name+','+random.choice(project_division)+','+random.choice(project_head)+','+'Ongoing'+'\n'
    csv.write(data_row)

if __name__=="__main__":
    '''
    Run this program live projects-directory which creates csv file with project name taken as folder name
    '''
    csv_dir = "dim_project_connect_details.csv"
    csv_file=open(csv_dir,"w")
    columnTitleRow="project_name,project_division,project_head,project_phase\n"
    csv_file.write(columnTitleRow)
    for data in os.listdir():
        project_name=str(data)
        dump_into_csv(project_name,csv_file) 
    csv_file.close()
