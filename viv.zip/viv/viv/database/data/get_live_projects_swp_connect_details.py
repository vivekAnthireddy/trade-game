import os
import json
from urllib.parse import urlparse


def dump_into_csv(hostname,project_name,csv):
    row=hostname+','+project_name+'\n'
    csv.write(row)

if __name__=="__main__":
    '''
    Program to get swp connection details into csv file
    '''
    csv_dir = "dim_swp_connect.csv"
    csv_file=open(csv_dir,"w")
    columnTitleRow="unix_hostname,project_name\n"
    csv_file.write(columnTitleRow)
    
    for data in os.listdir():
        filename=str(data)+'\config\inframate.json'
        try:
            file_obj=open(filename,'r')
            json_obj=json.loads(file_obj.read())
            obj=urlparse(json_obj['uri'])
            hostname=obj.hostname.replace('.corp.amdocs.com','')
            project_name=str(data)
            dump_into_csv(hostname,project_name,csv_file)
            file_obj.close()
        except Exception as error:
            continue
    csv_file.close()

