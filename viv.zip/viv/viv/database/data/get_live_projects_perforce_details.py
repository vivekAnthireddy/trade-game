import os
import json
from urllib.parse import urlparse


def dump_into_csv(project_name,server,depot,csv):
    row=project_name+','+server+','+depot+'\n'
    csv.write(row)

if __name__=="__main__":
    '''Program to get perforce connection details and load into csv file'''
    csv_dir = "dim_perforce_project.csv"
    csv_file=open(csv_dir,"w")
    columnTitleRow="project_name,project_server,project_depot\n"
    csv_file.write(columnTitleRow)
    for data in os.listdir():
        filename=str(data)+'\config\perforce.json'
        try:
            file_obj=open(filename,'r')
            json_obj=json.loads(file_obj.read())
            server=json_obj['uri'].replace('.corp.amdocs.com:',':')
            depot=json_obj['modulesConfig'][0]['path'][0]
            depot=depot[2:]
            depot=depot.split('/')[0]
            dump_into_csv(str(data),server,depot,csv_file)
            file_obj.close()
        except Exception as error:
            pass
    csv_file.close()
