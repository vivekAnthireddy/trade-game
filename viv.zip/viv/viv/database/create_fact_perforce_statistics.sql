drop table if exists fact_perforce_statistics cascade;

create table fact_perforce_statistics
("statistic_id" serial NOT NULL PRIMARY KEY,
"statistic_project_name" character varying(255) NOT NULL,
"statistic_week_no" integer,
"statistic_start_date" timestamp without time zone,
"statistic_end_date" timestamp without time zone,
"statistic_average_branches" REAL,
"statistic_average_active_branches" REAL,
"statistic_average_max_depth" REAL,
"statistic_project_id" integer NOT NULL,
foreign key ("statistic_project_id") references dim_project("project_id") ON DELETE CASCADE ON UPDATE CASCADE);