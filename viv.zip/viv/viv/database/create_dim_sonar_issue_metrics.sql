drop table if exists dim_sonar_issue_metrics cascade;

create table dim_sonar_issue_metrics
("metric_id" serial NOT NULL PRIMARY KEY,
"metric_display_name" character varying(255),
"metric_units" character varying(255),
"metric_active_flag" boolean);