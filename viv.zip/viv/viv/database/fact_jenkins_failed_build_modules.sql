DROP TABLE if exists public.fact_jenkins_failed_build_modules cascade;

CREATE TABLE public.fact_jenkins_failed_build_modules
(
    failed_build_module_id serial,
    failed_build_module_name character varying(50) COLLATE pg_catalog."default",
    build_id integer,
    CONSTRAINT failed_build_modules_pkey PRIMARY KEY (failed_build_module_id),
    CONSTRAINT fact_jenkins_failed_build_modules_build_id_fkey FOREIGN KEY (build_id)
        REFERENCES public.fact_jenkins_build (build_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)