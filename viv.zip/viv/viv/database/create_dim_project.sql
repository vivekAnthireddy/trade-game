--Table structure to store project details.
--Attributes
--1. project id: which identifies each project uniquely.(Primary key)
--2. project_name: Name of the project.
--3. project_division: Division of the project.
--4. project_head: Head of the project.
--5. project_phase: Current phase of the project.
--6. project_creation_date: To store the start date of the project.
--7. project_created_by: To stores the creator of the project.
--8. project_modified_date: To store modified date of the project.
--9. project_modified_by: To store the name of the person who did last modification.

drop table if exists dim_project cascade;

create table dim_project
("project_id" serial NOT NULL PRIMARY KEY,
"project_name" character varying(255) NOT NULL,
"project_division" character varying(50) NOT NULL,
"project_head" character varying(255) NOT NULL,
"project_phase" character varying(255) NOT NULL,
"project_creation_date" timestamp without time zone NOT NULL,
"project_created_by" character varying(255) NOT NULL,
"project_modified_date" timestamp without time zone,
"project_modified_by" character varying(255));