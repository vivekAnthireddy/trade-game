DROP TABLE if exists public.dim_jenkins_jobs cascade;

CREATE TABLE public.dim_jenkins_jobs
(
    job_id serial,
    job_name character varying(50) COLLATE pg_catalog."default",
    project_creation_date timestamp without time zone NOT NULL,
    project_created_by character varying(255) NOT NULL,
    project_modified_date timestamp without time zone,
    project_modified_by character varying(255),
    project_name character varying(50) COLLATE pg_catalog."default",
    project_id integer,
    CONSTRAINT dim_jenkins_jobs_pkey PRIMARY KEY (job_id),
    CONSTRAINT dim_jenkins_jobs_project_id_fkey FOREIGN KEY (project_id)
        REFERENCES public.dim_project (project_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)