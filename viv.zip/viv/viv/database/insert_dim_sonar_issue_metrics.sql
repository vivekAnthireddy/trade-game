insert into dim_sonar_issue_metrics (metric_display_name,metric_units,metric_active_flag) values ('Unresolved Issues','Number',true);

insert into dim_sonar_issue_metrics (metric_display_name,metric_units,metric_active_flag) values ('Blocker Issues','Number',true);

insert into dim_sonar_issue_metrics (metric_display_name,metric_units,metric_active_flag) values ('Critical Issues','Number',true);

insert into dim_sonar_issue_metrics (metric_display_name,metric_units,metric_active_flag) values ('Major Issues','Number',true);

insert into dim_sonar_issue_metrics (metric_display_name,metric_units,metric_active_flag) values ('Minor Issues','Number',true);

insert into dim_sonar_issue_metrics (metric_display_name,metric_units,metric_active_flag) values ('Info Issues','Number',true);

insert into dim_sonar_issue_metrics (metric_display_name,metric_units,metric_active_flag) values ('Major Violator','Name',true);