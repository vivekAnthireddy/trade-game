--Table structure to store the stream details.
--Attributes
--1. project_server_id: Server id of the project
--2. project_server: Server and port address of the project.
--3. project_depot: Depot name of the project.
--4. project_user: username to connect to the project server.
--5. project_password: password to connect to the project server.
--6. project_creation_date: To store the start date of the project.
--7. project_created_by: To stores the creator of the project.
--8. project_modified_date: To store modified date of the project.
--9. project_modified_by: To store the name of the person who did last modification.
--10. project_id: Foreign key to the dim_project table.

drop table if exists dim_perforce_project cascade;

create table dim_perforce_project
("project_server_id" serial NOT NULL Primary key,
"project_server" character varying(255) NOT NULL,
"project_name" character varying(255) NOT NULL,
"project_depot" character varying(255) NOT NULL,
"project_user" character varying(255) NOT NULL,
"project_password" character varying(255) NOT NULL,
"project_creation_date" timestamp without time zone NOT NULL,
"project_created_by" character varying(255) NOT NULL,
"project_modified_date" timestamp without time zone,
"project_modified_by" character varying(255),
"project_id" Integer NOT NULL,
foreign key ("project_id") references dim_project(project_id) ON DELETE CASCADE ON UPDATE CASCADE);