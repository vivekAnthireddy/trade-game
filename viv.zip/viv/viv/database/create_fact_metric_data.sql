--Table structure to store project details.
--Attributes
--1. metric_id: Primary key to fact_metric_data
--2. metric_technical_debt: To store product technical debt value.
--3. metric_new_technical_debt: To store product new technical debt value.
--4. metric_blocker_issues: To store product blocker issues value.
--5. metric_new_blocker_issues: To store product new blocker issues value.
--6. metric_critical_issues: To store product critical issues value.
--7. metric_new_critical_issues: To store product new critical issues value.
--8. metric_bugs: To store product bugs value.
--9. metric_vulnerabilities: To store product vulnerabilities value.
--10. metric_code_smells: To store product code smells value.
--11. metric_issues: To store product issues value.
--12. metric_new_violations: To store product new violations value.
--13. metric_complexity: To store product complexity value.
--14. metric_unit_tests: To store product unit tests value.
--15. metric_unit_test_coverage: To store product unit test coverage value.
--16. metric_lines_of_code: To store product lines of code value.
--17. metric_duplicated_lines: To store product duplicated lines value.
--18. metric_last_analysis: To store the date and time of last data fetch.
--19. metric_product_id: To store product id of the metrics.(Foreign key)


drop table if exists fact_metric_data;

create table fact_metric_data
("metric_id" serial NOT NULL PRIMARY KEY,
"metric_technical_debt" REAL NOT NULL,
"metric_new_technical_debt" REAL NOT NULL,
"metric_blocker_issues" REAL NOT NULL,
"metric_new_blocker_issues" REAL NOT NULL,
"metric_critical_issues" REAL NOT NULL,
"metric_new_critical_issues" REAL NOT NULL,
"metric_bugs" REAL NOT NULL,
"metric_vulnerabilities" REAL NOT NULL,
"metric_code_smells" REAL NOT NULL,
"metric_issues" REAL NOT NULL,
"metric_new_violations" REAL NOT NULL,
"metric_complexity" REAL NOT NULL,
"metric_unit_tests" REAL NOT NULL,
"metric_unit_test_coverage" REAL NOT NULL,
"metric_lines_of_code" REAL NOT NULL,
"metric_duplicated_lines" REAL NOT NULL,
"metric_last_update" timestamp without time zone,
"metric_product_id" integer NOT NULL,
foreign key ("metric_product_id") references dim_sonar_product("product_id") ON DELETE CASCADE ON UPDATE CASCADE);
