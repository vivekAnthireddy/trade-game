insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Technical Debt','Days','sqale_index',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('New Technical Debt','Days','new_technical_debt',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Blocker Issues','Number','blocker_violations',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('New Blocker Issues','Number','new_blocker_violations',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Critical Issues','Number','critical_violations',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('New critical Issues','Number','new_critical_violations',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Bugs','Number','bugs',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Vulnerabilities','Number','vulnerabilities',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Code Smells','Number','code_smells',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Issues','Number','violations',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('New Violations','Number','new_violations',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Complexity','Number','complexity',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Unit Tests','Number','tests',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Unit Test Coverage','Percentage','coverage',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Lines of Code','Number','ncloc',true);

insert into dim_sonar_metrics (metric_display_name,metric_units,metric_keyword,metric_active_flag) values ('Duplicated Lines','Number','duplicated_lines',true);