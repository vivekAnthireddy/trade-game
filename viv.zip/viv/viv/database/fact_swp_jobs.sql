drop table if exists fact_swp_jobs cascade;

CREATE TABLE public.fact_swp_jobs
(
    job_id serial,
    job_name character varying(50) COLLATE pg_catalog."default",
    alias character varying(50) COLLATE pg_catalog."default",
    job_start_time timestamp without time zone,
    job_end_time timestamp without time zone,
    job_duration interval,
    job_status character varying(20) COLLATE pg_catalog."default",
    stream_id integer,
    CONSTRAINT fact_swp_jobs_pkey PRIMARY KEY (job_id),
    CONSTRAINT fact_swp_jobs_stream_id_fkey FOREIGN KEY (stream_id)
        REFERENCES public.fact_swp_streams (stream_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)