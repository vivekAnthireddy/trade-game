--Table structure to store project details.
--Attributes
--1. project id: which identifies each project uniquely.(Primary key)
--2. project_name: Name of the project.
--3. project_last_update: To store the start date of the project.
--4. project_branches: To stores the total number of streams for each project.
--5. project_active_branches: To store the number active streams for each project.
--6. project_max_depth: To store the depth of project which is used for pictorial representation.
--7. project_main_id: Foreign key to main project table.

drop table if exists fact_project_stream cascade;

create table fact_project_stream
("project_id" serial NOT NULL PRIMARY KEY,
"project_name" character varying(255) NOT NULL,
"project_last_update" timestamp without time zone,
"project_branches" integer,
"project_active_branches" integer,
"project_max_depth" integer,
"project_main_id" integer NOT NULL,
foreign key ("project_main_id") references dim_project("project_id") ON DELETE CASCADE ON UPDATE CASCADE);