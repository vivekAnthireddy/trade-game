drop table if exists public.fact_swp_streams cascade;

CREATE TABLE public.fact_swp_streams
(
    stream_id serial,
    stream_name character varying(50) COLLATE pg_catalog."default",
    stream_start_time timestamp without time zone,
    stream_end_time timestamp without time zone,
    stream_duration interval,
    stream_status character varying(20) COLLATE pg_catalog."default",
    alias character varying(50) COLLATE pg_catalog."default",
    flow_id integer,
    CONSTRAINT fact_swp_streams_pkey PRIMARY KEY (stream_id),
    CONSTRAINT fact_swp_streams_flow_id_fkey FOREIGN KEY (flow_id)
        REFERENCES public.fact_swp_flows (flow_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)