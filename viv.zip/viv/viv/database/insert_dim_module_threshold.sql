INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('jenkins','success_rate',65,'#00B450');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('jenkins','success_rate',35,'#FFC300');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('jenkins','success_rate',0,'#ff0000');

INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('sonar','blocker_issues',4,'#00B450');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('sonar','blocker_issues',10,'#FFC300');

INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('sonar','critical_issues',10,'#00B450');	
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('sonar','critical_issues',100,'#FFC300');

INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('sonar','technical_debt',10,'#00B450');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('sonar','technical_debt',50,'#FFC300');

INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('perforce','avg_streams',25,'#00B450');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('perforce','avg_streams',50,'#FFC300');

INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('perforce','avg_active_streams',4,'#00B450');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('perforce','avg_active_streams',10,'#FFC300');

INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('swp','success_rate',65,'#00B450');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('swp','success_rate',35,'#FFC300');
INSERT INTO public.dim_module_threshold(threshold_module_name,threshold_metric_name,threshold_value,threshold_color) VALUES('swp','success_rate',0,'#ff0000');