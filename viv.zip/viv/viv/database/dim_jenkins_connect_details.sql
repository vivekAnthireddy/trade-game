DROP TABLE if exists public.dim_jenkins_connect_details cascade;

CREATE TABLE public.dim_jenkins_connect_details
(
    jenkins_connect_details_id serial,
    jenkins_hostname character varying(50) COLLATE pg_catalog."default",
    jenkins_port_no integer,
    project_name character varying(50) COLLATE pg_catalog."default",
    project_creation_date timestamp without time zone NOT NULL,
    project_created_by character varying(255) NOT NULL,
    project_modified_date timestamp without time zone,
    project_modified_by character varying(255),
    project_id integer,
    CONSTRAINT dim_jenkins_connect_details_pkey PRIMARY KEY (jenkins_connect_details_id),
    CONSTRAINT dim_jenkins_connect_details_project_id_fkey FOREIGN KEY (project_id)
        REFERENCES public.dim_project (project_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)