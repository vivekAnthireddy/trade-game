DROP TABLE if exists public.fact_jenkins_failed_build_culprits cascade;

CREATE TABLE public.fact_jenkins_failed_build_culprits
(
    failed_build_culprit_id serial,
    failed_build_culprit_name character varying(100) COLLATE pg_catalog."default",
    build_id integer,
    CONSTRAINT fact_jenkins_failed_build_culprits_pkey PRIMARY KEY (failed_build_culprit_id),
    CONSTRAINT fact_jenkins_failed_build_culprits_build_id_fkey FOREIGN KEY (build_id)
        REFERENCES public.fact_jenkins_build (build_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)