drop table if exists public.fact_swp_run_date cascade;

CREATE TABLE public.fact_swp_run_date
(
    last_run_date timestamp without time zone,
    project_id integer,
    foreign key ("project_id") references dim_project(project_id) ON DELETE CASCADE ON UPDATE CASCADE
);
