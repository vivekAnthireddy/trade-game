from django import template
from devops_admin.models import DimModuleThreshold
from datetime import date,datetime,timedelta

register=template.Library()

@register.filter
def index(List, i):
    return List[int(i)]

@register.simple_tag
def color(module,metric,value):
    if module=='sonar':
        if not isinstance(value, str):
            queryset=DimModuleThreshold.objects.filter(threshold_module_name=module,threshold_metric_name=metric).order_by('threshold_id')
            for threshold in queryset:
                if value<=threshold.threshold_value:
                    return threshold.threshold_color
            return '#ff0000'
        else:
            return 'black'
    if module=='perforce':
        if not isinstance(value, str):
            queryset=DimModuleThreshold.objects.filter(threshold_module_name=module,threshold_metric_name=metric).order_by('threshold_id')
            for threshold in queryset:
                if value<=threshold.threshold_value:
                    return threshold.threshold_color
            return '#ff0000'
        else:
            return 'black'
    if module=='swp':
        if not isinstance(value, str):
            queryset=DimModuleThreshold.objects.filter(threshold_module_name=module,threshold_metric_name=metric).order_by('threshold_id')
            for threshold in queryset:
                if value>=threshold.threshold_value:
                    return threshold.threshold_color
        else:
            return 'black'

    if module=='jenkins':
        if not isinstance(value, str):
            queryset=DimModuleThreshold.objects.filter(threshold_module_name=module,threshold_metric_name=metric).order_by('threshold_id')
            for threshold in queryset:
                if value>=threshold.threshold_value:
                    return threshold.threshold_color
        else:
            return 'black'

@register.simple_tag
def getweek():
    today=date.today()
    year, week, dow = today.isocalendar()
    start_date = today - timedelta(dow - 1)
    end_date = start_date + timedelta(6)
    return str(start_date)+' To '+str(end_date)

@register.simple_tag
def modalarrow(modal,row,column):
    if row!=len(modal)-1 and not isinstance(modal[row][column], str) and not isinstance(modal[row+1][column], str):
        if modal[row][column]<modal[row+1][column]:
            return 'fas fa-arrow-circle-down'
        elif modal[row][column]>modal[row+1][column]:
            return "fas fa-arrow-circle-up"
        else:
            return 'fas fa-arrows-alt-h'
