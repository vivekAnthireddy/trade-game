from django.conf.urls import include, url
from .views import addProject, upload_factproject_csv, upload_perforce_csv, uploadPerforce, admin_view, processDetails, upload_swp_csv, upload_sonar_csv, upload_jenkins_csv, get_products, preforceUpdate, sonarUpdate,swpUpdate,update_jenkins_connect,update_jenkins_connect_process,update_jenkins_jobs,update_jenkins_job_process
from django.contrib.auth.decorators import login_required

urlpatterns = [
    url(r'^$',login_required(admin_view.as_view(),login_url='login'), name='admin_page'),
    url(r'^project/process/$', processDetails, name='process'),
    url(r'^upload/factproject_csv/$', upload_factproject_csv, name='upload_factproject_csv'),
    url(r'^upload/perforce_csv/$', upload_perforce_csv, name='upload_perforce_csv'),
    url(r'^upload/perforce/$',login_required(uploadPerforce.as_view(),login_url='login'), name='uploadPerforce'),
    url(r'^upload/swp_csv/$', upload_swp_csv, name='upload_swp_csv'),
    url(r'^upload/jenkins_csv/$', upload_jenkins_csv, name='upload_jenkins_csv'),
    url(r'^upload/sonar_csv/$', upload_sonar_csv, name='upload_sonar_csv'),
    url(r'^get_products/(?P<project_id>[0-9]+)/$',get_products , name='get_products'),
    url(r'^update/perforce/(?P<project_id>[0-9]+)/',login_required(preforceUpdate.as_view(),login_url='login'), name='updatePerforce'),
    url(r'^update/sonar/(?P<project_id>[0-9]+)/(?P<product_id>[0-9]+)/$',login_required(sonarUpdate.as_view(),login_url='login'), name='updateSonar'),
    url(r'^update/swp/(?P<project_id>[0-9]+)/',login_required(swpUpdate.as_view(),login_url='login'), name='updateSwp'),
    url(r'^update/jenkins_connect/(?P<project_id>[0-9]+)/',update_jenkins_connect, name='update_jenkins_connect'),
    url(r'^update/jenkins_connect/update_jenkins_connect_process/',update_jenkins_connect_process, name='update_jenkins_connect_process'),
    url(r'^update/jenkins_jobs/(?P<project_id>[0-9]+)/',update_jenkins_jobs, name='update_jenkins_jobs'),
    url(r'^update/jenkins_connect/update_jenkins_job_process/',update_jenkins_job_process, name='update_jenkins_connect_process'),
]
