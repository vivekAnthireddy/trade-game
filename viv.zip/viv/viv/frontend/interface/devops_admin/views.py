from django.views.generic.edit import CreateView, UpdateView
from .models import DimProject, DimPerforceProject, DimAdminUsers, DimSwpConnectionDetails, DimJenkinsConnectDetails, DimSonarProduct,DimJenkinsJobs
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
import datetime
from django.contrib import messages
from django.core.urlresolvers import reverse
from .forms import DimProjectForm, DimPerforceProjectForm, DimSwpConnectionDetailsForm, DimSonarProductForm,DimJenkinsConnectDetailsForm, DimJenkinsJobsForm
from django.contrib.auth.decorators import login_required
import base64
import csv, json
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.views.generic import TemplateView
from django.template import loader
from django.contrib import messages
from django.db import IntegrityError

def encrypt(key, clear):
    '''Encryption of password'''
    enc = []
    for i in range(len(clear)):
        key_c = key[i % len(key)]
        enc_c = chr((ord(clear[i]) + ord(key_c)) % 256)
        enc.append(enc_c)
    return base64.urlsafe_b64encode("".join(enc).encode()).decode()

def decrypt(key, enc):
    '''Decryption of password'''
    dec = []
    enc = base64.urlsafe_b64decode(enc).decode()
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)

class addProject(CreateView):
    model=DimProject
    fields=['project_name', 'project_division', 'project_head', 'project_phase', 'project_creation_date', 'project_created_by']
    readonly_fields=['project_creation_date', 'project_created_by']
    def get_initial(self):
        return {'project_creation_date':datetime.datetime.now(), 'project_created_by':self.request.user, 'project_modified_date':None,'project_modified_by':None}

class preforceUpdate(UpdateView):
    model = DimPerforceProject
    fields = ['project_server','project_depot']

    def get_object(self, *args, **kwargs):
        perforceObject=DimPerforceProject.objects.get(project=self.kwargs['project_id'])
        perforce=get_object_or_404(DimPerforceProject,project_server_id=perforceObject.project_server_id)
        return perforce

    def dispatch(self, request, *args, **kwargs):
        try:
            return super(preforceUpdate,self).dispatch(request, *args, **kwargs)
        except DimPerforceProject.DoesNotExist:
            project_id=self.kwargs['project_id']
            return HttpResponseRedirect(reverse('streams:addperforce', kwargs={'project_id':project_id}))


    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.project_modified_date=datetime.datetime.now()
        self.object.project_modified_by=str(self.request.user)
        self.object.save()
        return super(preforceUpdate, self).form_valid(form)

class sonarUpdate(UpdateView):
    model = DimSonarProduct
    fields = ['product_name','product_key','product_server','product_port']

    def get_object(self, *args, **kwargs):
        sonar=get_object_or_404(DimSonarProduct, product_id=self.kwargs['product_id'], product_project_id=self.kwargs['project_id'])
        return sonar

    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.product_modified_date=datetime.datetime.now()
        self.object.product_modified_by=str(self.request.user)
        self.object.save()
        return super(sonarUpdate, self).form_valid(form)

class swpUpdate(UpdateView):
    model = DimSwpConnectionDetails
    fields = ['oracle_db_username','oracle_db_password','oracle_db_hostname','oracle_db_sid','oracle_db_port_no','unix_server_hostname','unix_server_username','unix_server_password','unix_server_log_files_path']

    def get_object(self, *args, **kwargs):
        swp_object = DimSwpConnectionDetails.objects.get(project=self.kwargs['project_id'])
        swp = get_object_or_404(DimSwpConnectionDetails, swp_connection_details_id=swp_object.swp_connection_details_id)
        swp.oracle_db_password=decrypt("SecretKey", swp.oracle_db_password)
        swp.unix_server_password = decrypt("SecretKey", swp.unix_server_password)
        return swp

    def dispatch(self, request, *args, **kwargs):
        try:
            return super(swpUpdate,self).dispatch(request, *args, **kwargs)
        except DimSwpConnectionDetails.DoesNotExist:
            project_id=self.kwargs['project_id']
            return HttpResponseRedirect(reverse('swp:connect_details', kwargs={'project_id':project_id}))


    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.oracle_db_password = encrypt("SecretKey", self.object.oracle_db_password)
        self.object.unix_server_password = encrypt("SecretKey", self.object.unix_server_password)
        self.object.project_modified_date=datetime.datetime.now()
        self.object.project_modified_by=str(self.request.user)
        self.object.save()
        return super(swpUpdate, self).form_valid(form)

class uploadPerforce(TemplateView):
    template_name='devops_admin/uploadperforce.html'
    def post(self,request):
        return render(request,self.template_name)

@login_required(login_url='login')
def get_products(request,project_id):
    sonar=DimSonarProduct.objects.filter(product_project_id=project_id)
    perforce=DimPerforceProject.objects.get(project_id=project_id)
    sonar_dict = {}
    for product in sonar:
        sonar_dict[product.product_id] = product.product_name
    context = {
        'sonar': sonar,
        'perforce': perforce,
        'sonar_dict':sonar_dict,
    }
    return HttpResponse(json.dumps(sonar_dict))

def update_jenkins_connect(request,project_id):
    try:
        jenkins=DimJenkinsConnectDetails.objects.get(project=project_id)
        template = loader.get_template('devops_admin/update_jenkins_connect.html')
        project = DimProject.objects.get(project_id=project_id)
        context = {
            'project_id': project_id,
            'project_name': project.project_name,
            'jenkins_connect':jenkins,
        }

        return HttpResponse(template.render(context, request))
    except:
        return HttpResponseRedirect(reverse('jenkins:jenkins_connect_details',kwargs={'project_id':project_id}))


def update_jenkins_connect_process(request):
    if "GET" == request.method:
        return render(request, "admin.html")
    elif 'POST' == request.method:
        jenkins_obj=DimJenkinsConnectDetails.objects.get(project_name=request.POST.get('project_name'))
        update_obj = DimJenkinsConnectDetails.objects.get(pk=jenkins_obj.jenkins_connect_details_id)
        update_obj.jenkins_hostname=request.POST.get('jenkins_hostname')
        update_obj.jenkins_port_no=request.POST.get('jenkins_port_no')
        update_obj.project_modified_by=str(request.user)
        update_obj.project_modified_date=datetime.datetime.now()
        update_obj.save()
    return HttpResponseRedirect(reverse("project"))

def update_jenkins_jobs(request,project_id):
    try:
        jenkins=DimJenkinsJobs.objects.filter(project=project_id)
        if(len(jenkins)==0):
            return HttpResponseRedirect(reverse('jenkins:jenkins_connect_details', kwargs={'project_id': project_id}))
        template = loader.get_template('devops_admin/update_jenkins_jobs.html')
        project = DimProject.objects.get(project_id=project_id)
        context = {
            'project_id': project_id,
            'project_name': project.project_name,
            'jenkins_jobs':jenkins,
        }

        return HttpResponse(template.render(context, request))
    except:
        return HttpResponseRedirect(reverse('jenkins:jenkins_connect_details',kwargs={'project_id':project_id}))

def update_jenkins_job_process(request):
    if "GET" == request.method:
        return render(request, "admin.html")
    elif 'POST' == request.method:
        jenkins_objects_list=DimJenkinsJobs.objects.filter(project_name=request.POST.get('project_name'))
        for jenkins_obj in jenkins_objects_list:
            update_obj = DimJenkinsJobs.objects.get(pk=jenkins_obj.job_id)
            update_obj.job_name=str(request.POST.get(jenkins_obj.job_name))
            update_obj.project_modified_by=str(request.user)
            update_obj.project_modified_date=datetime.datetime.now()
            update_obj.save()
    return HttpResponseRedirect(reverse("project"))


class admin_view(TemplateView):
    template_name='devops_admin/admin_page.html'
    def get(self, request, *args, **kwargs):
        if len(DimAdminUsers.objects.filter(admin_username=request.user))!=0:
            user=DimAdminUsers.objects.get(admin_username=request.user)
            if user.admin_rights is True:
                projects=DimProject.objects.all()
                context={
                    'projects':projects,
                }
                return render(request, self.template_name, context)
            else:
                messages.error(request,"Sorry!! You do not have access to this page.")
                return HttpResponseRedirect(reverse("project"))
        else:
            messages.error(request,"Sorry!! You do not have access to this page.")
            return HttpResponseRedirect(reverse("project"))

@login_required(login_url='login')
def upload_factproject_csv(request):
    if "GET" == request.method:
        return HttpResponseRedirect(reverse("project"))
    try:
        csv_file = request.FILES["csv_file1"]
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'File is not CSV type')
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        if csv_file.multiple_chunks():
            messages.error(request, "Uploaded file is too big")
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        path = default_storage.save('project.csv', ContentFile(csv_file.read()))
        reader = csv.DictReader(open(path, 'r'))
        dic_list = []
        for line in reader:
            dic_list.append(dict(line))
        for data in dic_list:
            if len(data)==4:
                data["project_creation_date"]=datetime.datetime.now()
                data["project_created_by"]=request.user
                if len(DimProject.objects.filter(project_name=data['project_name']))==0:
                    try:
                        form = DimProjectForm(data)
                        if form.is_valid():
                            form.save(commit=True)
                        else:
                            messages.warning(request, 'Form is invalid, Required fields are empty for project : '+str(data['project_name']))
                            pass
                    except Exception as e:
                        messages.error(request, 'Fields are incomplete for project'+str(data['project_name']))
                        pass
                else:
                    messages.warning(request,'Project '+str(data['project_name'])+' already exist in database!!')

    except Exception:
        messages.error(request,"Unable to upload file.")
        return HttpResponseRedirect(reverse("devops_admin:admin_page"))

    return HttpResponseRedirect(reverse("devops_admin:admin_page"))


@login_required(login_url='login')
def upload_perforce_csv(request):
    if "GET" == request.method:
        return HttpResponseRedirect(reverse("project"))
    try:
        csv_file = request.FILES["csv_file2"]
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'File is not CSV type')
            return HttpResponseRedirect(reverse('devops_admin:admin_page'))
        if csv_file.multiple_chunks():
            messages.error(request, "Uploaded file is too big")
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        path = default_storage.save('perforce.csv', ContentFile(csv_file.read()))
        reader = csv.DictReader(open(path, 'r'))
        dic_list = []
        for line in reader:
            dic_list.append(dict(line))
        for data in dic_list:
            if len(data)==3:
                data['project_user'] = 'DevopsDash'
                data["project_password"] = encrypt("SecretKey", '2~QdNc_5')
                data["project_creation_date"] = datetime.datetime.now()
                data["project_created_by"] = request.user
                if len(DimPerforceProject.objects.filter(project_name=data['project_name']))==0:
                    if len(DimProject.objects.filter(project_name=data['project_name']))!=0:
                        query = DimProject.objects.get(project_name=data['project_name'])
                        data["project"] = query.project_id
                        try:
                            form = DimPerforceProjectForm(data)
                            if form.is_valid():
                                form.save(commit=True)
                            else:
                                messages.warning(request, 'Form is invalid, Required fields are empty for project : '+ str(data['project_depot']))
                                pass
                        except Exception as e:
                            messages.error(request, 'Fields are incomplete for project' + str(data['project_depot']))
                            pass
                    else:
                        messages.error(request,'Depot ' + str(data['project_depot']) + ' is not present in database!!')
                else:
                    messages.warning(request, 'Perforce details for project ' + str(data['project_depot']) + ' already exist in database!!')

    except Exception as e:
        print (e)
        messages.error(request, "Unable to upload file.")
        return HttpResponseRedirect(reverse("devops_admin:admin_page"))

    return HttpResponseRedirect(reverse("devops_admin:admin_page"))

#return HttpResponseRedirect(reverse("streams:addperforce", kwargs={'project_id':project_id}))



@login_required(login_url='login')
def processDetails(request):
    if "GET" == request.method:
        return render(request, "devops_admin/admin_page.html")
    elif 'POST'==request.method:
        project_form=dict()
        project_form['project_name']=request.POST.get('project_name')
        project_form['project_division']=request.POST.get('project_division')
        project_form['project_head']=request.POST.get('project_head')
        project_form['project_phase']=request.POST.get('project_phase')
        project_form['project_creation_date']=datetime.datetime.now()
        project_form['project_created_by']=str(request.user)
        if len(DimProject.objects.filter(project_name=project_form['project_name'])) == 0:
            try:
                form = DimProjectForm(project_form)
                if form.is_valid():
                    form.save(commit=True)
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(project_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(project_form['project_name']))
                pass
        else:
            messages.warning(request, 'Project ' + str(project_form['project_name']) + ' already exist in database!!')
        if request.POST.get('product_name')!='':
            sonar_form={}
            sonar_form['product_project_name']=request.POST.get('project_name')
            sonar_form['product_name']=request.POST.get('product_name')
            sonar_form['product_key']=request.POST.get('product_key')
            sonar_form['product_server']=request.POST.get('product_server')
            sonar_form['product_port']=request.POST.get('product_port')
            sonar_form['product_username']='DevopsDash'
            sonar_form['product_password']=encrypt("SecretKey", '2~QdNc_5')
            sonar_form['product_creation_date']=datetime.datetime.now()
            sonar_form['product_created_by']=request.user
            query = DimProject.objects.get(project_name=sonar_form['product_project_name'])
            sonar_form["product_project"] = query.project_id
            try:
                form = DimSonarProductForm(sonar_form)

                if form.is_valid():

                    form.save(commit=True)
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(sonar_form['product_project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(sonar_form['product_project_name']))
                pass
        if request.POST.get('project_server')!='':
            perforce_form={}
            perforce_form['project_server']=request.POST.get('project_server')
            perforce_form['project_depot']=request.POST.get('project_depot')
            perforce_form['project_name']=request.POST.get('project_name')
            perforce_form['project_user']='DevopsDash'
            perforce_form['project_password']=encrypt("SecretKey", '2~QdNc_5')
            perforce_form['project_creation_date']=datetime.datetime.now()
            perforce_form['project_created_by']=request.user
            query = DimProject.objects.get(project_name=perforce_form['project_name'])
            perforce_form["project"] = query.project_id
            try:
                form = DimPerforceProjectForm(perforce_form)
                if form.is_valid():
                    form.save(commit=True)
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(perforce_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(perforce_form['project_name']))
                pass
        if request.POST.get('oracle_db_username')!='':
            swp_form={}
            swp_form['oracle_db_username'] = request.POST.get('oracle_db_username')
            swp_form['oracle_db_password'] = encrypt("SecretKey", request.POST.get('oracle_db_password'))
            swp_form['oracle_db_hostname'] = request.POST.get('oracle_db_hostname')
            swp_form['oracle_db_sid'] = request.POST.get('oracle_db_sid')
            swp_form['oracle_db_username'] = request.POST.get('oracle_db_username')
            swp_form['oracle_db_port_no'] = request.POST.get('oracle_db_port_no')
            swp_form['unix_server_hostname'] = request.POST.get('unix_server_hostname')
            swp_form['unix_server_username'] = request.POST.get('unix_server_username')
            swp_form['unix_server_password'] = encrypt("SecretKey", request.POST.get('unix_server_password'))
            swp_form['unix_server_log_files_path'] = request.POST.get('unix_server_log_files_path')
            swp_form['project_name']=request.POST.get('project_name')
            swp_form['project_creation_date'] = datetime.datetime.now()
            swp_form['project_created_by'] = str(request.user)
            query = DimProject.objects.get(project_name=swp_form['project_name'])
            swp_form["project"] = query.project_id
            try:
                form = DimSwpConnectionDetailsForm(swp_form)
                if form.is_valid():
                    form.save(commit=True)
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(swp_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(swp_form['project_name']))
                pass
        if request.POST.get('jenkins_hostname') != '':
            jenkins_form = {}
            jenkins_form['jenkins_hostname'] = request.POST.get('jenkins_hostname')
            jenkins_form['jenkins_port_no'] = request.POST.get('jenkins_port_no')
            jenkins_form['project_name'] = request.POST.get('project_name')
            jenkins_form['project_creation_date'] = datetime.datetime.now()
            jenkins_form['project_created_by'] = str(request.user)
            query = DimProject.objects.get(project_name=jenkins_form['project_name'])
            jenkins_form["project"] = query.project_id
            try:
                form = DimJenkinsConnectDetailsForm(jenkins_form)
                if form.is_valid():
                    form.save(commit=True)
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(
                        jenkins_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(jenkins_form['project_name']))
                pass

        if request.POST.get('job_name') != '':
            jenkins_job_form = {}
            jenkins_job_form['job_name'] = request.POST.get('job_name')
            jenkins_job_form['project_name'] = request.POST.get('project_name')
            jenkins_job_form['project_creation_date'] = datetime.datetime.now()
            jenkins_job_form['project_created_by'] = str(request.user)
            query = DimProject.objects.get(project_name=jenkins_job_form['project_name'])
            jenkins_job_form["project"] = query.project_id
            try:
                form = DimJenkinsJobsForm(jenkins_job_form)
                if form.is_valid():
                    form.save(commit=True)
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(
                        jenkins_job_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(jenkins_job_form['project_name']))
                pass
        return HttpResponseRedirect(reverse("devops_admin:admin_page"))

@login_required(login_url='login')
def upload_swp_csv(request):
    if "GET" == request.method:
        return HttpResponseRedirect(reverse("project"))
    try:
        csv_file = request.FILES["csv_file3"]
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'File is not CSV type')
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        if csv_file.multiple_chunks():
            print("Uploaded file is too big")
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        path=default_storage.save('swp.csv',ContentFile(csv_file.read()))
        reader=csv.DictReader(open(path,'r'))
        dic_list=[]
        for line in reader:
            dic_list.append(dict(line))

        for data in dic_list:
            if len(data) == 10:
                data['oracle_db_password']= encrypt("SecretKey",data['oracle_db_password'])
                data['unix_server_password'] =encrypt("SecretKey",data['unix_server_password'])
                if len(DimSwpConnectionDetails.objects.filter(project_name=data['project_name'])) == 0:
                    if len(DimProject.objects.filter(project_name=data['project_name'])) != 0:
                        query = DimProject.objects.get(project_name=data['project_name'])
                        data["project"] = query.project_id
                        data["project_creation_date"] = datetime.datetime.now()
                        data["project_created_by"] = request.user
                        try:
                            form = DimSwpConnectionDetailsForm(data)
                            if form.is_valid():
                                form.save(commit=True)
                            else:
                                messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(data['project_name']))
                                pass
                        except Exception as e:
                            messages.error(request, 'Fields are incomplete for project' + str(data['project_name']))
                            pass
                    else:
                        messages.error(request, 'Project ' + str(data['project_name']) + ' is not present in database!!')
                else:
                    messages.warning(request, 'SWP details for project ' + str(
                        data['project_name'] + 1) + ' already exist in database!!')

    except Exception as e:
        print(e)
        print("Unable to upload file.")
        return HttpResponseRedirect(reverse("devops_admin:admin_page"))

    return HttpResponseRedirect(reverse("devops_admin:admin_page"))

@login_required(login_url='login')
def upload_sonar_csv(request):
    if "GET" == request.method:
        return HttpResponseRedirect(reverse("project"))
    try:
        csv_file = request.FILES["csv_file4"]
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'File is not CSV type')
            return HttpResponseRedirect(reverse('devops_admin:admin_page'))
        if csv_file.multiple_chunks():
            messages.error(request, "Uploaded file is too big")
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        path = default_storage.save('sonar.csv', ContentFile(csv_file.read()))
        reader = csv.DictReader(open(path, 'r'))
        dic_list = []
        for line in reader:
            dic_list.append(dict(line))
        for data in dic_list:
            if len(data)==5:
                data['product_username']='DevopsDash'
                data["product_password"] = encrypt("SecretKey", '2~QdNc_5')
                data["product_creation_date"] = datetime.datetime.now()
                data["product_created_by"] = request.user
                if len(DimProject.objects.filter(project_name=data['product_project_name']))!=0:
                    query = DimProject.objects.get(project_name=data['product_project_name'])
                    data["product_project"] = query.project_id
                    try:
                        form = DimSonarProductForm(data)
                        if form.is_valid():
                            form.save(commit=True)
                        else:
                            errors=form.errors.as_json()
                            errors=json.dumps(errors)
                            errors=json.loads(errors)
                            if 'product_key' in errors:
                                messages.error(request,'Dim sonar product with '+ data['product_key']+' Product key already exists.')
                            else:
                                messages.warning(request, 'Form is invalid, Required fields are empty for project : '+ str(data['product_project_name']))
                            pass
                    except Exception as e:
                        messages.error(request, 'Fields are incomplete for project' + str(data['product_project_name']))
                        pass
                else:
                    messages.error(request,'Depot ' + str(data['product_project_name']) + ' is not present in database!!')

    except Exception as e:
        messages.error(request, "Unable to upload file.")
        return HttpResponseRedirect(reverse("devops_admin:admin_page"))

    return HttpResponseRedirect(reverse("devops_admin:admin_page"))

@login_required(login_url='login')
def upload_jenkins_csv(request):
    if "GET" == request.method:
        return HttpResponseRedirect(reverse("project"))
    try:
        csv_file = request.FILES["csv_file5"]
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'File is not CSV type')
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        if csv_file.multiple_chunks():
            print("Uploaded file is too big")
            return HttpResponseRedirect(reverse("devops_admin:admin_page"))
        path=default_storage.save('jenkins.csv',ContentFile(csv_file.read()))
        reader=csv.DictReader(open(path,'r'))
        dic_list=[]
        for line in reader:
            dic_list.append(dict(line))
        for data in dic_list:
            if len(data) == 4:
                data["project_creation_date"]=datetime.datetime.now()
                data["project_created_by"]=request.user
                if len(DimProject.objects.filter(project_name=data['project_name'])) != 0:
                    query = DimProject.objects.get(project_name=data['project_name'])
                    data["project"] = query.project_id
                    if(len(DimJenkinsConnectDetails.objects.filter(project=data['project']))==0):
                        jenkins_connect_data={'jenkins_hostname':data['jenkins_hostname'],'jenkins_port_no':data['jenkins_port_no'],'project_name':data['project_name'],'project_creation_date':data["project_creation_date"],'project_created_by':data["project_created_by"],'project':data['project']}
                        try:
                            form = DimJenkinsConnectDetailsForm(jenkins_connect_data)
                            if form.is_valid():
                                form.save(commit=True)
                            else:
                                messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(data['project_name']))
                                pass
                        except Exception as e:
                            messages.error(request, 'Fields are incomplete for project' + str(e))
                            pass

                    jenkins_job_data={'job_name':data['job_name'],'project_creation_date':data["project_creation_date"],'project_created_by':data["project_created_by"],'project_name':data['project_name'],'project':data['project']}

                    try:
                        form = DimJenkinsJobsForm(jenkins_job_data)
                        if form.is_valid():
                            form.save(commit=True)
                        else:
                            messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(data['project_name']))
                            pass
                    except Exception as e:
                        messages.error(request, 'Fields are incomplete for project' + str(data['project_name']))
                        pass
                else:
                    messages.error(request, 'Project ' + str(data['project_name']) + ' is not present in database!!')


    except Exception as e:
        print(e)
        print("Unable to upload file.")
        return HttpResponseRedirect(reverse("devops_admin:admin_page"))

    return HttpResponseRedirect(reverse("devops_admin:admin_page"))
