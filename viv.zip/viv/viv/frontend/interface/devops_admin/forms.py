from django.forms import ModelForm, modelform_factory
from .models import DimProject, DimPerforceProject, DimSwpConnectionDetails, DimSonarProduct, DimJenkinsConnectDetails, DimJenkinsJobs

class DimProjectForm(ModelForm):
    class Meta:
        model=DimProject
        fields=['project_name','project_division','project_head','project_phase','project_creation_date','project_created_by','project_modified_date','project_modified_by']

class DimPerforceProjectForm(ModelForm):
    class Meta:
        model=DimPerforceProject
        fields=['project_server','project_name','project_depot','project_user','project_password','project_creation_date','project_created_by','project_modified_date','project_modified_by','project']


class DimSwpConnectionDetailsForm(ModelForm):
    class Meta:
        model=DimSwpConnectionDetails
        fields=['oracle_db_username','oracle_db_password','oracle_db_hostname','oracle_db_sid','oracle_db_port_no','unix_server_hostname','unix_server_username','unix_server_password','unix_server_log_files_path','project_creation_date','project_created_by','project_modified_date','project_modified_by','project_name','project']

class DimJenkinsConnectDetailsForm(ModelForm):
    class Meta:
        model=DimJenkinsConnectDetails
        fields=['jenkins_hostname','jenkins_port_no','project_creation_date','project_created_by','project_modified_date','project_modified_by','project_name','project']

class DimJenkinsJobsForm(ModelForm):
    class Meta:
        model=DimJenkinsJobs
        fields=['job_name','project_name','project_creation_date','project_created_by','project_modified_date','project_modified_by','project']


class DimSonarProductForm(ModelForm):
    class Meta:
        model = DimSonarProduct
        fields=['product_project_name','product_name','product_key','product_server','product_port','product_username','product_password','product_creation_date','product_created_by','product_project']
