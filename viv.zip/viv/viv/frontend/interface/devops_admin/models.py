from __future__ import unicode_literals
from django.core.urlresolvers import reverse
from django.db import models

class DimProject(models.Model):
    project_id = models.AutoField(primary_key=True)
    project_name = models.CharField(max_length=255)
    project_division = models.CharField(max_length=50)
    project_head = models.CharField(max_length=255)
    project_phase = models.CharField(max_length=255)
    project_creation_date = models.DateTimeField()
    project_created_by = models.CharField(max_length=255)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=255, blank=True, null=True)

    def get_absolute_url(self):
        return reverse('project')

    class Meta:
        managed = False
        db_table = 'dim_project'

class DimPerforceProject(models.Model):
    project_server_id = models.AutoField(primary_key=True)
    project_server = models.CharField(max_length=255)
    project_name = models.CharField(max_length=255)
    project_depot = models.CharField(max_length=255)
    project_user = models.CharField(max_length=255)
    project_password = models.CharField(max_length=255)
    project_creation_date = models.DateTimeField()
    project_created_by = models.CharField(max_length=255)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=255, blank=True, null=True)
    project = models.ForeignKey('DimProject')

    def get_absolute_url(self):
        return reverse('project')

    class Meta:
        managed = False
        db_table = 'dim_perforce_project'


class DimAdminUsers(models.Model):
    admin_id = models.AutoField(primary_key=True)
    admin_username = models.CharField(max_length=255)
    admin_rights = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'dim_admin_users'

class DimSonarProduct(models.Model):
    product_id = models.AutoField(primary_key=True)
    product_project_name = models.CharField(max_length=255)
    product_name = models.CharField(max_length=255)
    product_key = models.CharField(unique=True, max_length=255)
    product_server = models.CharField(max_length=255)
    product_port = models.IntegerField()
    product_username = models.CharField(max_length=255)
    product_password = models.CharField(max_length=255)
    product_creation_date = models.DateTimeField()
    product_created_by = models.CharField(max_length=255)
    product_modified_date = models.DateTimeField(blank=True, null=True)
    product_modified_by = models.CharField(max_length=255, blank=True, null=True)
    product_project = models.ForeignKey(DimProject)

    def get_absolute_url(self):
        return reverse('project')

    class Meta:
        managed = False
        db_table = 'dim_sonar_product'

class DimSwpConnectionDetails(models.Model):
    swp_connection_details_id = models.AutoField(primary_key=True)
    oracle_db_username = models.CharField(max_length=50)
    oracle_db_password = models.CharField(max_length=50)
    oracle_db_hostname = models.CharField(max_length=50)
    oracle_db_sid = models.CharField(max_length=50)
    oracle_db_port_no = models.IntegerField()
    unix_server_hostname = models.CharField(max_length=50)
    unix_server_username = models.CharField(max_length=50)
    unix_server_password = models.CharField(max_length=50)
    unix_server_log_files_path = models.CharField(max_length=50)
    project_creation_date = models.DateTimeField()
    project_created_by = models.CharField(max_length=255)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=255, blank=True, null=True)
    project_name = models.CharField(max_length=50)
    project = models.ForeignKey(DimProject, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_swp_connection_details'

    def get_absolute_url(self):
        return reverse('project')

class DimJenkinsConnectDetails(models.Model):
    jenkins_connect_details_id = models.AutoField(primary_key=True)
    jenkins_hostname = models.CharField(max_length=50, blank=True, null=True)
    jenkins_port_no = models.IntegerField(blank=True, null=True)
    project_name = models.CharField(max_length=50, blank=True, null=True)
    project_creation_date = models.DateTimeField()
    project_created_by = models.CharField(max_length=255)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=255, blank=True, null=True)
    project = models.ForeignKey('DimProject', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_jenkins_connect_details'

    def get_absolute_url(self):
        return reverse('project')

class DimJenkinsJobs(models.Model):
    job_id = models.AutoField(primary_key=True)
    job_name = models.CharField(max_length=50, blank=True, null=True)
    project_creation_date = models.DateTimeField()
    project_created_by = models.CharField(max_length=255)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=255, blank=True, null=True)
    project_name = models.CharField(max_length=50, blank=True, null=True)
    project = models.ForeignKey('DimProject', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_jenkins_jobs'

class DimModuleThreshold(models.Model):
    threshold_id = models.AutoField(primary_key=True)
    threshold_module_name = models.CharField(max_length=255, blank=True, null=True)
    threshold_metric_name = models.CharField(max_length=255, blank=True, null=True)
    threshold_value = models.IntegerField(blank=True, null=True)
    threshold_color = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_module_threshold'
