from django.conf.urls import include, url
from .views import adminProject
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.views import login, logout
from .settings import LOGOUT_REDIRECT_URL
from .forms import LoginForm

urlpatterns = [
    url(r'^admin/', include('devops_admin.urls', namespace='devops_admin')),
    url(r'^login$',login,{'authentication_form':LoginForm,'template_name':'devops_admin/login.html','redirect_field_name':'/project'}, name='login'),
    url(r'^logout$',logout, {'next_page': LOGOUT_REDIRECT_URL}, name='logout'),
    url(r'^project$', adminProject.as_view(), name='project'),
    url(r'^project/perforce/', include('streams.urls', namespace='streams')),
    url(r'^project/sonar/', include('sonar.urls', namespace='sonar')),
    url(r'^project/swp/', include('swp.urls', namespace='swp')),
    url(r'^project/jenkins/', include('jenkins.urls', namespace='jenkins')),
]
