from django.views.generic import TemplateView
from devops_admin.models import DimProject
from django.shortcuts import render
from django.db.models import Count, Avg,Sum
from streams.models import FactPerforceStatistics
from sonar.models import FactSonarStatistics
from datetime import date
from jenkins.models import FactJenkinsStatistics
from swp.models import FactSwpStatistics
from devops_admin.models import DimJenkinsJobs
from operator import itemgetter

def jenkins_avg_success_rate(week_no):
    jobs_list = DimJenkinsJobs.objects.all()
    jenkins_statistics = FactJenkinsStatistics.objects.filter(week_no=week_no)
    jenkins_jobs = DimJenkinsJobs.objects.all()
    jenkins_project_success_rate = {}
    jenkins_jobs_count = {}
    for jenkins_job in jenkins_jobs:
        jenkins_project_success_rate[jenkins_job.project.project_id] = 0
        jenkins_jobs_count[jenkins_job.project.project_id] = 0

    for jenkins_statistic in jenkins_statistics:
        job = DimJenkinsJobs.objects.get(job_id=jenkins_statistic.job.job_id)
        jenkins_project_success_rate[job.project.project_id] += jenkins_statistic.success_rate
        jenkins_jobs_count[job.project.project_id] += 1

    jenkins_success_rate = 0
    count_project = 0
    for key, value in jenkins_project_success_rate.items():
        if (value != 0):
            jenkins_success_rate += (value / jenkins_jobs_count[key])
            count_project += 1

    jenkins_avg_success_rate = 'No Data'
    if (count_project != 0):
        jenkins_avg_success_rate = int(jenkins_success_rate / count_project)

    return jenkins_avg_success_rate

def swp_avg_success_rate(week_no):
    swp_successful_flows = FactSwpStatistics.objects.filter(week_no=week_no).aggregate(
        Sum('number_of_successful_flow_instances'))
    swp_total_flows = FactSwpStatistics.objects.filter(week_no=week_no).aggregate(Sum('number_of_flow_instances'))

    swp_statististics_projects = FactSwpStatistics.objects.values('project').distinct()
    swp_avg_success_rate = 0
    count_swp = 0
    success_rate='No Data'
    for swp_statististics_project in swp_statististics_projects:
        swp_successful_flows = FactSwpStatistics.objects.filter(week_no=week_no,
                                                                project=swp_statististics_project['project']).aggregate(
            Sum('number_of_successful_flow_instances'))
        swp_total_flows = FactSwpStatistics.objects.filter(week_no=week_no,
                                                           project=swp_statististics_project['project']).aggregate(
            Sum('number_of_flow_instances'))
        if (swp_total_flows['number_of_flow_instances__sum'] is not None):
            swp_success_rate = (swp_successful_flows['number_of_successful_flow_instances__sum'] / swp_total_flows[
                'number_of_flow_instances__sum']) * 100
            count_swp += 1
        else:
            swp_success_rate = 0
        swp_avg_success_rate += swp_success_rate

    if (swp_avg_success_rate != 0):
        success_rate=int(swp_avg_success_rate / count_swp)

    return success_rate

class adminProject(TemplateView):
    def get(self, request):
        projects = DimProject.objects.values('project_id','project_name')
        divisions=DimProject.objects.all().values_list('project_division').annotate(total=Count('project_division')).order_by('project_division')
        divisions=[list(i) for i in divisions]
        project_list=[]
        for each_division in divisions:
            if each_division[0] is not None:
                p_list=DimProject.objects.filter(project_division=each_division[0])
                project_list.append(p_list)
        main_header=[]
        week_no=date.today().isocalendar()[1]
        sonar = FactSonarStatistics.objects.values_list('statistic_blocker_issues').filter(statistic_week_no=week_no).aggregate(Avg('statistic_blocker_issues'))
        if sonar['statistic_blocker_issues__avg'] is not None:
            main_header.append(int(sonar['statistic_blocker_issues__avg']))
        else:
            main_header.append('No Data')
        sonar = FactSonarStatistics.objects.values_list('statistic_critical_issues').filter(statistic_week_no=week_no).aggregate(Avg('statistic_critical_issues'))
        if sonar['statistic_critical_issues__avg'] is not None:
            main_header.append(int(sonar['statistic_critical_issues__avg']))
        else:
            main_header.append('No Data')
        sonar = FactSonarStatistics.objects.values_list('statistic_technical_debt').filter(statistic_week_no=week_no).aggregate(Avg('statistic_technical_debt'))
        if sonar['statistic_technical_debt__avg'] is not None:
            main_header.append(int(sonar['statistic_technical_debt__avg']))
        else:
            main_header.append('No Data')
        perforce = FactPerforceStatistics.objects.values_list('statistic_average_branches').filter(statistic_week_no=week_no).aggregate(Avg('statistic_average_branches'))
        if perforce['statistic_average_branches__avg'] is not None:
            main_header.append(int(perforce['statistic_average_branches__avg']))
        else:
            main_header.append('No Data')
        perforce = FactPerforceStatistics.objects.values_list('statistic_average_active_branches').filter(statistic_week_no=week_no).aggregate(Avg('statistic_average_active_branches'))
        if perforce['statistic_average_active_branches__avg'] is not None:
            main_header.append(int(perforce['statistic_average_active_branches__avg']))
        else:
            main_header.append('No Data')

        main_header.append(jenkins_avg_success_rate(week_no))

        main_header.append(swp_avg_success_rate(week_no))


        division_perforce_statistics=[]
        division_sonar_statistics = []
        division_jenkins_statistics = []
        division_swp_statistics = []
        project_statistics=[]
        for each_division in project_list:
            temp_project=[]
            perforce_list, sonar_list=[], []
            jenkins_list,swp_list=[],  []
            for each_project in each_division:
                temp_each_project = []
                metric_value=FactPerforceStatistics.objects.values_list('statistic_average_active_branches').filter(statistic_project_id=each_project.project_id,statistic_week_no=week_no)
                if len(metric_value)>0:
                    temp_each_project+=[int(metric_value[0][0])]
                    perforce_list.append(int(metric_value[0][0]))
                else:
                    temp_each_project+=['No Data']
                metric_value=FactSonarStatistics.objects.values_list('statistic_technical_debt').filter(statistic_project_id=each_project.project_id,statistic_week_no=week_no)
                if len(metric_value)>0:
                    metric_value=[val[0] for val in metric_value]
                    temp_each_project+=[int(sum(metric_value))]
                    sonar_list.append(sum(metric_value))
                else:
                    temp_each_project+=['No Data']

                jenkins_job_list=DimJenkinsJobs.objects.filter(project=each_project.project_id)
                jenkins_statistics_project=0
                count_jobs=0
                jenkins_all_jobs_success_rate=0
                for jenkins_job in jenkins_job_list:
                    job_statistics=FactJenkinsStatistics.objects.values_list('success_rate').filter(job=jenkins_job.job_id,week_no=week_no)
                    if(len(job_statistics)>0):
                        count_jobs+=1
                        jenkins_all_jobs_success_rate+=job_statistics[0][0]

                if(len(jenkins_job_list)>0 and count_jobs!=0):
                    jenkins_statistics_project=int(jenkins_all_jobs_success_rate/count_jobs)
                    temp_each_project += [jenkins_statistics_project]
                    jenkins_list.append(jenkins_statistics_project)
                else:
                    temp_each_project+=['No Data']


                swp_successful_flows = FactSwpStatistics.objects.filter(project=each_project.project_id,week_no=week_no).aggregate(Sum('number_of_successful_flow_instances'))
                swp_total_flows = FactSwpStatistics.objects.filter(project=each_project.project_id,week_no=week_no).aggregate(
                    Sum('number_of_flow_instances'))
                if (swp_total_flows['number_of_flow_instances__sum'] is not None):
                    swp_success_rate = int((swp_successful_flows['number_of_successful_flow_instances__sum'] /swp_total_flows['number_of_flow_instances__sum'])*100)
                    temp_each_project += [swp_success_rate]
                    swp_list.append(swp_success_rate)
                else:
                    temp_each_project+=['No Data']

                temp_project.append(temp_each_project)

            if len(perforce_list)!=0:
                division_perforce_statistics.append(int(sum(perforce_list)/len(perforce_list)))
            else:
                division_perforce_statistics.append('No Data')
            if len(sonar_list)!=0:
                division_sonar_statistics.append(int(sum(sonar_list)/len(sonar_list)))
            else:
                division_sonar_statistics.append('No Data')
            if len(jenkins_list)!=0:
                division_jenkins_statistics.append(int(sum(jenkins_list)/len(jenkins_list)))
            else:
                division_jenkins_statistics.append('No Data')
            if len(swp_list)!=0:
                division_swp_statistics.append(int(sum(swp_list)/len(swp_list)))
            else:
                division_swp_statistics.append('No Data')
            project_statistics.append(temp_project)

        temp_week_no=week_no
        perforce_modal=[]
        sonar_modal=[]
        jenkins_modal=[]
        swp_modal=[]

        for each_week in range(4):
            temp_perforce_modal1=FactPerforceStatistics.objects.values('statistic_average_branches').filter(statistic_week_no=temp_week_no).aggregate(Avg('statistic_average_branches'))
            temp_perforce_modal2=FactPerforceStatistics.objects.values('statistic_average_active_branches').filter(statistic_week_no=temp_week_no).aggregate(Avg('statistic_average_active_branches'))
            temp_sonar_modal1=FactSonarStatistics.objects.values('statistic_blocker_issues').filter(statistic_week_no=temp_week_no).aggregate(Avg('statistic_blocker_issues'))
            temp_sonar_modal2=FactSonarStatistics.objects.values('statistic_critical_issues').filter(statistic_week_no=temp_week_no).aggregate(Avg('statistic_critical_issues'))
            temp_sonar_modal3=FactSonarStatistics.objects.values('statistic_technical_debt').filter(statistic_week_no=temp_week_no).aggregate(Avg('statistic_technical_debt'))
            jenkins_modal.append([temp_week_no,jenkins_avg_success_rate(temp_week_no)])
            swp_modal.append([temp_week_no,swp_avg_success_rate(temp_week_no)])
            perforce_modal.append([temp_week_no,temp_perforce_modal1['statistic_average_branches__avg'],temp_perforce_modal2['statistic_average_active_branches__avg']])
            sonar_modal.append([temp_week_no,temp_sonar_modal1['statistic_blocker_issues__avg'],temp_sonar_modal2['statistic_critical_issues__avg'],temp_sonar_modal3['statistic_technical_debt__avg']])
            temp_week_no-=1
        for each_week in perforce_modal:
            for each_data in range(len(each_week)):
                if each_week[each_data] is not None or isinstance(each_week[each_data], str):
                    each_week[each_data]=int(each_week[each_data])
                else:
                    each_week[each_data] = 'No Data'
        for each_week in sonar_modal:
            for each_data in range(len(each_week)):
                if each_week[each_data] is not None or isinstance(each_week[each_data], str):
                    each_week[each_data]=int(each_week[each_data])
                else:
                    each_week[each_data]='No Data'
        context={
            'projects': projects,
            'divisions':divisions,
            'project_list':project_list,
            'main_header':main_header,
            'division_perforce_statistics':division_perforce_statistics,
            'division_sonar_statistics':division_sonar_statistics,
            'division_swp_statistics':division_swp_statistics,
            'division_jenkins_statistics':division_jenkins_statistics,
            'project_statistics':project_statistics,
            'perforce_modal':perforce_modal,
            'sonar_modal':sonar_modal,
            'jenkins_modal':jenkins_modal,
            'swp_modal':swp_modal,
        }
        return render(request,'devops_admin/admin.html',context)
    def post(self,request):
        selected=request.POST['project']



