from django import template

register=template.Library()

@register.filter
def index(List, i):
    return List[int(i)]

@register.filter
def days_to_years(number_of_days):
    year = int(number_of_days / 365)
    week = int((number_of_days % 365) /7)
    days = (number_of_days % 365) % 7
    if year==0 and week!=0:
        return str(week)+' Weeks, '+str(days)+' Days'
    if year==0 and week==0:
        return str(days)+' Days'

    return str(year)+' Years, '+str(week)+' Weeks, '+str(days)+' Days'

@register.filter
def year(year):
    return year.date()