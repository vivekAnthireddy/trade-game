from django.conf.urls import url
from . import views
from django.contrib.auth.decorators import login_required, permission_required

app_name = 'streams'

urlpatterns = [
    url(r'^(?P<project_id>[0-9]+)/$',views.project,name='perforce'),
    url(r'^(?P<project_id>[0-9]+)/display/', views.display, name='display'),
    url(r'^(?P<project_id>[0-9]+)/addperforce/', login_required(views.addPerforceDetails.as_view(),login_url='login'),name='addperforce'),
]
