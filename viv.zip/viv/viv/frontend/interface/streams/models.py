from __future__ import unicode_literals
from django.db import models
from devops_admin.models import DimProject

class FactProjectStream(models.Model):
    project_id = models.AutoField(primary_key=True)
    project_name = models.CharField(max_length=255)
    project_last_update = models.DateTimeField(blank=True, null=True)
    project_branches = models.IntegerField(blank=True, null=True)
    project_active_branches = models.IntegerField(blank=True, null=True)
    project_max_depth = models.IntegerField(blank=True, null=True)
    project_main = models.ForeignKey(DimProject)

    class Meta:
        managed = False
        db_table = 'fact_project_stream'


class FactStream(models.Model):
    stream_id = models.IntegerField(primary_key=True)
    stream_path = models.CharField(max_length=255)
    stream_update = models.DateTimeField()
    stream_owner = models.CharField(max_length=255)
    stream_name = models.CharField(max_length=255)
    stream_parent = models.IntegerField()
    stream_type = models.CharField(max_length=30)
    stream_base_parent = models.CharField(max_length=255)
    stream_creation = models.DateTimeField()
    stream_active_flag = models.IntegerField()
    stream_alive_time = models.IntegerField()
    stream_level = models.IntegerField()
    stream_project = models.ForeignKey(DimProject)

    class Meta:
        managed = False
        db_table = 'fact_stream'

class FactPerforceStatistics(models.Model):
    statistic_id = models.AutoField(primary_key=True)
    statistic_project_name = models.CharField(max_length=255)
    statistic_week_no = models.IntegerField(blank=True, null=True)
    statistic_start_date = models.DateTimeField(blank=True, null=True)
    statistic_end_date = models.DateTimeField(blank=True, null=True)
    statistic_average_branches = models.FloatField(blank=True, null=True)
    statistic_average_active_branches = models.FloatField(blank=True, null=True)
    statistic_average_max_depth = models.FloatField(blank=True, null=True)
    statistic_project = models.ForeignKey(DimProject)

    class Meta:
        managed = False
        db_table = 'fact_perforce_statistics'
