from django.shortcuts import render
from .models import FactStream, FactProjectStream, FactPerforceStatistics
from devops_admin.models import DimPerforceProject, DimProject, DimAdminUsers
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.views.generic import TemplateView, ListView
from django.views.generic.edit import CreateView
from django.utils.datastructures import MultiValueDictKeyError
from django.contrib.auth.decorators import login_required
import datetime
from django.contrib import messages
from django.core.urlresolvers import reverse
from devops_admin.views import encrypt

class addPerforceDetails(CreateView):
    model=DimPerforceProject
    fields = ['project_server', 'project_depot']

    def dispatch(self, request, *args, **kwargs):
        user=request.user
        permission=DimAdminUsers.objects.filter(admin_username=user)
        if len(permission)!=0:
            permission = DimAdminUsers.objects.get(admin_username=user)
            if permission.admin_rights==False:
                messages.error(self.request, 'Sorry! You do not have permission to add connection details')
                return HttpResponseRedirect(reverse("project"))
            else:
                return super(addPerforceDetails, self).dispatch(request, *args, **kwargs)
        else:
            messages.error(self.request, 'Sorry! You do not have permission to add connection details')
            return HttpResponseRedirect(reverse("project"))

    def get_context_data(self, **kwargs):
        context = super(addPerforceDetails, self).get_context_data(**kwargs)
        context['project_id'] = self.kwargs['project_id']
        return context

    def form_valid(self, form):
        self.object = form.save(commit=False)
        pid = self.kwargs['project_id']
        project_name = DimProject.objects.get(project_id=pid)
        self.object.project = project_name
        project_name = project_name.project_name
        self.object.project_name=project_name
        self.object.project_user='DevopsDash'
        self.object.project_password = encrypt("SecretKey", '2~QdNc_5')
        self.object.project_creation_date=datetime.datetime.now()
        self.object.project_created_by=str(self.request.user)
        self.object.save()
        return super(addPerforceDetails, self).form_valid(form)



def project(request,project_id):
    perforce=DimPerforceProject.objects.filter(project_id=project_id)
    if len(perforce)==0:
        return HttpResponseRedirect('addperforce')
    try:
        project = FactProjectStream.objects.filter(project_main=project_id).order_by('-project_last_update')
        project=project[0]
        streams = FactStream.objects.filter(stream_project=project_id)
        week_statistics=FactPerforceStatistics.objects.filter(statistic_project_id=project_id).order_by('-statistic_week_no')[:4]
        context ={
            'project': project,
            'streams': streams,
            'week_statistics':week_statistics
        }
    except FactProjectStream.DoesNotExist:
        raise Http404("Stream Details are not available.")
    except IndexError:
        raise Http404("Stream Details are not available.")
    return render(request, 'streams/project.html', context)

def index(request, project_id):
    try:
        project = FactProjectStream.objects.filter(project_main=project_id).order_by('-project_last_update')[0]
    except FactProjectStream.DoesNotExist:
        raise Http404("Project does not exist")
    active_streams = FactStream.objects.filter(stream_project=project_id, stream_active_flag=1)
    image = "streams/active_" + project_id + "_all.png"
    title="All Active Branches"
    return render(request, 'streams/stream.html', {'project': project, 'image':image, 'title':title,'active_streams': active_streams})

def display(request, project_id):
    try:
        project = FactProjectStream.objects.filter(project_main=project_id).order_by('-project_last_update')[0]
    except FactProjectStream.DoesNotExist:
        raise Http404("Project does not exist")
    active_streams = FactStream.objects.filter(stream_project=project_id,stream_active_flag=1)
    try:
        selected=request.POST['type']
    except MultiValueDictKeyError:
        selected='all'
    image="streams/active_"+project_id+"_"+selected+".png"
    title=selected.capitalize()+" Branches"
    return render(request, 'streams/stream.html', {'active_streams': active_streams, 'image':image, 'title':title, 'project':project})
