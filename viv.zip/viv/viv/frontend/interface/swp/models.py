from __future__ import unicode_literals
from django.db import models
from django.core.urlresolvers import reverse
from devops_admin.models import DimProject,DimSwpConnectionDetails



class FactSwpFlows(models.Model):
    flow_id = models.IntegerField(primary_key=True)
    flow_name = models.CharField(max_length=50, blank=True, null=True)
    flow_start_date = models.DateTimeField(blank=True, null=True)
    flow_end_date = models.DateTimeField(blank=True, null=True)
    flow_duration = models.TextField(blank=True, null=True)  # This field type is a guess.
    flow_status = models.CharField(max_length=20, blank=True, null=True)
    project = models.ForeignKey('devops_admin.DimProject', blank=True, null=True)
    flow_event_id = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_swp_flows'


class FactSwpStreams(models.Model):
    stream_id = models.AutoField(primary_key=True)
    stream_name = models.CharField(max_length=50, blank=True, null=True)
    stream_start_time = models.DateTimeField(blank=True, null=True)
    stream_end_time = models.DateTimeField(blank=True, null=True)
    stream_duration = models.TextField(blank=True, null=True)  # This field type is a guess.
    stream_status = models.CharField(max_length=20, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    flow = models.ForeignKey(FactSwpFlows, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_swp_streams'


class FactSwpJobs(models.Model):
    job_id = models.AutoField(primary_key=True)
    job_name = models.CharField(max_length=50, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    job_start_time = models.DateTimeField(blank=True, null=True)
    job_end_time = models.DateTimeField(blank=True, null=True)
    job_duration = models.TextField(blank=True, null=True)  # This field type is a guess.
    job_status = models.CharField(max_length=20, blank=True, null=True)
    stream = models.ForeignKey('FactSwpStreams', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_swp_jobs'

class FactSwpStatistics(models.Model):
    swp_statistics_id = models.AutoField(primary_key=True)
    week_no = models.IntegerField(blank=True, null=True)
    week_start_date = models.DateTimeField(blank=True, null=True)
    week_end_date = models.DateTimeField(blank=True, null=True)
    flow_name = models.CharField(max_length=255, blank=True, null=True)
    number_of_flow_instances = models.IntegerField(blank=True, null=True)
    number_of_successful_flow_instances = models.IntegerField(blank=True, null=True)
    average_duration = models.TextField(blank=True, null=True)  # This field type is a guess.
    failed_jobs = models.CharField(max_length=255, blank=True, null=True)
    project = models.ForeignKey('devops_admin.DimProject', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_swp_statistics'