from django import template
from datetime import timedelta
from swp.models import FactSwpStatistics

register=template.Library()

@register.filter
def index(List, i):
    return List[int(i)]


@register.filter
def year(year):
    return year.date()

@register.filter
def duration(duration):
    if duration is not None:
        return duration -timedelta(microseconds=duration.microseconds)
    return duration

@register.simple_tag
def arrow(flow_name,start_date,duration):
    next_week_flow=FactSwpStatistics.objects.filter(flow_name=flow_name,week_start_date=start_date+timedelta(days=-7))
    if(len(next_week_flow)!=0):
        for flow in next_week_flow:
            if(flow.average_duration>duration):
                return 'fas fa-arrow-circle-down'
            elif(flow.average_duration<duration):
                return 'fas fa-arrow-circle-up'
            else:
                return 'fas fa-arrows-alt-h'
    else:
        return 'fas fa-arrows-alt-h'