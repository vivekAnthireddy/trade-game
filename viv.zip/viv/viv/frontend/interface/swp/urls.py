from django.conf.urls import include, url
from . import views
from django.contrib.auth.decorators import login_required

urlpatterns = [
    url(r'^(?P<project_id>[0-9]+)/$',views.weekly_flows,name='weekly_flows'),
    url(r'^(?P<project_id>[0-9]+)/streams/(?P<flow_id>[0-9]+)/display$',views.streams_display,name='streams'),
    url(r'^(?P<project_id>[0-9]+)/add_swp_connect_details/$', login_required(views.add_swp_connect_details.as_view(),login_url='login'),name='connect_details'),
]
