from django.http import HttpResponse,Http404,HttpResponseRedirect
from django.template import loader
from .models import FactSwpFlows,FactSwpStreams,FactSwpStatistics
from devops_admin.models import DimProject,DimSwpConnectionDetails,DimAdminUsers
from django.utils.timezone import timedelta
from datetime import date,datetime
from django.views.generic.edit import CreateView
from devops_admin.views import encrypt
from django.contrib import messages
from django.core.urlresolvers import reverse

def week_range(date):
    year, week, dow = date.isocalendar()
    start_date = date - timedelta(dow-1)
    end_date = start_date + timedelta(6)
    return (start_date, end_date)

def weekly_flows(request,project_id):
    try:
        DimSwpConnectionDetails.objects.get(project=project_id)
        DimProject.objects.get(pk=project_id)
        count=1
        time = date.today()
        start_date, end_date = week_range(time)
        all_weeks_data=[]
        while count<=4:
            weeks_data=[]
            start_date = datetime.combine(start_date, datetime.min.time())
            week_data=FactSwpStatistics.objects.filter(project=project_id,week_start_date=start_date)
            for flow in week_data:
                flow_statistics={}
                flow_statistics['flow_statistic_obj']=flow
                flow_objects=FactSwpFlows.objects.filter(flow_name=flow.flow_name,project_id=project_id,flow_start_date__gte=start_date)
                flow_statistics['flow_objects']=flow_objects
                weeks_data.append(flow_statistics)
            all_weeks_data.append(weeks_data)
            start_date = start_date + timedelta(days=-7)
            count=count+1
        template = loader.get_template('swp/weekly_flows.html')
        context = {
            'all_weeks_data':all_weeks_data,
        }
    except DimProject.DoesNotExist:
        raise Http404("Project Doesn't exist")
    except DimSwpConnectionDetails.DoesNotExist:
        return HttpResponseRedirect('add_swp_connect_details')
    return HttpResponse(template.render(context, request))

def streams_display(request,project_id,flow_id):
    all_streams=FactSwpStreams.objects.filter(flow_id=flow_id)
    flow=FactSwpFlows.objects.get(flow_id=flow_id)
    context={
        'all_streams':all_streams,
        'flow':flow,
    }
    template = loader.get_template('swp/streams_display.html')
    return HttpResponse(template.render(context, request))

class add_swp_connect_details(CreateView):
    model=DimSwpConnectionDetails
    fields = ['oracle_db_username','oracle_db_password','oracle_db_hostname','oracle_db_sid','oracle_db_port_no','unix_server_hostname','unix_server_username','unix_server_password','unix_server_log_files_path']

    def dispatch(self, request, *args, **kwargs):
        user=request.user
        permission=DimAdminUsers.objects.filter(admin_username=user)
        if len(permission)!=0:
            permission = DimAdminUsers.objects.get(admin_username=user)
            if permission.admin_rights==False:
                messages.error(self.request, 'Sorry! You do not have permission to add connection details')
                return HttpResponseRedirect(reverse("project"))
            else:
                return super(add_swp_connect_details, self).dispatch(request, *args, **kwargs)
        else:
            messages.error(self.request, 'Sorry! You do not have permission to add connection details')
            return HttpResponseRedirect(reverse("project"))

    def form_valid(self, form):
        self.object = form.save(commit=False)
        pid = self.kwargs['project_id']
        self.object.project=DimProject.objects.get(project_id=pid)
        self.object.project_name =self.object.project.project_name
        self.object.oracle_db_password = encrypt("SecretKey", self.object.oracle_db_password)
        self.object.unix_server_password = encrypt("SecretKey", self.object.unix_server_password)
        self.object.project_creation_date=datetime.now()
        self.object.project_created_by=str(self.request.user)
        self.object.save()
        return super(add_swp_connect_details, self).form_valid(form)

    def get_initial(self):
        pid = self.kwargs['project_id']
        return {'unix_server_log_files_path':'TWS/stdlist/logs'}

    def get_context_data(self, **kwargs):
        context = super(add_swp_connect_details, self).get_context_data(**kwargs)
        context['project_id'] = self.kwargs['project_id']
        return context





