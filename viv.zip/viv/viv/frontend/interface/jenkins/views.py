from devops_admin.models import DimJenkinsConnectDetails,DimProject,DimJenkinsJobs,DimAdminUsers
from devops_admin.forms import DimJenkinsConnectDetailsForm,DimJenkinsJobsForm
from .models import FactJenkinsStatistics
from django.http import HttpResponse,Http404,HttpResponseRedirect
from django.template import loader
from django.views.generic.edit import CreateView
from django.utils.timezone import timedelta
from datetime import date,datetime
from django.contrib import messages
from django.shortcuts import render
from django.core.urlresolvers import reverse
from devops_admin.views import encrypt
# Create your views here

def week_range(date):
    year, week, dow = date.isocalendar()
    start_date = date - timedelta(dow-1)
    end_date = start_date + timedelta(6)
    return (start_date, end_date)

def weekly_builds(request,project_id):
    try:
        DimProject.objects.get(pk=project_id)
        DimJenkinsConnectDetails.objects.get(project_id=project_id)
        jobs=DimJenkinsJobs.objects.filter(project=project_id)
        all_jobs_data=[]
        for job in jobs:
            job_dict={}
            job_dict['my_job_name']=job.job_name
            all_weeks_data=[]
            count=1
            time = date.today()
            start_date, end_date = week_range(time)
            while(count<=4):
                start_date = datetime.combine(start_date, datetime.min.time())
                week_data=FactJenkinsStatistics.objects.filter(week_start_date=start_date,job_id=job.job_id)
                if(len(week_data)!=0):
                    all_weeks_data.append(week_data)
                start_date=start_date+timedelta(days=-7)
                count=count+1
            job_dict['all_weeks_data']=all_weeks_data
            all_jobs_data.append(job_dict)
        template = loader.get_template('jenkins/weekly_builds.html')
        context = {
            'all_jobs_data': all_jobs_data,
        }
    except DimProject.DoesNotExist:
        raise Http404("Project Doesn't exist")
    except DimJenkinsConnectDetails.DoesNotExist:
        return HttpResponseRedirect('jenkins_connect_details')
    return HttpResponse(template.render(context, request))


class add_jenkins_connect_details(CreateView):
    model = DimJenkinsConnectDetails
    fields = ['jenkins_hostname','jenkins_port_no']


    def get_context_data(self, **kwargs):
        context=super(add_jenkins_connect_details,self).get_context_data(**kwargs)
        context['project_id']=self.kwargs['project_id']
        return context

    def form_valid(self, form):
        self.object = form.save(commit=False)
        pid = self.kwargs['project_id']
        self.object.project=DimProject.objects.get(project_id=pid)
        self.object.project_name=self.object.project.project_name
        self.object.project_creation_date=datetime.now()
        self.object.project_created_by=str(self.request.user)
        self.object.save()
        return super(add_jenkins_connect_details, self).form_valid(form)


def jenkins_connect_details(request,project_id):
    template=loader.get_template('jenkins/add_jenkins_connect.html')
    user = request.user
    permission = DimAdminUsers.objects.filter(admin_username=user)
    if len(permission) != 0:
        permission = DimAdminUsers.objects.get(admin_username=user)
        if permission.admin_rights == False:
            messages.error(request, 'Sorry! You do not have permission to add connection details')
            return HttpResponseRedirect(reverse("project"))
        else:
            project = DimProject.objects.get(project_id=project_id)
            context = {
                'project_id': project_id,
                'project_name': project.project_name,
            }
            return HttpResponse(template.render(context, request))
    else:
        messages.error(request, 'Sorry! You do not have permission to add connection details')
        return HttpResponseRedirect(reverse("project"))


def jenkins_connect_details_process(request):
    if "GET" == request.method:
        return render(request, "admin.html")
    elif 'POST' == request.method:
        if(len(DimJenkinsConnectDetails.objects.filter(project_name=request.POST.get('project_name')))==0):
            jenkins_form = dict()
            jenkins_form['project_name'] = request.POST.get('project_name')
            jenkins_form['jenkins_hostname'] = request.POST.get('jenkins_hostname')
            jenkins_form['jenkins_port_no'] = request.POST.get('jenkins_port_no')
            jenkins_form['project_creation_date'] = datetime.now()
            jenkins_form['project_created_by'] = str(request.user)
            query = DimProject.objects.get(project_name=jenkins_form['project_name'])
            jenkins_form["project"] = query.project_id
            try:
                form = DimJenkinsConnectDetailsForm(jenkins_form)
                if form.is_valid():
                    form.save()
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(jenkins_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(e))
                pass
        count=1
        id="job"+str(count)
        while((request.POST.get(id) is not None)):
            jenkins_job_form = {}
            jenkins_job_form['job_name'] = request.POST.get(id)
            jenkins_job_form['project_name'] = request.POST.get('project_name')
            jenkins_job_form['project_creation_date'] = datetime.now()
            jenkins_job_form['project_created_by'] = str(request.user)
            query = DimProject.objects.get(project_name=jenkins_job_form['project_name'])
            jenkins_job_form["project"] = query.project_id
            try:
                form = DimJenkinsJobsForm(jenkins_job_form)
                if form.is_valid():
                    form.save()
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(
                        jenkins_job_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(e))
                pass
            count=count+1
            id="job"+str(count)

    return HttpResponseRedirect(reverse("project"))