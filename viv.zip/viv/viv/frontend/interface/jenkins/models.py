from django.db import models
from devops_admin.models import DimProject,DimJenkinsJobs
# Create your models here.



class FactJenkinsBuild(models.Model):
    build_id = models.AutoField(primary_key=True)
    build_number = models.IntegerField()
    build_start_time = models.DateTimeField(blank=True, null=True)
    build_duration = models.TextField(blank=True, null=True)  # This field type is a guess.
    build_status = models.CharField(max_length=20, blank=True, null=True)
    job = models.ForeignKey("devops_admin.DimJenkinsJobs")

    class Meta:
        managed = False
        db_table = 'fact_jenkins_build'

class FactJenkinsFailedBuildCulprits(models.Model):
    failed_build_culprit_id = models.AutoField(primary_key=True)
    failed_build_culprit_name = models.CharField(max_length=100, blank=True, null=True)
    build = models.ForeignKey(FactJenkinsBuild, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_jenkins_failed_build_culprits'


class FactJenkinsFailedBuildModules(models.Model):
    failed_build_module_id = models.AutoField(primary_key=True)
    failed_build_module_name = models.CharField(max_length=50, blank=True, null=True)
    build = models.ForeignKey(FactJenkinsBuild, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_jenkins_failed_build_modules'

class FactJenkinsStatistics(models.Model):
    jenkins_statistics_id = models.AutoField(primary_key=True)
    week_no = models.IntegerField(blank=True, null=True)
    week_start_date = models.DateTimeField(blank=True, null=True)
    week_end_date = models.DateTimeField(blank=True, null=True)
    success_rate = models.FloatField(blank=True, null=True)
    successful_builds = models.IntegerField(blank=True, null=True)
    unstable_builds = models.IntegerField(blank=True, null=True)
    failed_builds = models.IntegerField(blank=True, null=True)
    aborted_builds = models.IntegerField(blank=True, null=True)
    failed_products = models.TextField(blank=True, null=True)  # This field type is a guess.
    failed_culprits = models.TextField(blank=True, null=True)
    longest_number_builds_till_fixing_failure = models.IntegerField(blank=True, null=True)
    average_number_builds_till_fixing_failure = models.IntegerField(blank=True, null=True)
    number_of_failed_builds_till_fixing_failure = models.IntegerField(blank=True, null=True)
    avg_duration_to_fix_failure = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_duration_of_failed_builds = models.TextField(blank=True, null=True)  # This field type is a guess.
    longest_duration_to_fix_a_failure = models.TextField(blank=True, null=True)  # This field type is a guess.
    job = models.ForeignKey('devops_admin.DimJenkinsJobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_jenkins_statistics'