from django.conf.urls import include, url
from . import views
from django.contrib.auth.decorators import login_required

urlpatterns = [
    url(r'^(?P<project_id>[0-9]+)/$',views.weekly_builds,name='jenkins_build_statistics'),
    url(r'^(?P<project_id>[0-9]+)/add_jenkins_connect_details/$', views.add_jenkins_connect_details.as_view(),name='jenkins_connect_details'),
    url(r'^(?P<project_id>[0-9]+)/jenkins_connect_details/$', login_required(views.jenkins_connect_details,login_url='login'),name='jenkins_connect_details'),
    url(r'^jenkins_connect_details_process/$', views.jenkins_connect_details_process,name='process_jenkins_connect_details'),

]
