from django import template
from datetime import timedelta

register=template.Library()

@register.filter
def year(year):
    return year.date()

@register.filter
def duration(duration):
    return duration -timedelta(microseconds=duration.microseconds)

@register.simple_tag
def arrow(job,i):
    all_week_data=job['all_weeks_data']
    if(len(all_week_data)>i+1):
        for week_data in all_week_data[i+1]:
            next_week_success_rate=week_data.success_rate
        for week_data in all_week_data[i]:
            this_week_success_rate=week_data.success_rate
        if(next_week_success_rate<this_week_success_rate):
            return "fas fa-arrow-circle-up"
        elif (next_week_success_rate>this_week_success_rate):
            return 'fas fa-arrow-circle-down'
        else:
            return 'fas fa-arrows-alt-h'
    else:
        return 'fas fa-arrows-alt-h'
