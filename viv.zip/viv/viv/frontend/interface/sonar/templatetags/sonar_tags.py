from django import template

register=template.Library()

@register.filter
def index(List, i):
    return List[int(i)]

length=[]
def removezero():
    global length
    length=[i for i in length if i!=0]

@register.simple_tag
def arrow(week_data, len_week_data, i, j):
    global length
    if len(length)==0:
        length=len_week_data
        removezero()
    if week_data[i][j] is not None and isinstance(week_data[i][j],str) is False:
        if i%length[-1]!=length[-1]-1:
            if week_data[i][j]>week_data[i+1][j]:
                return "fas fa-arrow-circle-up"
            elif week_data[i][j]<week_data[i+1][j]:
                return 'fas fa-arrow-circle-down'
            else:
                return 'fas fa-arrows-alt-h'
        return ''
