from django.shortcuts import render
from django.views.generic import TemplateView
from devops_admin.models import DimSonarProduct, DimProject, DimAdminUsers
from .models import FactMetricData, FactIssueData, FactSonarStatistics, DimSonarMetrics, DimSonarIssueMetrics
from devops_admin.forms import DimSonarProductForm
from datetime import datetime, date
from django.template import loader
from django.db.models import Count
from django.http import Http404, HttpResponseRedirect, HttpResponse
from django.views.generic.edit import CreateView
from devops_admin.views import encrypt
from django.contrib import messages
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required

@login_required(login_url='login')
def add_sonar_details(request,project_id):
    template='sonar/add_sonar.html'
    user = request.user
    permission = DimAdminUsers.objects.filter(admin_username=user)
    if len(permission) != 0:
        permission = DimAdminUsers.objects.get(admin_username=user)
        if permission.admin_rights == False:
            messages.error(request, 'Sorry! You do not have permission to add connection details')
            return HttpResponseRedirect(reverse("project"))
        else:
            return render(request, template, {'project_id': project_id})
    else:
        messages.error(request, 'Sorry! You do not have permission to add connection details')
        return HttpResponseRedirect(reverse("project"))

class metric_page(TemplateView):
    template_name='sonar/sonar_page.html'
    def get(self, request, *args, **kwargs):
        project_id=self.kwargs['project_id']
        project=DimProject.objects.get(project_id=project_id)
        product_data=DimSonarProduct.objects.filter(product_project=project_id)
        if len(product_data)==0:
            return HttpResponseRedirect('addsonar')
        week_data=[]
        len_week_data=[]
        issue_statistics=[]
        for product in product_data:
            data=FactSonarStatistics.objects.filter(statistic_project_id=project_id,statistic_product_id=product.product_id).values_list().order_by('-statistic_week_no')[:4]
            len_week_data.append(len(data))
            if len(data)>0:
                data=[list(i) for i in data]
                for each_row in data:
                    temp=[]
                    temp.append(each_row[6:16])
                    issue_statistics.append(each_row[16:23])
                    temp[0].extend(each_row[23:29])
                    week_data.append(temp[0])
        metric_names = DimSonarMetrics.objects.values_list('metric_display_name','metric_units').order_by('metric_id')
        #issue_names=['Unresolved (Number)', 'BLOCKER (Number)', 'CRITICAL (Number)', 'MAJOR (Number)', 'MINOR (Number)', 'INFO (Number)', 'Major Violator (Name)']
        metric_names = [metric[0] + ' (' + metric[1] + ')' for metric in metric_names]
        issue_names = DimSonarIssueMetrics.objects.values_list('metric_display_name','metric_units').order_by('metric_id')
        issue_names = [metric[0] + ' (' + metric[1] + ')' for metric in issue_names]
        week_header=[]
        for i in len_week_data:
            week_no = date.today().isocalendar()[1]
            for j in range(i):
                week_header.append('W-'+str(week_no))
                week_no-=1
        week_header.insert(0, 'Metric')
        week_data=[list(map(int,each_data)) for each_data in week_data]
        issue_data=[]
        for each_week in issue_statistics:
            temp=[]
            for each_data in each_week:
                if each_data is None or isinstance(each_data, str):
                    temp.append(each_data)
                else:
                    temp.append(int(each_data))
            issue_data.append(temp)
        context={
            'project':project,
            'product_data':product_data,
            'len_week_data':len_week_data,
            'week_header':week_header,
            'metric_names':metric_names,
            'week_data':week_data,
            'issue_statistics':issue_data,
            'issue_names':issue_names
        }
        return render(request,self.template_name,context)

def add_sonar_details_process(request,project_id):
    if "GET" == request.method:
        return render(request, "admin.html")
    elif 'POST' == request.method:
        sonar_form = dict()
        query = DimProject.objects.get(project_id=project_id)
        sonar_form['product_project_name'] = query.project_name
        sonar_form['product_server'] = request.POST.get('product_server')
        sonar_form['product_port'] = request.POST.get('product_port')
        sonar_form['product_username'] = 'DevopsDash'
        sonar_form['product_password'] = encrypt("SecretKey", '2~QdNc_5')
        sonar_form['product_creation_date'] = datetime.now()
        sonar_form['product_created_by'] = str(request.user)
        sonar_form["product_project"] = project_id
        product=1
        product_name='product_name1'
        product_key='product_key1'
        while request.POST.get(product_name) is not None:
            sonar_form['product_name'] = request.POST.get(product_name)
            sonar_form['product_key'] = request.POST.get(product_key)
            product+=1
            product_name='product_name'+str(product)
            product_key='product_key'+str(product)
            try:
                form = DimSonarProductForm(sonar_form)
                if form.is_valid():
                    form.save()
                else:
                    messages.warning(request, 'Form is invalid, Required fields are empty for project : ' + str(sonar_form['project_name']))
                    pass
            except Exception as e:
                messages.error(request, 'Fields are incomplete for project' + str(e))
                pass

    return HttpResponseRedirect(reverse("project"))