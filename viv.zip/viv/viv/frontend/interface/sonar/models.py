from __future__ import unicode_literals
from django.core.urlresolvers import reverse
from django.db import models
from devops_admin.models import DimSonarProduct, DimProject


class DimSonarIssueMetrics(models.Model):
    metric_id = models.AutoField(primary_key=True)
    metric_display_name = models.CharField(max_length=255, blank=True, null=True)
    metric_units = models.CharField(max_length=255, blank=True, null=True)
    metric_active_flag = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'dim_sonar_issue_metrics'


class DimSonarMetrics(models.Model):
    metric_id = models.AutoField(primary_key=True)
    metric_display_name = models.CharField(max_length=255, blank=True, null=True)
    metric_units = models.CharField(max_length=255, blank=True, null=True)
    metric_keyword = models.CharField(max_length=255, blank=True, null=True)
    metric_active_flag = models.NullBooleanField()

    class Meta:
        managed = False
        db_table = 'dim_sonar_metrics'

class FactIssueData(models.Model):
    issue_id = models.AutoField(primary_key=True)
    load_date = models.DateField(blank=True, null=True)
    status = models.TextField(blank=True, null=True)
    tags = models.TextField(blank=True, null=True)
    component = models.TextField(blank=True, null=True)
    assignee = models.TextField(blank=True, null=True)
    key = models.TextField(blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    debt = models.TextField(blank=True, null=True)
    effort = models.TextField(blank=True, null=True)
    line = models.TextField(blank=True, null=True)
    creationdate = models.DateTimeField(blank=True, null=True)
    severity = models.TextField(blank=True, null=True)
    author = models.TextField(blank=True, null=True)
    resolution = models.TextField(blank=True, null=True)
    rule = models.TextField(blank=True, null=True)
    project = models.TextField(blank=True, null=True)
    updatedate = models.DateTimeField(blank=True, null=True)
    subproject = models.TextField(blank=True, null=True)
    closedate = models.DateTimeField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    componentid = models.TextField(blank=True, null=True)
    project_0 = models.ForeignKey(DimProject, db_column='project_id')  # Field renamed because of name conflict.
    product = models.ForeignKey(DimSonarProduct)

    class Meta:
        managed = False
        db_table = 'fact_issue_data'


class FactMetricData(models.Model):
    metric_id = models.AutoField(primary_key=True)
    metric_technical_debt = models.FloatField()
    metric_technical_debt_flag = models.NullBooleanField()
    metric_new_technical_debt = models.FloatField()
    metric_new_technical_debt_flag = models.NullBooleanField()
    metric_blocker_issues = models.FloatField()
    metric_blocker_issues_flag = models.NullBooleanField()
    metric_new_blocker_issues = models.FloatField()
    metric_new_blocker_issues_flag = models.NullBooleanField()
    metric_critical_issues = models.FloatField()
    metric_critical_issues_flag = models.NullBooleanField()
    metric_new_critical_issues = models.FloatField()
    metric_new_critical_issues_flag = models.NullBooleanField()
    metric_bugs = models.FloatField()
    metric_bugs_flag = models.NullBooleanField()
    metric_vulnerabilities = models.FloatField()
    metric_vulnerabilities_flag = models.NullBooleanField()
    metric_code_smells = models.FloatField()
    metric_code_smells_flag = models.NullBooleanField()
    metric_issues = models.FloatField()
    metric_issues_flag = models.NullBooleanField()
    metric_new_violations = models.FloatField()
    metric_new_violations_flag = models.NullBooleanField()
    metric_complexity = models.FloatField()
    metric_complexity_flag = models.NullBooleanField()
    metric_unit_tests = models.FloatField()
    metric_unit_tests_flag = models.NullBooleanField()
    metric_unit_test_coverage = models.FloatField()
    metric_unit_test_coverage_flag = models.NullBooleanField()
    metric_lines_of_code = models.FloatField()
    metric_lines_of_code_flag = models.NullBooleanField()
    metric_duplicated_lines = models.FloatField()
    metric_duplicated_lines_flag = models.NullBooleanField()
    metric_last_update = models.DateTimeField(blank=True, null=True)
    metric_product = models.ForeignKey(DimSonarProduct)

    class Meta:
        managed = False
        db_table = 'fact_metric_data'


class FactSonarStatistics(models.Model):
    statistic_id = models.AutoField(primary_key=True)
    statistic_project_name = models.CharField(max_length=255)
    statistic_product_name = models.CharField(max_length=255)
    statistic_week_no = models.IntegerField()
    statistic_start_date = models.DateTimeField(blank=True, null=True)
    statistic_end_date = models.DateTimeField(blank=True, null=True)
    statistic_technical_debt = models.FloatField(blank=True, null=True)
    statistic_new_technical_debt = models.FloatField(blank=True, null=True)
    statistic_blocker_issues = models.FloatField(blank=True, null=True)
    statistic_new_blocker_issues = models.FloatField(blank=True, null=True)
    statistic_critical_issues = models.FloatField(blank=True, null=True)
    statistic_new_critical_issues = models.FloatField(blank=True, null=True)
    statistic_bugs = models.FloatField(blank=True, null=True)
    statistic_vulnerabilities = models.FloatField(blank=True, null=True)
    statistic_code_smells = models.FloatField(blank=True, null=True)
    statistic_issues = models.FloatField(blank=True, null=True)
    statistic_issues_unresolved = models.FloatField(blank=True, null=True)
    statistic_issues_blocker = models.FloatField(blank=True, null=True)
    statistic_issues_critical = models.FloatField(blank=True, null=True)
    statistic_issues_major = models.FloatField(blank=True, null=True)
    statistic_issues_minor = models.FloatField(blank=True, null=True)
    statistic_issues_info = models.FloatField(blank=True, null=True)
    statistic_issues_major_violator = models.CharField(max_length=255, blank=True, null=True)
    statistic_new_violations = models.FloatField(blank=True, null=True)
    statistic_complexity = models.FloatField(blank=True, null=True)
    statistic_unit_tests = models.FloatField(blank=True, null=True)
    statistic_unit_test_coverage = models.FloatField(blank=True, null=True)
    statistic_lines_of_code = models.FloatField(blank=True, null=True)
    statistic_duplicated_lines = models.FloatField(blank=True, null=True)
    statistic_product = models.ForeignKey(DimSonarProduct)
    statistic_project = models.ForeignKey(DimProject)

    class Meta:
        managed = False
        db_table = 'fact_sonar_statistics'