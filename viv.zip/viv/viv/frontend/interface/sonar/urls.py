from django.conf.urls import include, url
from django.contrib.auth.decorators import login_required, permission_required
from .views import metric_page, add_sonar_details, add_sonar_details_process

urlpatterns = [
    url(r'^(?P<project_id>[0-9]+)/$', metric_page.as_view(), name='metric_page'),
    url(r'^(?P<project_id>[0-9]+)/addsonar/$', add_sonar_details,name='addsonar'),
    url(r'^(?P<project_id>[0-9]+)/addsonar/process/$', add_sonar_details_process,name='addsonar_process'),
]