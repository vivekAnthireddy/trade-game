Installation instructions:
1. Install python-3.6.5 i.e. the latest version. 
2. The file requirements.txt has the list of required modules. Run "pip install -r requirements.txt"
3. Install PostgreSQL version 10.
4. Modify the file database/create_user.bat to set the PATH to your Postgres installation so that the script can find psql.
5. Run database/create_user.bat.
6. You will have a database called bakk_dashboard, user - bakk and password - bakk_123 created in your Postgres instance.
7. Modify the file etl/sonar/config/sonar_config.py, function get_login_details to add your NT user/password required for login to sonar.
8. Run etl/sonar/run.bat to load sonar data to your postgres instance.
9. If something does not work, we expect you to fix it.
