
def get_modules_ref_table():
    return {'modules':[{'column_name':'module_name', 'column_type':'varchar(10)'},
                       {'column_name':'sonar_project', 'column_type':'varchar(100)'}]}

def get_developers_ref_table():
    return {'developers':[{'column_name':'developer', 'column_type':'varchar(100)'},
                          {'column_name':'module_name', 'column_type':'varchar(10)'},
                          {'column_name':'scrum_team', 'column_type':'varchar(20)'}]}
