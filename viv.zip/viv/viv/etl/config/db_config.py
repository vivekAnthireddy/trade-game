import os

db_user =os.environ['DB_USER']
db_password =os.environ['DB_PASSWORD']
db_instance =os.environ['DB_INSTANCE']
db_server =os.environ['DB_SERVER']
