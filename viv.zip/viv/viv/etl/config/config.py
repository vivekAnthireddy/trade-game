import os
'''Active Threshold for perdforce streams(in months)'''
perforce_active_stream_threshold=2


path_to_log_file=os.environ['ROOTDIR']+'\etl\log'

