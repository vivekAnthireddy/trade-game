import requests
import json
import time
import re
import logging
import psycopg2
import psycopg2.extras
from datetime import datetime,timedelta
from jenkins_statistics import build_job_statistics
import sys
import db_config
import utils

def get_job_details(logger,conn,project_id):
    '''
    fetching job details from database
    '''
    try:       
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        job_details_query="select job_id,job_name from dim_jenkins_jobs where project_id=%s"
        parameters=[project_id]
        cur.execute(job_details_query,parameters)
        job_id_dict=cur.fetchall()
        conn.commit()
        return job_id_dict
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def get_jenkins_connection_details(logger,conn,project_id):
    '''
    fetching jenkins connection details from database
    '''
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        connect_details_query="select jenkins_hostname,jenkins_port_no from dim_jenkins_connect_details where project_id=%s"
        parameters=[project_id]
        cur.execute(connect_details_query,parameters)
        connection_details=cur.fetchone()
        conn.commit()
        return connection_details
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def get_build_data(json_data,job_id,max_build_number):
    '''
    processing build data from fetched json data
    '''
    build_data=[]
    culprits={}
    failed_modules={}
    for build in json_data['builds']:
        if(build['building'] is False and int(build['number'])>max_build_number):
            data={'NUMBER':build['number'],'START_TIME':time.ctime(build['timestamp']/1000),'STATUS':build['result'],'DURATION':build['duration'],'JOB_ID':job_id}
            build_data.append(data)
            if(build.get('culprits') is not None):
                culprits[build['number']]=[culprit['fullName'] for culprit in build['culprits']]
            failed_modules[build['number']]=get_failed_modules(str(build['actions']))
    return build_data,culprits,failed_modules

def load_build_data_to_db(logger,conn,build_data):
    '''
    build data is pushed to database
    '''
    try:
        cur = conn.cursor()
        for build in build_data:
            SQL="INSERT INTO public.fact_jenkins_build(build_number,build_start_time,build_duration,build_status,job_id) VALUES(%s,%s,%s,%s,%s);"
            parameters=[build['NUMBER'],build['START_TIME'],timedelta(milliseconds=build['DURATION']),build['STATUS'],build['JOB_ID']]
            cur.execute(SQL,parameters)
        conn.commit()
        logger.info("BUILD Data entered successfully...")
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def get_failed_modules(data):
    '''
    failed module data is present in <span> tag in json data.......by matching with regular expression failed modules data is fetched
    '''
    pattern=re.compile(r'<span\b[^>]*>(.*?)</span>')
    failed_modules=[]
    matches=pattern.findall(data)
    for match in matches:
        failed_modules.append(match)
    return failed_modules
        
def get_max_build_from_db(logger,conn,job_id):
    '''
    getting maximum build number from db to append the data fetched later runs
    '''
    try:       
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        max_build_query="select max(build_number) as max_build_number from fact_jenkins_build where job_id=%s"
        parameters=[job_id]
        cur.execute(max_build_query,parameters)
        max_build_number=cur.fetchone()
        conn.commit()
        if max_build_number['max_build_number'] is None:
            max_build_number['max_build_number']=0
        return max_build_number['max_build_number']
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def get_build_id_from_db(logger,conn,build_number,job_id):
    '''
    fetching build id to assign it to failed modules
    '''
    try:       
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        get_build_id_query="select build_id from fact_jenkins_build where job_id=%s and build_number=%s"
        parameters=[job_id,build_number]
        cur.execute(get_build_id_query,parameters)
        build_id=cur.fetchone()
        conn.commit()
        return build_id['build_id']
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def load_failed_build_culprits_to_db(logger,conn,build_data,culprits,job_id):
    '''
    pushing culprit data into database
    '''
    try:
        cur = conn.cursor()
        for build in build_data:
            if(build['STATUS']=='FAILURE'):
                build_id=get_build_id_from_db(logger,conn,build['NUMBER'],job_id)
                if(culprits!={}):
                    for culprit in culprits[build['NUMBER']]:
                        SQL="INSERT INTO public.fact_jenkins_failed_build_culprits(failed_build_culprit_name,build_id) VALUES(%s,%s);"
                        parameters=[culprit,build_id]
                        cur.execute(SQL,parameters)
        conn.commit()                    
        logger.info("CULPRIT Data entered successfully...")
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)


def load_failed_build_modules_to_db(logger,conn,build_data,failed_modules,job_id):
    '''
    Pushing failed module data into database
    '''
    try:
        cur = conn.cursor()
        for build in build_data:
            if(build['STATUS']=='FAILURE'):
                build_id=get_build_id_from_db(logger,conn,build['NUMBER'],job_id)
                for failed_module in failed_modules[build['NUMBER']]:
                    SQL="INSERT INTO public.fact_jenkins_failed_build_modules(failed_build_module_name,build_id) VALUES(%s,%s);"
                    parameters=[failed_module,build_id]
                    cur.execute(SQL,parameters)
        conn.commit()                    
        logger.info("FAILED MODULE Data entered successfully...")
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def get_project_details(logger,conn):
    '''
    getting all project details from postgres database table fact_project
    '''
    try:       
        cur = conn.cursor()
        cur.execute("select project_id from dim_project")
        project_id_list=cur.fetchall()
        conn.commit()
        return project_id_list
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

if __name__== "__main__":
    try:
        program_name="JENKINS"
        log_file_name="jenkins_"+datetime.now().strftime("%d%m%Y%H%M%S")+".log"
        logger=utils.log(program_name,log_file_name)
        conn=utils.create_postgres_connection(db_config.db_user,db_config.db_password,db_config.db_instance,db_config.db_server)
        project_id_list=get_project_details(logger,conn)
        #getting list of projects
        for project_id in project_id_list:
            conn_details=get_jenkins_connection_details(logger,conn,project_id)
            if conn_details is not None:
                job_id_dict=get_job_details(logger,conn,project_id)
                if(len(job_id_dict)!=0):
                    for job in job_id_dict:
                        max_build_number=get_max_build_from_db(logger,conn,job['job_id'])
                        url="http://"+conn_details['jenkins_hostname']+".corp.amdocs.com:"+str(conn_details['jenkins_port_no'])+"/job/"+job['job_name']+"/api/json?depth=1"
                        try:
                            json_data={}
                            json_data=requests.get(url).json()
                        except Exception as error:
                            logger.error(error)
                            continue
                        build_data,culprits,failed_modules=get_build_data(json_data,job['job_id'],max_build_number)
                        load_build_data_to_db(logger,conn,build_data)
                        load_failed_build_culprits_to_db(logger,conn,build_data,culprits,job['job_id'])
                        
                        load_failed_build_modules_to_db(logger,conn,build_data,failed_modules,job['job_id'])
                        
                        build_job_statistics(conn,job)
                        logger.info("Successfully entered statistics data") 
                else:
                    logger.info("NO JOBS for the project id=%s",project_id[0])
            else:
                logger.info("NO connection details for project id=%s",project_id[0])
            logger.info("Finished running program for project id=%s",project_id[0])
    finally:
        if conn is not None:
            conn.close()






