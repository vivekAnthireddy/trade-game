import json
import psycopg2
import psycopg2.extras
from datetime import date,datetime,timedelta
import sys
sys.path.insert(0,'..\\utils')
import utils



def get_number_of_builds(conn,job_id,status,start_date,end_date):
    '''
    fetching the count of builds with given status in a particular week from fact_jenkins_build
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    get_builds_query="select count(*) as number from fact_jenkins_build where job_id=%s and build_start_time>=%s and build_start_time<=%s and build_status=%s;"
    parameters=[job_id,start_date,end_date,status]
    cur.execute(get_builds_query,parameters)
    number_of_builds=cur.fetchone()
    conn.commit()
    return number_of_builds['number']

def get_failed_modules(conn,job_id,start_date,end_date):
    '''
    getting count of failed modules with module name in a particular week
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    failed_modules_query="select count(failed_build_module_name) as number_of_times_module_failed,failed_build_module_name from fact_jenkins_failed_build_modules where build_id in (select build_id from fact_jenkins_build where build_start_time>=%s and build_start_time<=%s and job_id=%s) group by failed_build_module_name;"
    parameters=[start_date,end_date,job_id]
    cur.execute(failed_modules_query,parameters)
    failed_modules=cur.fetchall()
    conn.commit()
    return failed_modules

def get_failed_culprits(conn,job_id,start_date,end_date):
    '''
    getting count of failed culprits with module name in a particular week
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    failed_culprits_query="select count(failed_build_culprit_name) as number_of_times_culprit_failed,failed_build_culprit_name from fact_jenkins_failed_build_culprits where build_id in (select build_id from fact_jenkins_build where build_start_time>=%s and build_start_time<=%s and job_id=%s) group by failed_build_culprit_name;"
    parameters=[start_date,end_date,job_id]
    cur.execute(failed_culprits_query,parameters)
    failed_culprits=cur.fetchall()
    conn.commit()
    return failed_culprits




def get_builds(conn,start_date,end_date,job_id):
    '''
    get build data in a particular week ordered by build number in descending
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    builds_query="select * from fact_jenkins_build where job_id=%s and build_start_time>=%s and build_start_time<=%s order by build_number desc"
    parameters=[job_id,start_date,end_date]
    cur.execute(builds_query,parameters)
    builds=cur.fetchall()
    conn.commit()
    return builds

def get_failed_chain_of_first_success_build(conn,job_id,build_number):
    '''
    getting failed chain of firat successful build in a week
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    failed_chain_query="select * from fact_jenkins_build where job_id=%s and build_number<%s order by build_number desc;"
    parameters=[job_id,build_number]
    cur.execute(failed_chain_query,parameters)
    builds=cur.fetchall()
    conn.commit()
    return builds

def get_failed_chain_statistics(chain_list,start_date,end_date):
    '''
    failed chain statistics  like longest failed build etc,.. are processed by passing failed chain list
    '''
    longest_number_of_builds_till_fix_failure = 0
    number_of_failed_builds = 0
    number_of_failed_lists = len(chain_list)
    longest_failed_build = None
    total_duration = timedelta(0)
    longest_failed_build_duration = timedelta(0)
    for list1 in chain_list:
        number_of_failed_builds += len(list1)
        if (len(list1) > longest_number_of_builds_till_fix_failure):
            longest_number_of_builds_till_fix_failure = len(list1)
            longest_failed_build = list1
        for build in list1:
            total_duration += build['build_duration']

    if (number_of_failed_lists != 0):
        avg_number_of_builds_till_fix_failure = number_of_failed_builds / number_of_failed_lists
        avg_duration_to_fix_failure = total_duration / number_of_failed_lists
    else:
        avg_duration_to_fix_failure=timedelta(0)
        avg_number_of_builds_till_fix_failure=0

    if (longest_failed_build is not None):
        for build in longest_failed_build:
            longest_failed_build_duration += build['build_duration']

    failed_chain_dict={'start_date':start_date,'end_date':end_date,'longest_no_of_builds':longest_number_of_builds_till_fix_failure,'avg_no_of_builds':avg_number_of_builds_till_fix_failure,'total_failed_builds':number_of_failed_builds,'avg_duration':avg_duration_to_fix_failure,'total_duration':total_duration,'longest_duration':longest_failed_build_duration}
    return failed_chain_dict

def get_failed_chains_data(conn,start_date,end_date,job_id):
    '''
    method where failed chain list is made from build data and it is passed as input to get failed chain statistics 
    '''
    builds=get_builds(conn,start_date,end_date,job_id)
    chain_list=[]
    first_build_success_in_week=None
    for j in range(0,len(builds)):
        if(builds[j]['build_status']=='SUCCESS'):
            first_build_success_in_week=builds[j]
            chain=[]
            for i in range(j-1,0,-1):
                if(builds[i]['build_status']!='SUCCESS'):
                    chain.append(builds[i])
                else:
                    if(len(chain)!=0):
                        chain_list.append(chain)
                    break

    first_failed_chain=[]
    if first_build_success_in_week is not None:
        builds=get_failed_chain_of_first_success_build(conn,job_id,first_build_success_in_week['build_number'])
        for build in builds:
            if(build['build_status']!='SUCCESS'):
                first_failed_chain.append(build)
            else:
                break

    if len(first_failed_chain)!=0:
        chain_list.append(first_failed_chain)

    failed_chain_statistics=get_failed_chain_statistics(chain_list,start_date,end_date)
    return failed_chain_statistics


def load_jenkins_statistics_data_to_db(conn,jenkins_statistics_data,job_id):
    '''
    method to load jenkins statistics data to database
    '''
    try:
        cur = conn.cursor()
        if(jenkins_statistics_data['successful_builds']!=0 or jenkins_statistics_data['unstable_builds']!=0 or jenkins_statistics_data['failed_builds']!=0 or jenkins_statistics_data['aborted_builds']!=0):
            jenkins_statistics_query="insert into fact_jenkins_statistics(week_no,week_start_date,week_end_date,success_rate,successful_builds,unstable_builds,failed_builds,aborted_builds,failed_products,failed_culprits,longest_number_builds_till_fixing_failure,average_number_builds_till_fixing_failure,number_of_failed_builds_till_fixing_failure,avg_duration_to_fix_failure,total_duration_of_failed_builds,longest_duration_to_fix_a_failure,job_id) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"
            parameters=[jenkins_statistics_data['week_no'],jenkins_statistics_data['start_date'],jenkins_statistics_data['end_date'],jenkins_statistics_data['success_rate'],jenkins_statistics_data['successful_builds'],jenkins_statistics_data['unstable_builds'],jenkins_statistics_data['failed_builds'],jenkins_statistics_data['aborted_builds'],json.dumps(jenkins_statistics_data['failed_products']),json.dumps(jenkins_statistics_data['failed_culprits']),jenkins_statistics_data['longest_no_of_builds'],jenkins_statistics_data['avg_no_of_builds'],jenkins_statistics_data['total_failed_builds'],jenkins_statistics_data['avg_duration'],jenkins_statistics_data['total_duration'],jenkins_statistics_data['longest_duration'],job_id]
            cur.execute(jenkins_statistics_query,parameters)
            conn.commit()                    
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        exit(1)

def delete_this_week_statistics(conn,job_id,start_date,end_date):
    '''
    method will delete the current week statistics
    '''
    try:
        cur = conn.cursor()
        week_statistics_query="delete from fact_jenkins_statistics where week_start_date=%s and week_end_date=%s and job_id=%s"
        parameters=[start_date,end_date,job_id]
        cur.execute(week_statistics_query,parameters)
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        exit(1)


def build_job_statistics(conn,job):
    '''
    method will build the required weekly jenkins statistics for given job
    '''
    cur=conn.cursor()
    time=date.today()
    start_date,end_date=utils.week_range(time)
    start_date=datetime.combine(start_date,datetime.min.time())
    end_date=datetime.combine(end_date,datetime.max.time())
    week_no=date.today().isocalendar()[1]
    delete_this_week_statistics(conn,job['job_id'],start_date,end_date)
    jenkins_statistics_data={}
    no_of_successful_builds=get_number_of_builds(conn,job['job_id'],'SUCCESS',start_date,end_date)
    no_of_unstable_builds=get_number_of_builds(conn,job['job_id'],'UNSTABLE',start_date,end_date)
    no_of_failed_builds=get_number_of_builds(conn,job['job_id'],'FAILURE',start_date,end_date)
    no_of_aborted_builds=get_number_of_builds(conn,job['job_id'],'ABORTED',start_date,end_date)
    success_rate=0
    if(no_of_successful_builds!=0):
        success_rate=no_of_successful_builds/(no_of_successful_builds+no_of_unstable_builds+no_of_failed_builds+no_of_aborted_builds)
    jenkins_statistics_data={'week_no':week_no,'start_date':start_date,'end_date':end_date,'success_rate':int(success_rate*100),'successful_builds':no_of_successful_builds,'unstable_builds':no_of_unstable_builds,'failed_builds':no_of_failed_builds,'aborted_builds':no_of_aborted_builds}
    failed_modules=get_failed_modules(conn,job['job_id'],start_date,end_date)
    failed_products_list=[]
    for product in failed_modules:
        failed_product_dict={'name':product['failed_build_module_name'],'no_of_times':product['number_of_times_module_failed']}
        failed_products_list.append(failed_product_dict)
    failed_modules_dict={}
    failed_modules_dict['failed_products']=failed_products_list
    jenkins_statistics_data['failed_products']=failed_modules_dict


    failed_culprits=get_failed_culprits(conn,job['job_id'],start_date,end_date)
    failed_culprits_list=[]
    for culprit in failed_culprits:
        failed_culprit_dict={'name':culprit['failed_build_culprit_name'],'no_of_times':culprit['number_of_times_culprit_failed']}
        failed_culprits_list.append(failed_culprit_dict)
    failed_culprits_dict={}
    failed_culprits_dict['failed_culprits']=failed_culprits_list
    jenkins_statistics_data['failed_culprits']=failed_culprits_dict
    
    failed_chain_data=get_failed_chains_data(conn,start_date,end_date,job['job_id'])
    jenkins_statistics_data.update(failed_chain_data)
    load_jenkins_statistics_data_to_db(conn,jenkins_statistics_data,job['job_id'])



