import psycopg2
import itertools
import operator


def get_stream_id(conn,alias,logger):
    '''
    for particular job with alias getting stream id
    '''
    try:
        cur = conn.cursor()
        stream_id_query="SELECT stream_id from fact_swp_streams where alias=%s"
        parameters=[alias]
        cur.execute(stream_id_query,parameters)
        stream_id=cur.fetchone()
        
        return stream_id[0]
        
    except (Exception, psycopg2.DatabaseError) as error:
        logger.info(error)
        exit(1)


def check_alias(conn,alias,logger):
    '''
    method to check whether for particular stream exists in log or not
    stream exists for alias in log if there is name='NA' in log_table
    '''
    try:
        cur = conn.cursor()
        check_alias_query="SELECT alias from fact_swp_log_data where alias=%s and name='NA'"
        parameters=[alias]
        cur.execute(check_alias_query,parameters)
        alias_present=cur.fetchall()
        if len(alias_present)!=0:
            return True
        else:
            return False
        
    except (Exception, psycopg2.DatabaseError) as error:
        logger.info(error)
        exit(1)

def append_job(conn,logger,job_name,alias,start_time,end_time,status,final_jobs_dict):
    if(check_alias(conn,alias,logger)):
        stream_id=get_stream_id(conn,alias,logger)
        if(start_time is not None and end_time is not None):
            final_jobs_dict={'JOB_NAME':job_name,'ALIAS':alias,'JOB_START_TIME':start_time,'JOB_END_TIME':end_time,'JOB_DURATION':end_time-start_time,'STATUS':status,'STREAM_ID':stream_id}
        else:
            final_jobs_dict={'JOB_NAME':job_name,'ALIAS':alias,'JOB_START_TIME':start_time,'JOB_END_TIME':end_time,'JOB_DURATION':None,'STATUS':status,'STREAM_ID':stream_id}
    return final_jobs_dict
            

def get_jobs_data(conn,alias_list,logger):
    '''
    jobs data is fetched from log file data based on alias ie.for particular stream
    '''
    try:
        cur = conn.cursor()
        final_jobs_data=[]
        for alias in alias_list:
            job_data_query="select date,name,status,alias from fact_swp_log_data where alias=%s and job_or_stream='JOB'"
            parameters=[alias]
            cur.execute(job_data_query,parameters)
            job_data=cur.fetchall()
            conn.commit()
            jobs_data=[]
            labels=['JOB_DATE','JOB_NAME','JOB_STATUS','ALIAS']
            for line in job_data:
                job_data_dict={}
                for label,value in zip(labels,line):
                    job_data_dict[label]=value
                jobs_data.append(job_data_dict)

            jobs_data.sort(key=operator.itemgetter('JOB_NAME'))
            #multiple instance of a job are grouped which are by default sorted in increasing time and among them min gives job_start_time and max gives job_end_time 
            job_data=[]
            for key, items in itertools.groupby(jobs_data, operator.itemgetter('JOB_NAME')):
                job_data.append(list(items))
                    
            for job in job_data:
                final_jobs_dict={}
                
                start_time=end_time=status=None
                count=1
                for d in job:
                    if(d['JOB_STATUS']=='Running'):
                        if(count>1):
                            final_jobs_dict=append_job(conn,logger,d['JOB_NAME'],alias,start_time,end_time,status,final_jobs_dict)
                            if(len(final_jobs_dict)!=0):
                                final_jobs_data.append(final_jobs_dict)
                        start_time=d['JOB_DATE']
                        status='STARTED'
                        count=count+1
                    elif(d['JOB_STATUS']=='Successful'):
                        end_time=d['JOB_DATE']
                        status='SUCCESS'
                    elif(d['JOB_STATUS']=='Error' or d['JOB_STATUS']=='Canceled' or d['JOB_STATUS']=='Cancelled'):
                        end_time=d['JOB_DATE']
                        status='ERROR'

                final_jobs_dict=append_job(conn,logger,d['JOB_NAME'],alias,start_time,end_time,status,final_jobs_dict)
                if(len(final_jobs_dict)!=0):
                    final_jobs_data.append(final_jobs_dict)             
        return final_jobs_data
    except (Exception, psycopg2.DatabaseError) as error:
        logger.info(error)
        exit(1)
