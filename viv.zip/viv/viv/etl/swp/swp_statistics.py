import psycopg2
import psycopg2.extras
from datetime import date,datetime,timedelta

def week_range(date):
    year, week, dow = date.isocalendar()
    start_date = date-timedelta(dow-1)
    end_date = start_date + timedelta(6)
    return (start_date, end_date)


def get_flow_group(conn,project_id,start_date,end_date):
    '''
    group of flows is selected to find average time from fact_swp_flows table
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    flow_group_query="select flow_name,avg(flow_duration) as average_time,count(flow_status) as successful_flows from fact_swp_flows where project_id=%s and flow_status='SUCCESS' and flow_start_date>=%s and flow_start_date<=%s group by flow_name"
    parameters=[project_id,start_date,end_date]
    cur.execute(flow_group_query,parameters)
    flow_group=cur.fetchall()
    conn.commit()
    return flow_group

def get_number_of_flow_instances(conn,project_id,flow_name,start_date,end_date):
    '''
    method to get the count of no.of flow instances of particular flow
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    flow_instances_query="select count(flow_name) as number from fact_swp_flows where project_id=%s and flow_name=%s and flow_start_date>=%s and flow_start_date<=%s"
    parameters=[project_id,flow_name,start_date,end_date]
    cur.execute(flow_instances_query,parameters)
    flow_instances=cur.fetchone()
    conn.commit()
    return flow_instances['number']

def get_group_flow_with_no_success(conn,project_id,start_date,end_date):
    '''
    method to get the flows which are grouped with status not success so that avg time is zero
    '''
    cur=conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    flow_group_query="select flow_name,count(flow_status) from fact_swp_flows where project_id=%s and flow_status='SUCCESS' and flow_start_date>=%s and flow_start_date<=%s group by flow_name having count(flow_status)=0"
    parameters=[project_id,start_date,end_date]
    cur.execute(flow_group_query,parameters)
    flow_group=cur.fetchall()
    conn.commit()
    return flow_group    

def load_swp_statistics_data_to_db(conn,total_week_data,project_id):
    '''
    pushing swp statistics data into database
    '''
    try:
        for week_data in total_week_data:
            cur = conn.cursor()
            swp_statistics_query="insert into fact_swp_statistics(week_no,week_start_date,week_end_date,flow_name,number_of_flow_instances,number_of_successful_flow_instances,average_duration,failed_jobs,project_id) values(%s,%s,%s,%s,%s,%s,%s,%s,%s);"
            parameters=[week_data['week_no'],week_data['start_date'],week_data['end_date'],week_data['flow_name'],week_data['number_of_flow_instances'],week_data['number_of_successful_flow_instances'],week_data['average_duration'],week_data['failed_jobs'],project_id]
            cur.execute(swp_statistics_query,parameters)
            conn.commit()                    
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        exit(1)

def delete_this_week_statistics(conn,project_id,start_date,end_date):
    '''
    method to delete this week statistics
    '''
    try:
        cur = conn.cursor()
        week_statistics_query="delete from fact_swp_statistics where week_start_date=%s and week_end_date=%s and project_id=%s"
        parameters=[start_date,end_date,project_id]
        cur.execute(week_statistics_query,parameters)
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        exit(1)

def most_failed_jobs(conn,start_date,end_date,flow_name):
    try:
        cur=conn.cursor()
        most_failed_jobs_query="select count(job_name),job_name from fact_swp_jobs where job_status='ERROR' and stream_id in (select stream_id from fact_swp_streams where flow_id in (select flow_id from fact_swp_flows where flow_name=%s and flow_start_date>%s and flow_start_date<%s)) group by job_name order by count(job_name) desc limit 2"
        parameters=[flow_name,start_date,end_date]
        cur.execute(most_failed_jobs_query,parameters)
        most_failed_jobs=cur.fetchall()
        conn.commit()
        return most_failed_jobs
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        exit(1)

        
def build_statistics(conn,project_id,date_to_run_from,flag):
    '''
    method to get swp statistics
    '''
    cur=conn.cursor()
    if(flag==1):
        time=date_to_run_from.date()
    else:
        time=date.today()
    while(date.today()>=time):
        start_date,end_date=week_range(time)
        start_date=datetime.combine(start_date,datetime.min.time())
        end_date=datetime.combine(end_date,datetime.max.time())
        week_no=start_date.isocalendar()[1]
        delete_this_week_statistics(conn,project_id,start_date,end_date)
        
        week_data=[]
        swp_statistics_data={}
        group_flow=get_flow_group(conn,project_id,start_date,end_date)
        for flow in group_flow:
            number_of_flow_instances=get_number_of_flow_instances(conn,project_id,flow['flow_name'],start_date,end_date)
            most_failed_job=most_failed_jobs(conn,start_date,end_date,flow['flow_name'])
            if(len(most_failed_job)>0):
                failed_jobs_str=''
                for job in most_failed_job:
                    failed_jobs_str=failed_jobs_str+job[1]+','
                failed_jobs_str=failed_jobs_str[:-1]
            else:
                failed_jobs_str='-'
            week_dict={'week_no':week_no,'start_date':start_date,'end_date':end_date,'flow_name':flow['flow_name'],'average_duration':flow['average_time'],'number_of_flow_instances':number_of_flow_instances,'number_of_successful_flow_instances':flow['successful_flows'],'failed_jobs':failed_jobs_str}
            week_data.append(week_dict)

        
        group_flow=get_group_flow_with_no_success(conn,project_id,start_date,end_date)
        for flow in group_flow:
            number_of_flow_instances=get_number_of_flow_instances(conn,project_id,flow['flow_name'],start_date,end_date)
            most_failed_job=most_failed_jobs(conn,start_date,end_date,flow['flow_name'])
            if(len(most_failed_job)>0):
                failed_jobs_str=''
                for job in most_failed_job:
                    failed_jobs_str=failed_jobs_str+job[1]+','
                failed_jobs_str=failed_jobs_str[:-1]
                print(failed_jobs_str)
            else:
                failed_jobs_str='-'
            week_dict={'week_no':week_no,'start_date':start_date,'end_date':end_date,'flow_name':flow['flow_name'],'average_duration':timedelta(0),'number_of_flow_instances':number_of_flow_instances,'number_of_successful_flow_instances':0,'failed_jobs':failed_jobs_str}
            week_data.append(week_dict)

        load_swp_statistics_data_to_db(conn,week_data,project_id)
        time=time+timedelta(days=7)
