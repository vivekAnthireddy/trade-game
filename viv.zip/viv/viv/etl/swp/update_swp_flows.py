import psycopg2

def get_flow_data_from_db(conn,max_flow_id,logger):
    '''
    getting flow_data from databse whose status,end time,duration is yet to be find
    '''
    try:
        cur = conn.cursor()
        cur.execute("select * from fact_swp_flows where flow_id>%s"%(max_flow_id))
        flow_data=cur.fetchall()
        conn.commit()
        return flow_data
    except (Exception, psycopg2.DatabaseError) as error:
        logger.info(error)
        exit(1)


def get_stream_data_from_db(conn,flow_id,logger):
    '''
    getting stream data for the flows whose status,end time,duration is yet to be find because based on the stream data of flow ,flow's status is decided 
    '''
    try:
        cur = conn.cursor()
        cur.execute("select * from fact_swp_streams where flow_id=%s order by stream_end_time desc"%(flow_id))
        stream_data=cur.fetchall()
        conn.commit()
        return stream_data
    except (Exception, psycopg2.DatabaseError) as error:
        logger.info(error)
        exit(1)

def update_flows_data(conn,max_flow_id,logger):
    '''
    updating flows with the end time,status,duration
    '''
    fetched_flow_data=get_flow_data_from_db(conn,max_flow_id,logger)
    for line in fetched_flow_data:
        flow_id=line[0]
        fetched_stream_data=get_stream_data_from_db(conn,flow_id,logger)
        status=[]
        flow={}
        flow["status"]='Running'
        flow["end_date"]=None
        flow["duration"]=None
        if 'Running' in status:
            flow["status"]='Running'
        else:
            for stream in fetched_stream_data:
                flow["end_date"]=stream[3]
                flow["status"]=stream[5]
                if flow['end_date'] is not None:
                    flow["duration"]=flow['end_date']-line[2]
                break
        try:
            cur = conn.cursor()
            update_flow_query="update fact_swp_flows set flow_end_date=%s,flow_duration=%s,flow_status=%s where flow_id=%s"
            parameters=[flow['end_date'],flow['duration'],flow['status'],flow_id]
            cur.execute(update_flow_query,parameters)
            conn.commit()
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(error)
            exit(1)
    logger.info("Updated flows data Successfully")
