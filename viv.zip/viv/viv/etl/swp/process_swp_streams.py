import psycopg2

def get_streams_data(conn,group_data,max_flow_id,logger):
    '''
    getting stream data from group data which is fetched from oracle database where flow_id is assigned to every stream and start time,end time are fetched from log_data table in postgres database 
    '''
    try:
        cur = conn.cursor()
        flow_id=max_flow_id
        streams_data=[]
        for group in group_data:
            flow_id=flow_id+1
            for line in group:
                stream_data={}
                #getting start time and end time from fact_swp_log_data for each stream
                start_date_query="select min(date) from fact_swp_log_data where alias=%s and status='Running'"
                end_date_query="select max(date) from fact_swp_log_data where alias=%s and status='Successful'" 
                parameters=[line['ALIAS']]
                cur.execute(start_date_query,parameters)
                start_time=cur.fetchone()
                cur.execute(end_date_query,parameters)
                end_time=cur.fetchone()
                #if end_date query fetches nothing that means status of stream not successful
                if end_time[0] is None:
                    end_date_query2="select max(date) from fact_swp_log_data where alias=%s and status in (select status from fact_swp_log_data where status!='Running')"
                    parameters=[line['ALIAS']]
                    cur.execute(end_date_query2,parameters)
                    end_time2=cur.fetchone()
                    if end_time2[0] is None:
                        status='Running'
                    else:
                        end_time=[]
                        end_time.append(end_time2[0])
                        status='Cancelled'
                else:
                    status='SUCCESS'

                if(start_time[0] is not None and end_time[0] is not None):
                    stream_data={'STREAM_NAME':line['STREAM_NAME'],'STREAM_START_TIME':start_time[0],'STREAM_END_TIME':end_time[0],'DURATION':end_time[0]-start_time[0],'STATUS':status,'ALIAS':line['ALIAS'],'FLOW_ID':flow_id}
                    streams_data.append(stream_data)
                elif(start_time[0] is not None or end_time[0] is not None):
                    stream_data={'STREAM_NAME':line['STREAM_NAME'],'STREAM_START_TIME':start_time[0],'STREAM_END_TIME':end_time[0],'DURATION':None,'STATUS':status,'ALIAS':line['ALIAS'],'FLOW_ID':flow_id}
                    streams_data.append(stream_data)                 
        conn.commit()      
        return streams_data
    except (Exception, psycopg2.DatabaseError) as error:
        logger.info(error)
        exit(1)
