import cx_Oracle
import time
import re
from datetime import date,datetime,timedelta
import itertools
import operator
import paramiko
import psycopg2
import logging
import sys
import base64
import db_config
import utils
from update_swp_flows import update_flows_data
from process_swp_jobs import get_jobs_data
from process_swp_streams import get_streams_data
from swp_statistics import build_statistics


def get_project_details(conn,logger):
    '''
    getting all project details from postgres database table dim_project
    '''
    try:       
        cur = conn.cursor()
        cur.execute("select project_id from dim_project")
        project_id_list=cur.fetchall()
        conn.commit()
        return project_id_list
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)


def get_connection_details(conn,project_id,logger):
    '''
    getting connection details from postgres database table dim_swp_connection_details for particular project
    '''
    try:
        cur = conn.cursor()
        connect_details_query="select * from dim_swp_connection_details where project_id=%s"
        parameters=[project_id]
        cur.execute(connect_details_query,parameters)
        connection_details=cur.fetchone()
        conn.commit()
        return connection_details
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

            
def get_last_run_details(conn,project_id,logger):
    '''
    getting date when this program was last run
    '''
    try:
        cur = conn.cursor()
        last_run_query="select max(last_run_date) from fact_swp_run_date where project_id=%s"
        parameters=[project_id]
        cur.execute(last_run_query,parameters)
        last_run_date=cur.fetchone()
        conn.commit()
        return last_run_date[0]
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)


def get_max_flow_id(conn,logger):
    '''
    getting maximum value of flow_id from the postgres db table fact_swp_flows which is used for newly flows fetched from oracle database
    '''
    try:
        cur = conn.cursor()
        cur.execute("select max(flow_id) from fact_swp_flows")
        max_flow_id=cur.fetchone()
        if max_flow_id[0] is None:
            return 0
        else:
            return max_flow_id[0]
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)


def delete_today_log_data(conn,present_run_date,project_id,logger):
    '''
    deleting todays log data because of synchronization problem
    '''
    try:
        cur = conn.cursor()
        delete_last_week_flow_query="DELETE FROM fact_swp_log_data where date>=%s and project_id=%s"
        parameters=[present_run_date,project_id]
        cur.execute(delete_last_week_flow_query,parameters)
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def convert_data_to_dict(fetch_data):
    '''
    converting data fetched from oracle database into dictionary
    '''
    fetched_data=[]
    labels=['FLOW_NAME','STREAM_NAME','ALIAS','EVENT_ID','CREATION_DATE']
    for line in fetch_data:
        my_dict={}
        for label,value in zip(labels,line):
            my_dict[label]=value
        fetched_data.append(my_dict)
    return fetched_data

def process_fetched_data(fetched_data,date_to_run_from,running_event_id):
    '''
    processing fetched data from based on date and previous running flows event id
    '''
    data=[]
    for row in fetched_data:
        if(row['CREATION_DATE']>=date_to_run_from or (str(row['EVENT_ID']) in running_event_id)):
            data.append(row)
    return data
            

def get_group_data(fetched_data):
    '''
    grouping fetched data based on event id
    '''
    fetched_data.sort(key=operator.itemgetter('EVENT_ID'))
    group_data=[]
    for key, items in itertools.groupby(fetched_data, operator.itemgetter('EVENT_ID')):
        group_data.append(list(items))
    return group_data

def get_flows_data(group_data,project_id,max_flow_id):
    '''
    getting flow data from group data
    '''
    flows_data=[]
    flow_id=max_flow_id
    for group in group_data:
        flow_id=flow_id+1
        group.sort(key=operator.itemgetter('CREATION_DATE'))
        row=group[0]
        flow_data={'FLOW_ID':flow_id,'FLOW_NAME':row['FLOW_NAME'],'START_DATE':row['CREATION_DATE'],'END_DATE':None,'DURATION':None,'STATUS':None,'PROJECT_ID':project_id,'EVENT_ID':row['EVENT_ID']}
        flows_data.append(flow_data)
    return flows_data


def load_flows_data_to_db(conn,flows_data,logger):
    '''
    loading flow data into database
    '''
    try:
        cur = conn.cursor()
        for row in flows_data:
            SQL="INSERT INTO public.fact_swp_flows(flow_id,flow_name,flow_start_date,project_id,flow_event_id) VALUES(%s,%s,%s,%s,%s);"
            parameters=[row['FLOW_ID'],row['FLOW_NAME'],row['START_DATE'],row['PROJECT_ID'],row['EVENT_ID']]
            cur.execute(SQL,parameters)
        conn.commit()
        logger.info ("Flows Data entered successfully...")
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def get_date_from_logs(line):
    '''
    getting date from log_date by using regular expressions
    '''
    pattern=re.compile(r'[a-zA-Z]{3}..\d{1,2}.\d{2}:\d{2}:\d{2}.....\d{4}')
    matches=pattern.findall(line)
    date1=None
    for match in matches:
        date1=match.replace('IST ','')
        date1=date1.replace('IDT ','')
    return date1


def process_log_data(data_from_logs,date_to_run_from,project_id):
    '''
    processing log data for start time,end time,alias and status.here we assign project_id to the corresponding project log data
    '''
    log_file_data=[]
    for line in data_from_logs:
        date_from_logs=get_date_from_logs(line)
        if(date_from_logs is not None):
            date_obj=datetime.strptime(date_from_logs,'%b %d %H:%M:%S %Y')
            if(date_obj>=date_to_run_from):
                log_data={'DATE':date_from_logs,'JOB_OR_STREAM':line.split('<HANDLE_EVENT>')[1].split(' ')[1],'NAME':line.split('<HANDLE_EVENT>')[1].split(' ')[2],'ALIAS':line.split('<HANDLE_EVENT>')[1].split(' ')[3],'STATUS':line.split('<HANDLE_EVENT>')[1].split(' ')[4],'PROJECT_ID':project_id}
                log_file_data.append(log_data)
    return log_file_data



def load_log_file_data_to_db(conn,log_file_data,logger):
    '''
    loading processed log file data into database
    '''
    try:
        cur = conn.cursor()
        for row in log_file_data:
            SQL="INSERT INTO public.fact_swp_log_data VALUES(%s,%s,%s,%s,%s,%s);"
            parameters=[row['DATE'],row['JOB_OR_STREAM'],row['NAME'],row['ALIAS'],row['STATUS'],row['PROJECT_ID']]
            cur.execute(SQL,parameters)
        conn.commit()
        logger.info ("Log file Data entered successfully...")
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def load_streams_data_to_db(conn,streams_data,logger):
    '''
    loading streams data into postgres database
    '''
    try:
        cur = conn.cursor()
        for row in streams_data:
            SQL="INSERT INTO public.fact_swp_streams(stream_name,stream_start_time,stream_end_time,stream_duration,stream_status,alias,flow_id) VALUES(%s,%s,%s,%s,%s,%s,%s);"
            parameters=[row['STREAM_NAME'],row['STREAM_START_TIME'],row['STREAM_END_TIME'],row['DURATION'],row['STATUS'],row['ALIAS'],row['FLOW_ID']]
            cur.execute(SQL,parameters)
        conn.commit()
        logger.info ("Streams Data entered successfully...")
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)


def load_jobs_data_to_db(conn,jobs_data,logger):
    '''
    loading jobs data into postgres database
    '''
    try:
        cur = conn.cursor()
        for row in jobs_data:
            SQL="INSERT INTO public.fact_swp_jobs(job_name,alias,job_start_time,job_end_time,job_duration,job_status,stream_id) VALUES(%s,%s,%s,%s,%s,%s,%s);"
            parameters=[row['JOB_NAME'],row['ALIAS'],row['JOB_START_TIME'],row['JOB_END_TIME'],row['JOB_DURATION'],row['STATUS'],row['STREAM_ID']]
            cur.execute(SQL,parameters)
        conn.commit()
        logger.info ("Jobs Data entered successfully...")
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def update_last_run_date(conn,present_run_date,project_id,logger):
    '''
    updating run date of the program
    '''
    try:
        cur = conn.cursor()
        update_run_date_query="insert into fact_swp_run_date values(%s,%s)"
        parameters=[present_run_date,project_id]
        cur.execute(update_run_date_query,parameters)
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def get_running_flows_list(conn,project_id,logger):
    '''
    getting list of flows whose status is Running for particular project
    '''
    try:
        cur = conn.cursor()
        running_flow_query="select flow_event_id from fact_swp_flows where flow_status='Running' and project_id=%s"
        parameters=[project_id]
        cur.execute(running_flow_query,parameters)
        running_flow_data=cur.fetchall()
        conn.commit()
        return running_flow_data
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def delete_running_flow_data(conn,project_id,logger):
    '''
    deleting the flows from databse whose flow status is Running
    '''
    try:
        cur = conn.cursor()
        delete_running_flow_query="delete from fact_swp_flows where project_id=%s and flow_status='Running'"
        parameters=[project_id]
        cur.execute(delete_running_flow_query,parameters)
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

def delete_todays_flow_data(conn,project_id,date_to_run_from,logger):
    '''
    deleting flows from databse which are created when this program was run previously on particular day
    '''
    try:
        cur = conn.cursor()
        todays_flow_query="delete from fact_swp_flows where flow_start_date>=%s and project_id=%s"
        parameters=[date_to_run_from,project_id]
        cur.execute(todays_flow_query,parameters)
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        logger.error(error)
        exit(1)

    
def get_data_from_oracle_db(conn_details,date_to_run_from,logger):
    '''
    connecting to oracle database and fetching data from it
    '''
    try:
        str_date_to_run_from=date_to_run_from.strftime("%d-%b-%Y")
        user=conn_details[1]
        pwd=decrypt('SecretKey',conn_details[2])
        ip=conn_details[3]
        SID=conn_details[4]
        port=conn_details[5]                    
        dsn_tns = cx_Oracle.makedsn(ip, port, SID)
        connect = cx_Oracle.connect(user, pwd, dsn_tns)
        cur=connect.cursor()
        
        fetch_data_obj=cur.execute("SELECT IMT_EVT.FLOW_NAME,IMT_EVT.JOB_OR_STREAM,IMT_EVT.ALIAS,IMT_EVT.EVT_ID,IMT_EVT.CREATION_DATE from IMT_EVT WHERE IMT_EVT.RUN_USER='SCHED_ADMIN' and creation_date>='%s'"%(str_date_to_run_from))
        fetch_data=[line for line in fetch_data_obj]
        logger.info("FETCHED DATA FROM ORACLE DB=%s"%(fetch_data))
        return fetch_data
    
    except cx_Oracle.DatabaseError as e:
        logger.error(e.args)


def get_data_from_logs(conn_details,logger):
    '''
    connecting to unix server and getting log data
    '''
    try:
        hostname=conn_details[6]
        username=conn_details[7]
        password=decrypt('SecretKey',conn_details[8])

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                            
        client.connect(hostname, username=username, password=password, look_for_keys=False, allow_agent=False)
        logger.info("Unix SERVER connection established")
        command_log_data="cd %s && cat imt_event_handler_*.log"%(conn_details[9])
        stdin,stdout,stderr=client.exec_command(command_log_data)
        logger.info("Data fetched from logs")
        data_from_logs=stdout.readlines()
        return data_from_logs    
    except Exception as e:
        logger.error(e.args)
        exit(1)
    finally:        
        client.close()


def get_log_file_start_date(conn_details,logger):
    try:
        hostname=conn_details[6]
        username=conn_details[7]
        password=decrypt('SecretKey',conn_details[8])

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                            
        client.connect(hostname, username=username, password=password, look_for_keys=False, allow_agent=False)
        logger.info("Unix SERVER connection established")
        command_log_start_date="find %s/"%(conn_details[9])
        command_log_start_date+="imt_event_handler_*.log -type f -printf '%TY-%Tm-%Td\n' | sort | head -n 1"
        stdin,stdout,stderr=client.exec_command(command_log_start_date)
        logger.info("Start Date fetched from logs")
        date_from_logs=stdout.readlines()
        #start_date="2018-05-09"
        for start_date in date_from_logs:
            log_file_start_date=datetime(int(start_date[0:4]),int(start_date[5:7]),int(start_date[8:10]))
        return log_file_start_date
    except Exception as e:
        logger.error(e.args)
        return None
    finally:        
        client.close()

def decrypt(key, enc):
    '''Decryption of password'''
    dec = []
    enc = base64.urlsafe_b64decode(enc).decode()
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)

if __name__== "__main__":
    try:
        program_name="SWP"
        log_file_name="swp_"+datetime.now().strftime("%d%m%Y%H%M%S")+".log"
        logger=utils.log(program_name,log_file_name)
        conn=utils.create_postgres_connection(db_config.db_user,db_config.db_password,db_config.db_instance,db_config.db_server)
        project_id_list=get_project_details(conn,logger)
        #getting list of projects
        for project_id in project_id_list:
            conn_details=get_connection_details(conn,project_id,logger)

            #getting connection details for project
            if conn_details is not None:
                date_to_run_from=get_last_run_details(conn,project_id,logger)
                flag=0
                if(date_to_run_from is None):
                    flag=1
                    date_to_run_from=get_log_file_start_date(conn_details,logger)
                    if date_to_run_from is None:
                        continue

                #get max flow id from the table which is used for assigning to the new flows
                max_flow_id=get_max_flow_id(conn,logger)
                today_date=date.today()

                delete_today_log_data(conn,date_to_run_from,project_id,logger)

                running_flows_list=get_running_flows_list(conn,project_id,logger)
                #get flows with running status and delete them from table because when we fetch flow details..... again we get the running flows with new streams
                running_event_id=[]
                if(len(running_flows_list)!=0):
                    running_event_id=[row[0] for row in running_flows_list]
                    delete_running_flow_data(conn,project_id,logger)
                

                delete_todays_flow_data(conn,project_id,date_to_run_from,logger)

                
                fetch_data=get_data_from_oracle_db(conn_details,date_to_run_from,logger)
                if(fetch_data is not None):
                    fetched_data=convert_data_to_dict(fetch_data)
                    processed_data=process_fetched_data(fetched_data,date_to_run_from,running_event_id)
                    group_data=get_group_data(processed_data)
                    alias_list=[row["ALIAS"] for row in processed_data]
                    flows_data=get_flows_data(group_data,project_id,max_flow_id)            
                    load_flows_data_to_db(conn,flows_data,logger)

                    data_from_logs=get_data_from_logs(conn_details,logger)
                    log_file_data=process_log_data(data_from_logs,date_to_run_from,project_id)
                    load_log_file_data_to_db(conn,log_file_data,logger)

                    streams_data=get_streams_data(conn,group_data,max_flow_id,logger)
                    load_streams_data_to_db(conn,streams_data,logger)

                    jobs_data=get_jobs_data(conn,alias_list,logger)
                    load_jobs_data_to_db(conn,jobs_data,logger)

                    update_flows_data(conn,max_flow_id,logger)
                    update_last_run_date(conn,today_date,project_id,logger)
                    build_statistics(conn,project_id,date_to_run_from,flag)
                    logger.info("STATISTICS data entered successfully")
                logger.info("Finished Running the program for project id=%s"%(project_id))
            else:
                logger.info("No connection details for project id=%s"%(project_id))

    finally:
        if conn is not None:
            conn.close()
