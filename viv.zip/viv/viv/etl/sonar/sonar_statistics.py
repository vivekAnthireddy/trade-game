from datetime import timedelta, datetime, date
import psycopg2, sys
import db_config
from utils import week_range

def build_statistics(conn,project_name,product_name,project_id,product_id):
    '''Method to build statistics for sonar'''
    cur=conn.cursor()
    time=date.today()
    start_date,end_date=week_range(time)
    start_date=datetime.combine(start_date,datetime.min.time())
    end_date=datetime.combine(end_date,datetime.max.time())
    week_no=date.today().isocalendar()[1]
    SQL='delete from public.fact_sonar_statistics where statistic_start_date=%s and statistic_end_date=%s and statistic_product_id=%s and statistic_project_id=%s'
    parameters=[start_date,end_date,product_id,project_id]
    cur.execute(SQL,parameters)
    SQL='SELECT metric_technical_debt,metric_new_technical_debt,metric_blocker_issues,metric_new_blocker_issues,metric_critical_issues,metric_new_critical_issues,metric_bugs,metric_vulnerabilities,metric_code_smells,metric_issues,metric_new_violations,metric_complexity,metric_unit_tests,metric_unit_test_coverage,metric_lines_of_code,metric_duplicated_lines from public.fact_metric_data where metric_last_update >=%s and metric_last_update <=%s and metric_product_id=%s'
    parameters=[start_date,end_date,product_id]
    cur.execute(SQL,parameters)
    week_data=cur.fetchall()
    if len(week_data)>0:
        week_data=[list(data) for data in week_data]
        total_days=len(week_data)
        metrics=['metric_technical_debt','metric_new_technical_debt','metric_blocker_issues','metric_new_blocker_issues','metric_critical_issues','metric_new_critical_issues','metric_bugs','metric_vulnerabilities','metric_code_smells','metric_issues','metric_new_violations','metric_complexity','metric_unit_tests','metric_unit_test_coverage','metric_lines_of_code','metric_duplicated_lines']
        week_data=[dict(zip(metrics,data)) for data in week_data]
        statistics={}
        for each_metric in metrics:
            for data in week_data:
                if each_metric in statistics:
                    statistics[each_metric]+=data[each_metric]
                else:
                    statistics[each_metric]=data[each_metric]
        for each_metric,value in statistics.items():
            statistics[each_metric]=statistics[each_metric]/total_days
        SQL='select count(*) from public.fact_issue_data where project_id=%s and product_id=%s and creationdate>=%s and creationdate<=%s and resolution=%s'
        parameters=[project_id,product_id,start_date,end_date,"Unresolved"]
        cur.execute(SQL,parameters)
        issues_unresolved=cur.fetchall()
        statistics['unresolved']=issues_unresolved[0][0]
        issues_severity=['BLOCKER','CRITICAL','MAJOR','MINOR','INFO']
        for each_severity in issues_severity:
            SQL='select count(*) from public.fact_issue_data where project_id=%s and product_id=%s and creationdate>=%s and creationdate<=%s and severity=%s'
            parameters=[project_id,product_id,start_date,end_date,each_severity]
            cur.execute(SQL,parameters)
            severity_count=cur.fetchall()
            statistics[each_severity]=severity_count[0][0]
        SQL='select author,count(*) from public.fact_issue_data where project_id=%s and product_id=%s and creationdate>=%s and creationdate<=%s group by author order by count(*) DESC'
        parameters=[project_id,product_id,start_date,end_date,]
        cur.execute(SQL,parameters)
        major_violators=cur.fetchall()
        if len(major_violators)>0:
            statistics['major_violator']=major_violators[0][0]
        else:
            statistics['major_violator']=None
        SQL='insert into public.fact_sonar_statistics(statistic_project_name,statistic_product_name,statistic_week_no,statistic_start_date,statistic_end_date,statistic_technical_debt,statistic_new_technical_debt,statistic_blocker_issues,statistic_new_blocker_issues,statistic_critical_issues,statistic_new_critical_issues,statistic_bugs,statistic_vulnerabilities,statistic_code_smells,statistic_issues,statistic_issues_unresolved,statistic_issues_blocker,statistic_issues_critical,statistic_issues_major,statistic_issues_minor,statistic_issues_info,statistic_issues_major_violator,statistic_new_violations,statistic_complexity,statistic_unit_tests,statistic_unit_test_coverage,statistic_lines_of_code,statistic_duplicated_lines,statistic_product_id,statistic_project_id) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        parameters=[project_name,product_name,week_no,start_date,end_date,statistics.get('metric_technical_debt'),statistics.get('metric_new_technical_debt'),statistics.get('metric_blocker_issues'),statistics.get('metric_new_blocker_issues'),statistics.get('metric_critical_issues'),statistics.get('metric_new_critical_issues'),statistics.get('metric_bugs'),statistics.get('metric_vulnerabilities'),statistics.get('metric_code_smells'),statistics.get('metric_issues'),statistics.get('unresolved'),statistics.get('BLOCKER'),statistics.get('CRITICAL'),statistics.get('MAJOR'),statistics.get('MINOR'),statistics.get('INFO'),statistics.get('major_violator'),statistics.get('metric_new_violations'),statistics.get('metric_complexity'),statistics.get('metric_unit_tests'),statistics.get('metric_unit_test_coverage'),statistics.get('metric_lines_of_code'),statistics.get('metric_duplicated_lines'),product_id,project_id]
        cur.execute(SQL,parameters)
        conn.commit()
