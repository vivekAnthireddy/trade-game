import requests
from datetime import date
import sys

from config import sonar_config
import utils
import dim_date

def create_sonar_table(conn):
    tables = sonar_config.get_table_details()
    utils.create_table(conn, tables)

def get_project_id(conn, project_name):
    sql = 'select project_id from dim_project where project_name = %s'
    cur = conn.cursor()
    cur.execute(sql, (project_name,))
    return cur.fetchone()[0]

def get_module_id(conn, project_id, module_key):
    sql = 'select module_id from dim_sonar_module where project_id = %s and module_key = %s'
    cur = conn.cursor()
    cur.execute(sql, (project_id, module_key))
    return cur.fetchone()[0]

def delete_by_date(conn, project_name, module_key, date_to_delete):
    project_id = get_project_id(conn, project_name)
    module_id = get_module_id(conn, project_id, module_key)
    sql = 'delete from fact_sonar_data where load_date = %s and project_id = %s and module_id = %s'
    
    conn.cursor().execute(sql, (date_to_delete, project_id, module_id))

def insert_sonar_data(conn, project_name, module_key,  run_date, data):
    project_id = get_project_id(conn, project_name)
    module_id = get_module_id(conn, project_id, module_key)

    table_name = 'fact_sonar_data'
    table_details = sonar_config.get_table_details()[table_name]
    table_columns = [d['column_name'] for d in table_details]
    sql = utils.create_insert_statement(table_name, table_columns)
    
    column_names = [d['column_name'] for d in table_details]
    column_cast_func = {d['column_name']:d['cast_function'] for d in table_details if d['cast_function'] is not None}
    sql_data = []

    for d in data:
        o = {k:column_cast_func[k](v) for k,v in d.items()}
        z = {k:None for k in column_names}
        z.update(o)
        z['load_date'] = run_date
        z['project_id'] = project_id
        z['module_id'] = module_id
        sql_data.append(z)

    cur = conn.cursor()
    for d in sql_data:
        cur.execute(sql, d)

    cur.close()

def projects_index(session_obj, server, port, username, password):
    projects_index_url = "http://{0}:{1}/api/projects/index".format(server,port)
    resp = session_obj.get(projects_index_url, auth=(username, password))
    resp.raise_for_status()
    return resp.json()

def project_issues(session_obj, project):
    project_key = project['module_key']
    server = project['server']
    port = project['port']
    api = "api/issues/search?componentKeys={0}&ps=500".format(project_key)
    project_issues_url =  "http://{0}:{1}/{2}".format(server, port, api)
    print(project_issues_url)
    resp = session_obj.get(project_issues_url)
    resp.raise_for_status()
    return resp.json()


def populate_sonar_data(sql_conn):
    today = date.today()
    for project in sonar_config.get_projects_to_analyze():
        delete_by_date(sql_conn, project['project_name'], project['module_key'], today)
        session = requests.Session()
        session.trust_env = False
        session.auth = sonar_config.get_login_details()
        print(project)
        insert_sonar_data(sql_conn, project['project_name'], project['module_key'], today, project_issues(session, project)['issues'])


