import utils
import dim_date
import sonar

from config import db_config

sql_conn = utils.create_postgres_connection(db_config.db_user, 
                                            db_config.db_password, 
                                            db_config.db_instance, 
                                            db_config.db_server)

#dim_date.populate_dim_date(sql_conn)
#sonar.create_sonar_table(sql_conn)
sonar.populate_sonar_data(sql_conn)

sql_conn.commit()
sql_conn.close()
