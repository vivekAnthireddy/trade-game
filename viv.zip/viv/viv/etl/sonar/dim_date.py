from datetime import date, timedelta
import itertools

import utils

def dim_date_next(start_date="19700101", end_date="20501231"):
    try:
        start_date = date(int(start_date[0:4]), int(start_date[4:6]), int(start_date[6:8]))
        end_date = date(int(end_date[0:4]), int(end_date[4:6]), int(end_date[6:8]))
    except ValueError:
        print("Input(s) must be valid date value in YYYYMMDD format")
        sys.exit(1)

    while start_date <= end_date: 
        date_info = {'date_yyyymmdd': start_date.strftime('%Y%m%d'), 
                     'calendar_date': start_date.strftime('%Y-%m-%d'), 
                     'calendar_day': start_date.day, 
                     'calendar_month': start_date.month, 
                     'calendar_year': start_date.year} 
        date_info['iso_weekday'] = start_date.isoweekday() 
        date_info['day_number'] = start_date.toordinal() - date(start_date.year - 1, 12, 31).toordinal() 
        date_info['week_number'] = start_date.isocalendar()[1] 
        yield(date_info) 
        start_date = start_date + timedelta(1)

def get_todays_date_id(conn):
    today = date.today()
    sql = 'select date_id from dim_date where calendar_day = {0} and calendar_month = {1} and calendar_year = {2}'
    sql = sql.format(today.day,
                     today.month,
                     today.year)
    select_cursor = conn.cursor()
    select_cursor.execute(sql)
    date_id = select_cursor.fetchall()[0][0]
    select_cursor.close()
    return date_id

def populate_dim_date(conn):
    table_name = 'dim_date'
    table_columns = ['date_id', 'date_yyyymmdd', 'calendar_date', 'calendar_day', 'calendar_month',
                     'calendar_year', 'iso_weekday', 'day_number', 'week_number']
    sql = utils.create_insert_statement(table_name, table_columns)
    insert_cursor = conn.cursor()
    sql_data = []
    for data, date_id in zip(dim_date_next(), itertools.count()):
        data['date_id'] = date_id
        sql_data.append(data)

    print(len(sql_data))
    insert_cursor.executemany(sql, sql_data)
    insert_cursor.close()
