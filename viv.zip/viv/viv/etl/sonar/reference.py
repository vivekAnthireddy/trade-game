import itertools

import utils
from config import reference_config
from config import db_config

def load_modules_table(conn):
    table_details = reference_config.get_modules_ref_table()
    utils.create_table(conn, table_details)

    sql = 'insert into modules (module_name, sonar_project) values (:module_name, :sonar_project)'
    insert_cursor = conn.cursor()
    insert_cursor.prepare(sql)
    data = [{'module_name':'ABP', 'sonar_project':'amdocs.cust:abp-sonar:MAXIS-3000-ABP'},
            {'module_name':'ABP-CPP', 'sonar_project':'amdocs.cust:abp-sonar:MAXIS-3000-ABP-CPP'},
            {'module_name':'CRM', 'sonar_project':'amdocs.cust:crm-sonar:MAXIS-3000-CRM'},
            {'module_name':'OMNI', 'sonar_project':'amdocs.cust:omni-sonar:MAXIS-3000-OMNI'},
            {'module_name':'OMS', 'sonar_project':'amdocs.cust:oms-sonar:MAXIS-3000-OMS'}]
    insert_cursor.executemany(None, data)

def load_developers_table(conn):
    table_details = reference_config.get_developers_ref_table()
    utils.create_table(conn, table_details)

    sql = 'insert into developers (developer, module_name, scrum_team) values (:developer, :module_name, :scrum_team)'
    insert_cursor = conn.cursor()
    insert_cursor.prepare(sql)

    column_keys = ['developer', 'module_name', 'scrum_team']
    data = [['akashbha', 'ABP', 'ABP-1'], 
            ['alpandey', 'ABP', 'ABP-2'], 
            ['amitkoh', 'OMS', 'OMS-1'],
            ['ankitsir', 'CRM', 'CRM-1'], 
            ['ankittya', 'OMS', 'OMS-2'],
            ['arpitsi', 'CRM', 'CRM-2'], 
            ['bhatiapr', 'OMS', 'OMS-3'],
            ['chandrsh', 'OMS', 'OMS-4'],
            ['chzhang', 'ABP', 'ABP-3'],
            ['dejindal', 'OMNI', 'OMNI-1'],
            ['dejindal', 'OMS', 'OMS-1'],
            ['gamishra', 'OMS', 'OMS-2'],
            ['heenag', 'CRM', 'CRM-3'],
            ['heenaga', 'OMS', 'OMS-3'],
            ['jyotsnpa', 'OMS', 'OMS-4'],
            ['kapilbh', 'CRM', 'CRM-4'],
            ['keshashe', 'CRM', 'CRM-1'],
            ['krigupta', 'OMS', 'OMS-1'],
            ['mallikag', 'CRM', 'CRM-2'],
            ['mb_ccbsp', 'ABP-CPP', 'ABP-CPP-1'],
            ['mb_ccbsp', 'OMS', 'OMS-2'],
            ['meenalg', 'OMS', 'OMS-3'],
            ['munnap', 'OMS', 'OMS-4'],
            ['noundlas', 'OMS', 'OMS-1'],
            ['pdhingra', 'ABP', 'ABP-4'],
            ['poojaran', 'CRM', 'CRM-3'],
            ['prgaurav', 'ABP', 'ABP-1'],
            ['psingana', 'OMNI', 'OMNI-2'],
            ['sandiman', 'OMS', 'OMS-2'],
            ['shchauha', 'CRM', 'CRM-4'],
            ['shivamv', 'OMNI', 'OMNI-3'],
            ['sibsingh', 'OMNI', 'OMNI-4'],
            ['singhcha', 'ABP', 'ABP-1'],
            ['singhcha', 'ABP-CPP', 'ABP-CPP-2'],
            ['smalvi', 'OMS', 'OMS-3'],
            ['snehac', 'CRM', 'CRM-1'],
            ['sumedhal', 'OMS', 'OMS-4'],
            ['vhada', 'OMNI', 'OMNI-1'],
            ['virajj', 'CRM', 'CRM-2'],
            ['vpatil', 'CRM', 'CRM-3']]

    sql_data = []
    for keys, values in itertools.izip([column_keys] * len(data), data):
        sql_data.append(dict(itertools.izip(keys, values)))

    print(sql_data)
    insert_cursor.executemany(None, sql_data)
    insert_cursor.close()

if __name__ == '__main__':
    sql_conn = utils.create_oracle_connection(db_config.db_user, 
                                              db_config.db_password, 
                                              db_config.db_instance, 
                                              db_config.db_server)

    load_modules_table(sql_conn)
    load_developers_table(sql_conn)
    sql_conn.commit()
    sql_conn.close()





