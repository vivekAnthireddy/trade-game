import requests
import psycopg2
import logging
from sys import exit
import datetime
import base64, sys, os
import db_config
from sonar_statistics import build_statistics
import utils

def get_metrics(connection_details):
    '''Method to fetch the metric values of the given product'''
    cur.execute('select metric_keyword from public.dim_sonar_metrics')
    metrics=cur.fetchall()
    metrics=[keyword[0] for keyword in metrics]
    metrics=','.join(metrics)
    a = {'componentKey': connection_details['module_key'], 'metricKeys':metrics}
    project_metrics_url =  "http://{0}:{1}/api/measures/component".format(connection_details['server'], connection_details['port'])
    resp = requests.get(project_metrics_url, params=a,auth=(connection_details['username'],decrypt('SecretKey',connection_details['password'])))
    resp=resp.json()
    metric_values={}
    for metric in metrics.split(','):
        metric_values[metric]=0
    for metric in resp['component']['measures']:
        if 'value' in metric:
            metric_values[metric['metric']]=metric['value']
        else:
            metric_values[metric['metric']]=metric['periods'][0]['value']
    return metric_values

def get_last_update(connection_details):
    '''Method to fetch the last analysis date of a given product'''
    a = {'key': connection_details['module_key']}
    project_last_update_url ="http://{0}:{1}/api/projects?versions=true&format=json".format(connection_details['server'], connection_details['port'])
    resp = requests.get(project_last_update_url,params=a,auth = (connection_details['username'],decrypt('SecretKey',connection_details['password'])))
    resp=resp.json()
    return resp[0]['v'][resp[0]['lv']]['d']

def load_metric_data(metric_values,product_id):
    '''Method to load metric data to the database'''
    SQL="INSERT INTO public.fact_metric_data(metric_technical_debt,metric_new_technical_debt,metric_blocker_issues,metric_new_blocker_issues,metric_critical_issues,metric_new_critical_issues,metric_bugs,metric_vulnerabilities,metric_code_smells,metric_issues,metric_new_violations,metric_complexity,metric_unit_tests,metric_unit_test_coverage,metric_lines_of_code,metric_duplicated_lines,metric_last_update,metric_product_id) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"
    parameters=[metric_values['sqale_index'],metric_values['new_technical_debt'],metric_values['blocker_violations'],metric_values['new_blocker_violations'],metric_values['critical_violations'],metric_values['new_critical_violations'],metric_values['bugs'],metric_values['vulnerabilities'],metric_values['code_smells'],metric_values['violations'],metric_values['new_violations'],metric_values['complexity'],metric_values['tests'],metric_values['coverage'],metric_values['ncloc'],metric_values['duplicated_lines'],metric_values['last_analysis'],product_id]
    cur.execute(SQL,parameters)
    conn.commit()

def project_issues(session_obj, connection_details):
    '''Method to fetch the issues data of the given product'''
    project_key = connection_details['module_key']
    server = connection_details['server']
    port = connection_details['port']
    page_number=1
    api = "api/issues/search?componentKeys={0}&ps=500&p={1}&resolutions".format(project_key,page_number)
    project_issues_url =  "http://{0}:{1}/{2}".format(server, port, api)
    resp = session_obj.get(project_issues_url, auth=(connection_details['username'],decrypt('SecretKey',connection_details['password'])))
    resp.raise_for_status()
    data=resp.json()
    total=data['total']
    issues={}
    while True:
        for issue in data['issues']:
            key=issue.pop('key')
            issues[key]=issue
        if total<=500:
            break
        page_number+=1
        total-=500
        api = "api/issues/search?componentKeys={0}&ps=500&p={1}".format(project_key,page_number)
        project_issues_url =  "http://{0}:{1}/{2}".format(server, port, api)
        resp = session_obj.get(project_issues_url, auth=(connection_details['username'],decrypt('SecretKey',connection_details['password'])))
        resp.raise_for_status()
        data=resp.json()
    return issues

def load_issue_data(issues,project_id,product_id):
    '''Method to load metric data of the given product into the database'''
    last_analysis_date=datetime.datetime.now()
    SQL="INSERT INTO public.fact_issue_data(load_date,status,tags,component,assignee,key,message,debt,effort,line,creationdate,severity,author,resolution,rule,project,updatedate,subproject,closedate,type,componentid,project_id,product_id) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"
    for key,issue_data in issues.items():
        date=datetime.datetime.strptime(issue_data.get('creationDate'),'%Y-%m-%dT%H:%M:%S%z')
        issue_data['creationDate']=date.replace(tzinfo=None)
        date=datetime.datetime.strptime(issue_data.get('updateDate'),'%Y-%m-%dT%H:%M:%S%z')
        issue_data['updateDate']=date.replace(tzinfo=None)
        if issue_data.get('closeDate') is not None:
            date=datetime.datetime.strptime(issue_data.get('closeDate'),'%Y-%m-%dT%H:%M:%S%z')
            issue_data['closeDate']=date.replace(tzinfo=None)
        parameters=[last_analysis_date,issue_data.get('status'),issue_data.get('tags'),issue_data.get('component'),issue_data.get('assignee'),key,issue_data.get('message'),issue_data.get('debt'),issue_data.get('effort'),issue_data.get('line'),issue_data.get('creationDate'),issue_data.get('severity'),issue_data.get('author'),issue_data.get('resolution','Unresolved'),issue_data.get('rule'),issue_data.get('project'),issue_data.get('updateDate'),issue_data.get('subProject'),issue_data.get('closeDate'),issue_data.get('type'),issue_data.get('componentId'),project_id,product_id]
        cur.execute(SQL,parameters)
    conn.commit()
        
def decrypt(key, enc):
    '''Methoc to decrypt the password'''
    dec = []
    enc = base64.urlsafe_b64decode(enc).decode()
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)

if __name__== "__main__":
    '''Main driven function to fetch the sonar metric details'''
    program_name="SONAR"
    log_file_name="sonar_"+datetime.datetime.now().strftime("%d%m%Y%H%M%S")+".log"
    logger=utils.log(program_name,log_file_name)
    try:
        conn=psycopg2.connect("dbname="+db_config.db_instance+" user="+db_config.db_user+" password="+db_config.db_password+" host="+db_config.db_server)
        logger.info("Connected to the server....")
        cur = conn.cursor()
        cur.execute("DELETE FROM public.fact_issue_data")
        cur.execute("SELECT project_id, project_name from public.dim_project ORDER BY project_id ASC")
        logger.info("Fetched project details from database....")
        projects=cur.fetchall()
        for project in projects:
            sql="SELECT * from public.dim_sonar_product where product_project_id=%s ORDER BY product_id ASC;"
            logger.info("Fetched product details for project "+project[1]+"....")
            cur.execute(sql,[project[0]])
            project_products=cur.fetchall()
            try:
                if len(project_products)!=0:
                    project_products=map(list,project_products)
                    for product in project_products:
                        connection_details={'module_key':product[3],'server':product[4],'port':product[5],'username':product[6],'password':product[7]}
                        metric_values=get_metrics(connection_details)
                        logger.info("Fetched metric values from sonar for product "+product[2]+"....")
                        metric_values['sqale_index']=int(metric_values['sqale_index'])//480
                        metric_values['new_technical_debt']=int(metric_values['new_technical_debt'])//480
                        metric_values['last_analysis']=get_last_update(connection_details)
                        logger.info("Fetched last analysis date from sonar for product "+product[2]+"....")
                        SQL='select metric_last_update from public.fact_metric_data where metric_product_id=%s order by metric_last_update DESC LIMIT 1'
                        cur.execute(SQL,[product[0]])
                        last_analysis=cur.fetchall()
                        metric_values['last_analysis']=datetime.datetime.strptime(metric_values['last_analysis'],'%Y-%m-%dT%H:%M:%S%z')
                        metric_values['last_analysis']=metric_values['last_analysis'].replace(tzinfo=None)
                        last_analysis=list(map(list,last_analysis))
                        if len(last_analysis)!=0:
                            last_analysis=last_analysis[0]
                            if metric_values['last_analysis']>last_analysis[0]:
                                load_metric_data(metric_values,product[0])
                                logger.info("Loaded metric data to database for product "+product[2]+"....")
                        else:
                            load_metric_data(metric_values,product[0])
                        issues=project_issues(requests,connection_details)
                        logger.info("Fetched issues for product "+product[2]+"....")
                        load_issue_data(issues,project[0],product[0])
                        logger.info("Loaded issue data to database for product "+product[2]+"....")
                        build_statistics(conn,project[1],product[2],project[0],product[0])
                        logger.info("Finished weekly statistics for "+product[2]+"....")
                else:
                    logger.warning("Sonar product details for project "+project[1]+" doesn't exist in database....")
                    continue
            except Exception as error:
                logger.error("Failed to make a connection to the server")
                logger.error(error)
                continue
    except psycopg2.DatabaseError as error:
        logger.error(error)
        exit(1)
    finally:
        if conn is not None:
            conn.close()
