import networkx as nx
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import sys

def generate_graph(data,graph_path,project_id):
    '''Method to generate graphs for active streams'''
    Graph=nx.DiGraph()
    labels={}
    for stream in data:
        if stream['active_flag']==1:
            levelOfNode=stream['level']
            node=stream['stream_id']
            while True:
                Graph.add_edge(node,data[node]['Parent'])
                labels[node]=data[node]['Name']
                if data[node]['Parent']!='none':
                    labels[data[node]['Parent']]=data[data[node]['Parent']]['Name']
                levelOfNode-=1
                node=data[node]['Parent']
                if levelOfNode<=1:
                    break
    nx.draw_spring(Graph,k=10000,labels=labels,node_size=500,node_shape='o', node_color='skyblue', with_labels=True)
    path="active_"+str(project_id)+"_all.png"
    my_graph_path=os.path.join(graph_path,path)
    plt.savefig(my_graph_path,transparent=True)
    plt.clf()
    types_of_streams=['mainline','development','release']
    for each_type in types_of_streams:
        Graph=nx.DiGraph()
        labels={}
        for stream in data:
            if stream['active_flag']==1 and stream['Type']==each_type:
                levelOfNode=stream['level']
                node=stream['stream_id']
                while True:
                    Graph.add_edge(node,data[node]['Parent'])
                    labels[node]=data[node]['Name']
                    if data[node]['Parent']!='none':
                        labels[data[node]['Parent']]=data[data[node]['Parent']]['Name']
                    levelOfNode-=1
                    node=data[node]['Parent']
                    if levelOfNode<=1:
                        break
        nx.draw_spring(Graph,k=10000,labels=labels,node_size=500,node_shape='o', node_color='skyblue', with_labels=True)
        path="active_"+str(project_id)+"_"+each_type+".png"
        my_graph_path=os.path.join(graph_path,path)
        plt.savefig(my_graph_path,transparent=True)
        plt.clf()
