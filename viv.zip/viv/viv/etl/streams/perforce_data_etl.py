from P4 import P4,P4Exception
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import networkx as nx
import psycopg2
import os, shutil, glob
import logging
import sys
import db_config
import base64
from generate_graph import generate_graph
from perforce_statistics import build_statistics
import utils
import config

def remove_task(all_streams):
    '''Method to remove the task streams from the list of all streams.'''
    all_streams = [stream for stream in all_streams if not stream['Type']=='task']
    return all_streams

def get_update(all_streams):
    '''Method to get the last update date using changes command.'''
    for stream in all_streams:
        stream_name=stream['Stream']
        stream_name+="/..."
        changes=p4.run("changes","-m","1",stream_name)
        if len(changes)!=0:
            stream['Update']=changes[0]['time']
    return all_streams

def get_active_streams(all_streams,project_id,active_threshold):
    '''Method to update the steam_active_flag.'''
    active_streams=0
    index=0
    for stream in all_streams:
        stream['creation']=stream.pop('Access')
        stream['active_flag']=active(stream['Update'],active_threshold)
        if stream['active_flag'] and stream['Type']!='virtual':
            active_streams+=1
        stream['alive_time']=0
        if stream['Parent']=='none':
            stream['level']=1
        else:
            stream['level']=0
        stream['project_id']=project_id
        stream['stream_id']=index
        index+=1
    return all_streams,active_streams

def active(update,active_threshold):
    '''Method which deterrmines whether the stream is active or not.'''
    time=datetime.utcfromtimestamp(int(update))
    if time>=active_threshold:
        return 1
    return 0

def update_parent(all_streams):
    '''Method to update the parent stream information.'''
    for stream1 in all_streams:
        for stream2 in all_streams:
            if stream1['Parent']==stream2['Stream']:
                stream1['Parent']=stream2['stream_id']
                break
    return all_streams

def remove_virtual(all_streams):
    '''Method to remove virtual streams.'''
    for stream in all_streams:
        if stream['Parent']!='none' and all_streams[stream['Parent']]['Type']=='virtual':
            super_parent_id=all_streams[stream['Parent']]['stream_id']
            while True:
                super_parent_id=all_streams[super_parent_id]['Parent']
                if all_streams[super_parent_id]['Type']!='virtual':
                    stream['Parent']=super_parent_id
                    break
    all_streams = [stream for stream in all_streams if not stream['Type']=='virtual']
    for stream1 in all_streams:
        for stream2 in all_streams:
            if stream1['Parent']==stream2['stream_id']:
                stream1['Parent']=all_streams.index(stream2)
                break
    stream_id=0
    for stream in all_streams:
        stream['stream_id']=stream_id
        stream_id+=1
    return all_streams

def get_creation(all_streams):
    '''Method to get the creation date of a stream using changes command.'''
    for stream in all_streams:
        stream_name=stream['Stream']
        stream_name+="/..."
        owner=stream['Owner']
        changes=p4.run("changes","-t","-u",owner,stream_name)
        if len(changes)!=0:
            stream['creation']=changes[-1]['time']
        else:
            changes=p4.run("changes",stream_name)
            if len(changes)!=0:
                stream['creation']=changes[-1]['time']
    return all_streams

def update_alive_time(all_streams):
    '''Method to update the alive_time of a stream.'''
    for stream in all_streams:
        stream['alive_time']=(datetime.utcfromtimestamp(int(stream['Update']))-datetime.utcfromtimestamp(int(stream['creation']))).days
    return all_streams

def update_level(all_streams,queue,queue_length):
    '''Method to update the level of a stream this is used in pictorial representation of the streams.'''
    max_level=1
    for node in queue:
        for stream in all_streams:
            if node==stream['Parent']:
                queue.append(stream['stream_id'])
    queue=queue[queue_length:]
    for node in queue:
        all_streams[node]['level']=all_streams[all_streams[node]['Parent']]['level']+1
    max_level=all_streams[queue[-1]]['level']
    return all_streams,max_level

def load_to_database(data,project_id,project_name,active_streams,max_level):
    '''Method to save the stream data of a project into the database.'''
    project_last_update=datetime.now()
    project_branches=len(data)
    project_max_depth=max_level
    SQL="INSERT INTO public.fact_project_stream(project_name,project_last_update,project_branches,project_active_branches,project_max_depth,project_main_id) VALUES(%s,%s,%s,%s,%s,%s);"
    parameters=[project_name,project_last_update,project_branches,active_streams,project_max_depth,project_id]
    cur.execute(SQL,parameters)
    conn.commit()
    cur.execute("SELECT MAX(stream_id) FROM public.fact_stream")
    last_stream_id=cur.fetchall()[0][0]
    if last_stream_id is None:
        last_stream_id=0
    stream_id,parent=0,0
    for stream in data:
        stream_id=stream['stream_id']+1+last_stream_id
        if stream['Parent']=='none':
            parent=0
        else:
            parent=stream['Parent']+1+last_stream_id
        update=datetime.utcfromtimestamp(int(stream['Update']))
        creation=datetime.utcfromtimestamp(int(stream['creation']))
        SQL="INSERT INTO public.fact_stream VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);"
        parameters=[stream_id,stream['Stream'],update,stream['Owner'],stream['Name'],parent,stream['Type'],stream['baseParent'],creation,stream['active_flag'],stream['alive_time'],stream['level'],stream['project_id']]
        cur.execute(SQL,parameters)
    conn.commit()
    logger.info("Data entered successfully....")

def encrypt(key, clear):
    '''Encryption of password'''
    enc = []
    for i in range(len(clear)):
        key_c = key[i % len(key)]
        enc_c = chr((ord(clear[i]) + ord(key_c)) % 256)
        enc.append(enc_c)
    return base64.urlsafe_b64encode("".join(enc).encode()).decode()

def decrypt(key, enc):
    '''Decryption of password'''
    dec = []
    enc = base64.urlsafe_b64decode(enc).decode()
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)

def delete_graphs():
    '''Method to delete the old graphs'''
    my_path=os.path.abspath(os.path.dirname(__file__))
    graph_path=os.path.join(my_path,'../../frontend/interface/streams/static/streams/active_*.png')
    for f in glob.glob(graph_path):
            os.remove(f)
    return os.path.join(my_path,'../../frontend/interface/streams/static/streams/')

if __name__== "__main__":
    '''Main driven function to fetch perforce stream details of a project'''
    active_threshold=date.today() + relativedelta(months=-config.perforce_active_stream_threshold)
    active_threshold=datetime.combine(active_threshold,datetime.min.time())
    program_name="PERFORCE"
    log_file_name="perforce_"+datetime.now().strftime("%d%m%Y%H%M%S")+".log"
    logger=utils.log(program_name,log_file_name)
    try:
        conn=psycopg2.connect("dbname="+db_config.db_instance+" user="+db_config.db_user+" password="+db_config.db_password+" host="+db_config.db_server)
        logger.info("Database Connected....")
        cur = conn.cursor()
        cur.execute("DELETE FROM public.fact_stream")
        conn.commit()
        graph_path=delete_graphs()
        cur.execute("SELECT project_id, project_name from public.dim_project ORDER BY project_id ASC")
        projects=cur.fetchall()
        for project in projects:
            logger.info("project Name: "+project[1])
            sql="SELECT * from public.dim_perforce_project where project_id=%s;"
            cur.execute(sql,[project[0]])
            connection_details=cur.fetchall()
            try:
                if len(connection_details)==1:
                    connection_details=list(connection_details[0])
                    p4=P4()
                    p4.port=connection_details[1]
                    p4.user=connection_details[4]
                    p4.password=decrypt('SecretKey',connection_details[5])
                    p4.connect()
                    p4.run_login()
                    logger.info("Connected to the server....")
                    project_path="Stream=//"+connection_details[3]+"/..."
                    all_streams=p4.run("streams","-F",project_path,"-T","Stream,Update,Access,Owner,Name,Parent,Type,baseParent")
                    if len(all_streams)!=0:
                        logger.info("Fetched stream data....")
                        all_streams=remove_task(all_streams)
                        logger.info("Removed task streams....")
                        all_streams=get_update(all_streams)
                        logger.info("Fetched last update time from changes command....")
                        all_streams,active_streams=get_active_streams(all_streams,project[0],active_threshold)
                        logger.info("updated active branches....")
                        all_streams=update_parent(all_streams)
                        logger.info("updated parent information....")
                        all_streams=remove_virtual(all_streams)
                        logger.info("Removed virtual streams....")
                        all_streams=get_creation(all_streams)
                        logger.info("Fetched the stream creation time from changes command....")
                        all_streams=update_alive_time(all_streams)
                        logger.info("Updated the alive time of a stream....")
                        
                        queue=[]
                        for stream in all_streams:
                            if stream['level']==1:
                                queue.append(stream['stream_id'])
                    
                        data,max_level=update_level(all_streams,queue,len(queue))
                        logger.info("Updated the level of each stream....")
                        
                        load_to_database(data,project[0],project[1],active_streams,max_level)
                        generate_graph(data,graph_path,project[0])
                        build_statistics(conn,project[0],project[1])
                    else:
                        logger.warning("Stream details are not available for "+project[1])
                else:
                    logger.error("Connection details for "+project[1]+" doesn't exist in database....")
                    continue
            except (P4Exception,Exception) as error:
                logger.error(error)
                logger.error("Failed to make a connection to the server")
                continue
    except  psycopg2.DatabaseError as error:
        logger.error(error)
        logger.error("Failed to make connection to Database")
        sys.exit(1)
    finally:
        if conn is not None:
            conn.close()
