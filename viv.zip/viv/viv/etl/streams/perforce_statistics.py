from datetime import timedelta, datetime, date
import psycopg2
import sys
import db_config
from utils import week_range

def build_statistics(conn,project_id,project_name):
    '''Method to build statistics for perforce'''
    cur=conn.cursor()
    time=date.today()
    start_date,end_date=week_range(time)
    start_date=datetime.combine(start_date,datetime.min.time())
    end_date=datetime.combine(end_date,datetime.max.time())
    week_no=date.today().isocalendar()[1]
    SQL='delete from public.fact_perforce_statistics where statistic_start_date=%s and statistic_end_date=%s and statistic_project_id=%s'
    cur.execute(SQL,[start_date,end_date,project_id])
    SQL='select * from public.fact_project_stream where project_last_update>=%s and project_last_update<=%s and project_main_id=%s'
    cur.execute(SQL,[start_date,end_date,project_id])
    week_data=cur.fetchall()
    week_data=[ list(i) for i in week_data]
    total_streams=[]
    active_streams=[]
    max_depth=[]
    for data in week_data:
        total_streams.append(data[3])
        active_streams.append(data[4])
        max_depth.append(data[5])
    SQL='INSERT INTO public.fact_perforce_statistics (statistic_project_name,statistic_week_no,statistic_start_date,statistic_end_date,statistic_average_branches,statistic_average_active_branches,statistic_average_max_depth,statistic_project_id) values(%s,%s,%s,%s,%s,%s,%s,%s)'
    parameters=[project_name,week_no,start_date,end_date,sum(total_streams)/len(total_streams),sum(active_streams)/len(active_streams),sum(max_depth)/len(max_depth),project_id]
    cur.execute(SQL,parameters)
    conn.commit()

