import psycopg2
import logging
from datetime import date,datetime,timedelta
import os, sys
import config

def create_postgres_connection(db_user, db_password, db_instance, db_server):
    con = psycopg2.connect("dbname="+db_instance+" user="+db_user+" password="+db_password+" host="+db_server)
    return con

def create_insert_statement(table_name, column_names):
    parameter_placeholders = ['%({})s'.format(d) for d in column_names]
    sql_stmt = "insert into {0} ({1}) values ({2})".format(table_name,
                                                           ",".join(column_names),
                                                           ",".join(parameter_placeholders))
    return sql_stmt

def create_table(conn, table_details):
    for table_name, details in table_details.items():
        column_names = [d['column_name'] for d in details]
        column_types = [d['column_type'] for d in details]
        sql = ("create table " + table_name + "("
               + ",".join([" ".join(k) for k in zip(column_names, column_types)])
               + ")")
        print(sql)
        conn.cursor().execute("drop table if exists " + table_name)
        conn.cursor().execute(sql)

def log(program_name,log_file_name):
    log_file_name=os.path.join(config.path_to_log_file,log_file_name)
    logger = logging.getLogger(program_name)
    logger.setLevel(logging.DEBUG)
    fh = logging.FileHandler(log_file_name)
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.ERROR)
    formatter = logging.Formatter('[%(asctime)s] - %(name)s - %(filename)s:%(lineno)d - %(levelname)s:%(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

def week_range(date):
    '''
    finding start date and end date when any date in that particular week is passed
    '''
    year, week, dow = date.isocalendar()
    start_date = date - timedelta(dow-1)
    end_date = start_date + timedelta(6)
    return (start_date, end_date)
