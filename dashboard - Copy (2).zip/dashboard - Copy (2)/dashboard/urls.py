from django.conf.urls import include, url
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^swp/',include('swp.urls',namespace='swp')),
    url(r'^project/$',views.project,name='project'),
    url(r'^project/add$',views.FactProjectCreate.as_view(),name='add_project'),
    url(r'^upload/csv/$',views.upload_csv,name='upload_csv'),
]
