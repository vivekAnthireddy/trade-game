from django.forms import ModelForm
from swp.models import FactProject
from swp.models import DimSwpConnectionDetails

class FactprojectForm(ModelForm):
    class Meta:
        model=FactProject
        fields=['project_name','project_division','project_head','project_phase','project_creation_date','project_created_by','project_modified_date','project_modified_by']



class DimSwpConnectionDetailsForm(ModelForm):
    class Meta:
        model=DimSwpConnectionDetails
        fields=['oralce_db_username','oracle_db_password','oracle_db_hostname','oralce_db_sid','unix_server_hostname','unix_server_username','unix_server_password','unix_server_log_files_path','unix_server_log_files_name','project_name','project']