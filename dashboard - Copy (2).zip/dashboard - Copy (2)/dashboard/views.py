from django.http import Http404
from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from swp.models import FactProject
from django.views.generic.edit import CreateView,UpdateView
from django.views import generic
import datetime
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from .forms import FactprojectForm


def project(request):
    all_projects = FactProject.objects.all()
    template = loader.get_template('swp/project.html')
    context = {
        'all_projects': all_projects,
    }
    return HttpResponse(template.render(context, request))

class FactProjectCreate(CreateView):
    model=FactProject
    fields = ['project_name', 'project_division', 'project_head', 'project_phase', 'project_creation_date',
              'project_created_by']

    def get_initial(self):
        return {'project_creation_date': datetime.datetime.now(), 'project_created_by': 'User',
                'project_modified_date': None, 'project_modified_by': None}

def upload_csv(request):
    data = {}
    if "GET" == request.method:
        return render(request, "swp/project.html", data)
    try:
        csv_file = request.FILES["csv_file"]
        if not csv_file.name.endswith('.csv'):
            print('File is not CSV type')
            return HttpResponseRedirect(reverse("project"))
        if csv_file.multiple_chunks():
            print("Uploaded file is too big")
            return HttpResponseRedirect(reverse("project"))

        file_data = csv_file.read().decode("utf-8")

        lines = file_data.split("\n")
        for line in lines:
            fields = line.split(",")
            if len(fields) == 4:
                data_dict = {}
                data_dict["project_name"] = fields[0]
                data_dict["project_division"] = fields[1]
                data_dict["project_head"] = fields[2]
                data_dict["project_phase"] = fields[3]
                data_dict["project_creation_date"] = datetime.datetime.now()
                data_dict["project_created_by"] = 'User'
                try:
                    form = FactprojectForm(data_dict)
                    if form.is_valid():
                        form.save()
                    else:
                        print(form.errors.as_json())
                        pass
                except Exception as e:
                    print(e)
                    pass

    except Exception as e:
        print(e)
        print("Unable to upload file.")

    return HttpResponseRedirect(reverse("project"))