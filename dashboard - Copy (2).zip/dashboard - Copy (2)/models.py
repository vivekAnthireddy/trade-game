# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
#
# Also note: You'll have to insert the output of 'django-admin sqlcustom [app_label]'
# into your database.
from __future__ import unicode_literals

from django.db import models


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup)
    permission = models.ForeignKey('AuthPermission')

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group_id', 'permission_id'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType')
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type_id', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.BooleanField()
    username = models.CharField(unique=True, max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=254)
    is_staff = models.BooleanField()
    is_active = models.BooleanField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class DimFlow(models.Model):
    flow_id = models.IntegerField(primary_key=True)
    flow_name = models.CharField(max_length=50, blank=True, null=True)
    flow_creation_date = models.DateTimeField(blank=True, null=True)
    project = models.ForeignKey('FactProject', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_flow'


class DimJob(models.Model):
    job_id = models.BigIntegerField(primary_key=True)
    job_name = models.CharField(max_length=50, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    job_start_time = models.DateTimeField(blank=True, null=True)
    job_end_time = models.DateTimeField(blank=True, null=True)
    job_status = models.CharField(max_length=20, blank=True, null=True)
    stream = models.ForeignKey('DimStream', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_job'


class DimLogData(models.Model):
    date = models.DateTimeField(blank=True, null=True)
    job_or_stream = models.CharField(max_length=20, blank=True, null=True)
    name = models.CharField(max_length=50, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    status = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_log_data'


class DimProject(models.Model):
    project_id = models.AutoField(primary_key=True)
    project_name = models.TextField()

    class Meta:
        managed = False
        db_table = 'dim_project'


class DimSonarModule(models.Model):
    module_id = models.AutoField(primary_key=True)
    project = models.ForeignKey(DimProject)
    module_key = models.TextField(blank=True, null=True)
    module_name = models.TextField(blank=True, null=True)
    module_short_name = models.TextField(blank=True, null=True)
    module_type = models.TextField(blank=True, null=True)
    sonar_server = models.TextField(blank=True, null=True)
    sonar_port = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_sonar_module'
        unique_together = (('module_id', 'project_id'),)


class DimStream(models.Model):
    stream_id = models.BigIntegerField(primary_key=True)
    stream_name = models.CharField(max_length=50, blank=True, null=True)
    stream_start_time = models.DateTimeField(blank=True, null=True)
    stream_end_time = models.DateTimeField(blank=True, null=True)
    stream_status = models.CharField(max_length=20, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    flow = models.ForeignKey(DimFlow, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_stream'


class DimSwpConnectionDetails(models.Model):
    swp_connection_details_id = models.AutoField(primary_key=True)
    oralce_db_username = models.CharField(max_length=50)
    oracle_db_password = models.CharField(max_length=50)
    oracle_db_hostname = models.CharField(max_length=50)
    oralce_db_sid = models.CharField(db_column='oralce_db_SID', max_length=50)  # Field name made lowercase.
    unix_server_hostname = models.CharField(max_length=50)
    unix_server_username = models.CharField(max_length=50)
    unix_server_password = models.CharField(max_length=50)
    unix_server_log_files_path = models.CharField(max_length=255)
    unix_server_log_files_name = models.CharField(max_length=50)
    project_name = models.CharField(max_length=50)
    project = models.ForeignKey('FactProject', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_swp_connection_details'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', blank=True, null=True)
    user = models.ForeignKey(AuthUser)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class FactProject(models.Model):
    project_id = models.AutoField(primary_key=True)
    project_name = models.CharField(max_length=50, blank=True, null=True)
    project_division = models.CharField(max_length=50, blank=True, null=True)
    project_head = models.CharField(max_length=50, blank=True, null=True)
    project_phase = models.CharField(max_length=50, blank=True, null=True)
    project_creation_date = models.DateTimeField(blank=True, null=True)
    project_created_by = models.CharField(max_length=50, blank=True, null=True)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_project'


class FactRunDate(models.Model):
    last_run_date = models.DateTimeField(primary_key=True)

    class Meta:
        managed = False
        db_table = 'fact_run_date'


class FactSonarData(models.Model):
    project = models.ForeignKey(DimProject)
    module_id = models.IntegerField()
    load_date = models.DateField(blank=True, null=True)
    status = models.TextField(blank=True, null=True)
    tags = models.TextField(blank=True, null=True)
    component = models.TextField(blank=True, null=True)
    flows = models.TextField(blank=True, null=True)
    assignee = models.TextField(blank=True, null=True)
    key = models.TextField(blank=True, null=True)
    message = models.TextField(blank=True, null=True)
    debt = models.TextField(blank=True, null=True)
    effort = models.TextField(blank=True, null=True)
    line = models.TextField(blank=True, null=True)
    creationdate = models.TextField(blank=True, null=True)
    severity = models.TextField(blank=True, null=True)
    author = models.TextField(blank=True, null=True)
    resolution = models.TextField(blank=True, null=True)
    rule = models.TextField(blank=True, null=True)
    textrange = models.TextField(blank=True, null=True)
    project_0 = models.TextField(db_column='project', blank=True, null=True)  # Field renamed because of name conflict.
    updatedate = models.TextField(blank=True, null=True)
    subproject = models.TextField(blank=True, null=True)
    closedate = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    componentid = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fact_sonar_data'


class SwpFactproject(models.Model):
    project_id = models.AutoField(primary_key=True)
    project_name = models.CharField(max_length=50, blank=True, null=True)
    project_division = models.CharField(max_length=50, blank=True, null=True)
    project_head = models.CharField(max_length=50, blank=True, null=True)
    project_phase = models.CharField(max_length=50, blank=True, null=True)
    project_creation_date = models.DateTimeField(blank=True, null=True)
    project_created_by = models.CharField(max_length=50, blank=True, null=True)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'swp_factproject'
