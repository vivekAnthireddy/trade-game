# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('swp', '0005_auto_20180614_1221'),
    ]

    operations = [
        migrations.CreateModel(
            name='DimSwpConnectionDetails',
            fields=[
                ('swp_connection_details_id', models.AutoField(primary_key=True, serialize=False)),
                ('oralce_db_username', models.CharField(max_length=50)),
                ('oracle_db_password', models.CharField(max_length=50)),
                ('oracle_db_hostname', models.CharField(max_length=50)),
                ('oralce_db_sid', models.CharField(max_length=50, db_column='oralce_db_SID')),
                ('unix_server_hostname', models.CharField(max_length=50)),
                ('unix_server_username', models.CharField(max_length=50)),
                ('unix_server_password', models.CharField(max_length=50)),
                ('unix_server_log_files_path', models.CharField(max_length=255)),
                ('unix_server_log_files_name', models.CharField(max_length=50)),
                ('project_name', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'dim_swp_connection_details',
                'managed': False,
            },
        ),
    ]
