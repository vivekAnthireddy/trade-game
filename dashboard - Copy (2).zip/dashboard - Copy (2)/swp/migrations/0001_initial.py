# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='AuthGroup',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('name', models.CharField(max_length=80, unique=True)),
            ],
            options={
                'db_table': 'auth_group',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='AuthUser',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('password', models.CharField(max_length=128)),
                ('last_login', models.DateTimeField(blank=True, null=True)),
                ('is_superuser', models.BooleanField()),
                ('username', models.CharField(max_length=30, unique=True)),
                ('first_name', models.CharField(max_length=30)),
                ('last_name', models.CharField(max_length=30)),
                ('email', models.CharField(max_length=254)),
                ('is_staff', models.BooleanField()),
                ('is_active', models.BooleanField()),
                ('date_joined', models.DateTimeField()),
            ],
            options={
                'db_table': 'auth_user',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DimFlow',
            fields=[
                ('flow_id', models.IntegerField(primary_key=True, serialize=False)),
                ('flow_name', models.CharField(max_length=50, blank=True, null=True)),
                ('flow_creation_date', models.DateTimeField(blank=True, null=True)),
                ('project_id', models.IntegerField(blank=True, null=True)),
            ],
            options={
                'db_table': 'dim_flow',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DimJob',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('job_name', models.CharField(max_length=50)),
                ('job_start_time', models.DateTimeField(blank=True, null=True)),
                ('job_end_time', models.DateTimeField(blank=True, null=True)),
                ('status', models.CharField(max_length=20, blank=True, null=True)),
            ],
            options={
                'db_table': 'dim_job',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DimLogData',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('date', models.DateTimeField(blank=True, null=True)),
                ('job_or_stream', models.CharField(max_length=20, blank=True, null=True)),
                ('name', models.CharField(max_length=50, blank=True, null=True)),
                ('alias', models.CharField(max_length=50, blank=True, null=True)),
                ('status', models.CharField(max_length=20, blank=True, null=True)),
            ],
            options={
                'db_table': 'dim_log_data',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DimProject',
            fields=[
                ('project_id', models.AutoField(primary_key=True, serialize=False)),
                ('project_name', models.TextField()),
            ],
            options={
                'db_table': 'dim_project',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DimStream',
            fields=[
                ('stream_name', models.CharField(max_length=50, blank=True, null=True)),
                ('stream_start_time', models.DateTimeField(blank=True, null=True)),
                ('stream_end_time', models.DateTimeField(blank=True, null=True)),
                ('status', models.CharField(max_length=20, blank=True, null=True)),
                ('alias', models.CharField(primary_key=True, max_length=50, serialize=False)),
            ],
            options={
                'db_table': 'dim_stream',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoAdminLog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('action_time', models.DateTimeField()),
                ('object_id', models.TextField(blank=True, null=True)),
                ('object_repr', models.CharField(max_length=200)),
                ('action_flag', models.SmallIntegerField()),
                ('change_message', models.TextField()),
            ],
            options={
                'db_table': 'django_admin_log',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoContentType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('app_label', models.CharField(max_length=100)),
                ('model', models.CharField(max_length=100)),
            ],
            options={
                'db_table': 'django_content_type',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoMigrations',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('app', models.CharField(max_length=255)),
                ('name', models.CharField(max_length=255)),
                ('applied', models.DateTimeField()),
            ],
            options={
                'db_table': 'django_migrations',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoSession',
            fields=[
                ('session_key', models.CharField(primary_key=True, max_length=40, serialize=False)),
                ('session_data', models.TextField()),
                ('expire_date', models.DateTimeField()),
            ],
            options={
                'db_table': 'django_session',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='FactRunDate',
            fields=[
                ('last_run_date', models.DateField(primary_key=True, serialize=False)),
            ],
            options={
                'db_table': 'fact_run_date',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='FactSonarData',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('module_id', models.IntegerField()),
                ('load_date', models.DateField(blank=True, null=True)),
                ('status', models.TextField(blank=True, null=True)),
                ('tags', models.TextField(blank=True, null=True)),
                ('component', models.TextField(blank=True, null=True)),
                ('flows', models.TextField(blank=True, null=True)),
                ('assignee', models.TextField(blank=True, null=True)),
                ('key', models.TextField(blank=True, null=True)),
                ('message', models.TextField(blank=True, null=True)),
                ('debt', models.TextField(blank=True, null=True)),
                ('effort', models.TextField(blank=True, null=True)),
                ('line', models.TextField(blank=True, null=True)),
                ('creationdate', models.TextField(blank=True, null=True)),
                ('severity', models.TextField(blank=True, null=True)),
                ('author', models.TextField(blank=True, null=True)),
                ('resolution', models.TextField(blank=True, null=True)),
                ('rule', models.TextField(blank=True, null=True)),
                ('textrange', models.TextField(blank=True, null=True)),
                ('project_0', models.TextField(blank=True, null=True, db_column='project')),
                ('updatedate', models.TextField(blank=True, null=True)),
                ('subproject', models.TextField(blank=True, null=True)),
                ('closedate', models.TextField(blank=True, null=True)),
                ('type', models.TextField(blank=True, null=True)),
                ('componentid', models.TextField(blank=True, null=True)),
            ],
            options={
                'db_table': 'fact_sonar_data',
                'managed': False,
            },
        ),
    ]
