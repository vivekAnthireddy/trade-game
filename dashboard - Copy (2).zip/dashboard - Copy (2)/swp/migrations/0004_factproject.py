# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('swp', '0003_auto_20180612_1900'),
    ]

    operations = [
        migrations.CreateModel(
            name='FactProject',
            fields=[
                ('project_id', models.AutoField(primary_key=True, serialize=False)),
                ('project_name', models.CharField(max_length=50, blank=True, null=True)),
                ('project_division', models.CharField(max_length=50, blank=True, null=True)),
                ('project_head', models.CharField(max_length=50, blank=True, null=True)),
                ('project_phase', models.CharField(max_length=50, blank=True, null=True)),
                ('project_creation_date', models.DateTimeField(blank=True, null=True)),
                ('project_created_by', models.CharField(max_length=50, blank=True, null=True)),
                ('project_modified_date', models.DateTimeField(blank=True, null=True)),
                ('project_modified_by', models.CharField(max_length=50, blank=True, null=True)),
            ],
        ),
    ]
