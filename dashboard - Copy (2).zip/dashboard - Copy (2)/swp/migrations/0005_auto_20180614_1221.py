# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('swp', '0004_factproject'),
    ]

    operations = [
        migrations.AlterModelTable(
            name='factproject',
            table='fact_project',
        ),
    ]
