from django.http import Http404
from django.http import HttpResponseRedirect
from django.template import loader
from django.shortcuts import render
from .models import FactProject,DimSwpConnectionDetails
from django.views.generic.edit import CreateView


def index(request,project_id):
    try:
        conn = DimSwpConnectionDetails.objects.get(project_id=project_id)
        project=FactProject.objects.get(pk=project_id)
    except FactProject.DoesNotExist:
        raise Http404("Project Doesn't exist")
    except DimSwpConnectionDetails.DoesNotExist:
        return HttpResponseRedirect('add_swp_connect_details')
    return render(request,'swp/index.html',{'project': project})

class add_swp_connect_details(CreateView):
    model=DimSwpConnectionDetails
    fields = ['oralce_db_username','oracle_db_password','oracle_db_hostname','oralce_db_sid','unix_server_hostname','unix_server_username','unix_server_password','unix_server_log_files_path','unix_server_log_files_name','project_name','project']

    def get_initial(self):
        pid = self.kwargs['project_id']
        return {'project': pid}

    def get_context_data(self, **kwargs):
        context = super(add_swp_connect_details, self).get_context_data(**kwargs)
        context['project_id'] = self.kwargs['project_id']
        return context