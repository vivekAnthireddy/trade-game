from __future__ import unicode_literals
from django.core.urlresolvers import reverse

from django.db import models

class FactProject(models.Model):
    project_id = models.AutoField(primary_key=True)
    project_name = models.CharField(max_length=50, blank=True, null=True)
    project_division = models.CharField(max_length=50, blank=True, null=True)
    project_head = models.CharField(max_length=50, blank=True, null=True)
    project_phase = models.CharField(max_length=50, blank=True, null=True)
    project_creation_date = models.DateTimeField(blank=True, null=True)
    project_created_by = models.CharField(max_length=50, blank=True, null=True)
    project_modified_date = models.DateTimeField(blank=True, null=True)
    project_modified_by = models.CharField(max_length=50, blank=True, null=True)

    def get_absolute_url(self):
        return reverse('project')

    class Meta:
        db_table='fact_project'


class DimSwpConnectionDetails(models.Model):
    swp_connection_details_id = models.AutoField(primary_key=True)
    oralce_db_username = models.CharField(max_length=50)
    oracle_db_password = models.CharField(max_length=50)
    oracle_db_hostname = models.CharField(max_length=50)
    oralce_db_sid = models.CharField(db_column='oralce_db_SID', max_length=50)  # Field name made lowercase.
    unix_server_hostname = models.CharField(max_length=50)
    unix_server_username = models.CharField(max_length=50)
    unix_server_password = models.CharField(max_length=50)
    unix_server_log_files_path = models.CharField(max_length=255)
    unix_server_log_files_name = models.CharField(max_length=50)
    project_name = models.CharField(max_length=50)
    project = models.ForeignKey('FactProject', blank=True, null=True)


    def get_absolute_url(self):
        return reverse('project')

    class Meta:
        db_table = 'dim_swp_connection_details'





class DimFlow(models.Model):
    flow_id = models.IntegerField(primary_key=True)
    flow_name = models.CharField(max_length=50, blank=True, null=True)
    flow_creation_date = models.DateTimeField(blank=True, null=True)
    project = models.ForeignKey('FactProject', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_flow'

class DimStream(models.Model):
    stream_id = models.BigIntegerField(primary_key=True)
    stream_name = models.CharField(max_length=50, blank=True, null=True)
    stream_start_time = models.DateTimeField(blank=True, null=True)
    stream_end_time = models.DateTimeField(blank=True, null=True)
    stream_status = models.CharField(max_length=20, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    flow = models.ForeignKey(DimFlow, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_stream'

class DimJob(models.Model):
    job_id = models.BigIntegerField(primary_key=True)
    job_name = models.CharField(max_length=50, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    job_start_time = models.DateTimeField(blank=True, null=True)
    job_end_time = models.DateTimeField(blank=True, null=True)
    job_status = models.CharField(max_length=20, blank=True, null=True)
    stream = models.ForeignKey('DimStream', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dim_job'


class FactRunDate(models.Model):
    last_run_date = models.DateTimeField(primary_key=True)

    class Meta:
        managed = False
        db_table = 'fact_run_date'