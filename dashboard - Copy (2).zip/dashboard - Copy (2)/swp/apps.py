from django.apps import AppConfig

class SwpConfig(AppConfig):
    name='swp'