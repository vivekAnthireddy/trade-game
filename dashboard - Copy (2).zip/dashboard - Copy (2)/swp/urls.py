from django.conf.urls import url
from . import views



urlpatterns = [

    url(r'^(?P<project_id>[0-9]+)/$',views.index,name='index'),
    url(r'^(?P<project_id>[0-9]+)/add_swp_connect_details/$',views.add_swp_connect_details.as_view(),name='connect_details'),

]
