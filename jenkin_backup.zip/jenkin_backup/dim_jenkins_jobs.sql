DROP TABLE if exists public.dim_jenkins_jobs cascade;

CREATE TABLE public.dim_jenkins_jobs
(
    job_id serial,
    job_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    job_hostname character varying(50) COLLATE pg_catalog."default",
    job_port_no integer,
    CONSTRAINT dim_jenkins_jobs_pkey PRIMARY KEY (job_id)
)