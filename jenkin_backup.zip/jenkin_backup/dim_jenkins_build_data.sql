DROP TABLE if exists public.dim_jenkins_build cascade;

CREATE TABLE public.dim_jenkins_build
(
    build_id serial,
    build_number integer NOT NULL,
    build_start_time timestamp without time zone,
    build_duration interval,
    build_status character varying(20) COLLATE pg_catalog."default",
    job_id integer NOT NULL,
    CONSTRAINT dim_jenkins_build_pkey PRIMARY KEY (build_id),
    CONSTRAINT dim_jenkins_build_job_id_fkey FOREIGN KEY (job_id)
        REFERENCES public.dim_jenkins_jobs (job_id) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)